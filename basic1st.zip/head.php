<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

if (G5_IS_MOBILE) {
    include_once(G5_THEME_MOBILE_PATH.'/head.php');
    return;
}

include_once(G5_THEME_PATH.'/head.sub.php');
include_once(G5_LIB_PATH.'/latest.lib.php');
include_once(G5_LIB_PATH.'/outlogin.lib.php');
include_once(G5_LIB_PATH.'/poll.lib.php');
include_once(G5_LIB_PATH.'/visit.lib.php');
include_once(G5_LIB_PATH.'/connect.lib.php');
include_once(G5_LIB_PATH.'/popular.lib.php');
?>

<!-- 상단 시작 { -->


<div id="hd">
    <h1 id="hd_h1"><?php echo $g5['title'] ?></h1>

    <div id="skip_to_container"><a href="#container">본문 바로가기</a></div>

    <?php
    if(defined('_INDEX_')) { // index에서만 실행
        include G5_BBS_PATH.'/newwin.inc.php'; // 팝업레이어
    }
    ?>

    <div id="hd_wrapper">

        <div id="logo">
            <a href="<?php echo G5_URL ?>">
                <img src="<?echo G5_THEME_IMG_URL?>/logo_c.png" alt="<?php echo $config['cf_title']; ?>">
            </a>
        </div>
        <nav id="gnb">
            <div class="gnb_wrap">
                <ul id="gnb_1dul">
                    <?php
                    $sql = " select *
                                from {$g5['menu_table']}
                                where me_use = '1'
                                  and length(me_code) = '2'
                                order by me_order, me_id ";
                    $result = sql_query($sql, false);
                    $gnb_zindex = 999; // gnb_1dli z-index 값 설정용
                    $menu_datas = array();

                    for ($i=0; $row=sql_fetch_array($result); $i++) {
                        $menu_datas[$i] = $row;

                        $sql2 = " select *
                                    from {$g5['menu_table']}
                                    where me_use = '1'
                                      and length(me_code) = '4'
                                      and substring(me_code, 1, 2) = '{$row['me_code']}'
                                    order by me_order, me_id ";
                        $result2 = sql_query($sql2);
                        for ($k=0; $row2=sql_fetch_array($result2); $k++) {
                            $menu_datas[$i]['sub'][$k] = $row2;
                        }

                    }

                    $i = 0;
                    foreach( $menu_datas as $row ){
                        if( empty($row) ) continue; 
                    ?>
                    <li class="gnb_1dli" style="z-index:<?php echo $gnb_zindex--; ?>">
                        <a href="<?php echo $row['me_link']; ?>" target="_<?php echo $row['me_target']; ?>" class="gnb_1da"><?php echo $row['me_name'] ?></a>
                    </li>
                    <?php
                    $i++;
                    }   //end foreach $row

                    if ($i == 0) {  ?>
                        <li class="gnb_empty">메뉴 준비 중입니다.<?php if ($is_admin) { ?> <a href="<?php echo G5_ADMIN_URL; ?>/menu_list.php">관리자모드 &gt; 환경설정 &gt; 메뉴설정</a>에서 설정하실 수 있습니다.<?php } ?></li>
                    <?php } ?>
                </ul>
            </div>
        </nav>
    </div>
</div>


<!-- } 상단 끝 -->


<hr>

<!-- ----------mid---------- -->
<? if(defined("_INDEX_")){?>

<div class="mid">
    <div class="slide">
        <ul>
            <li><img src="<?echo G5_THEME_IMG_URL?>/slide_1.jpg" alt="img_1"></li>
            <li><img src="<?echo G5_THEME_IMG_URL?>/slide_2.jpg" alt="img_2"></li>
            <li><img src="<?echo G5_THEME_IMG_URL?>/slide_3.jpg" alt="img_3"></li>
            <li><img src="<?echo G5_THEME_IMG_URL?>/slide_4.jpg" alt="img_4"></li>
        </ul>
    </div>
    <div class="cont1">
        <ul class="clearfix">
            <li>
                <div class="txt_1">
                    <h5>한복연구가</h5>
                    <h3>디자이너 김숙진</h3>
                    <p class="plus"><a href="javascript:return false">+ 더보기</a></p>
                    <p>
                        우리옷은 우리 문화의 상징이요 국제화 시대의 중요한 문화 상품입니다.<br>
                        김숙진 우리옷은 우리 의복문화의 전통을 계승하면서, 시대에 맞게 <br>
                        발전시키고자 노력합니다.
                    </p>
                </div>
            </li>
            <li class="clearfix">
                <div class="txt_2 clearfix">
                    <h5>김숙진 우리옷</h5>
                    <h3>우리옷의자부심</h3>
                    <p class="plus"><a href="javascript:return false">+ 더보기</a></p>
                    <p>
                        전통과 현대 감각의 조화를 이루며 원단 재직에서부터 옛 문헌의 고증을 통한 <br>
                        전통 문양 재현과 자수 배치, 저고리 치마, 마고자, 바지 등 옷의 특성에 따른 전통 바느질,<br>
                        손수 염색 등 전통기법을 통해 우리 옷의 아름다움을 나타내고 있다.
                    </p>
                </div>
            </li>
        </ul>
    </div>
    <div class="cont2">
        <h3>우리 옷 컬렉션</h3>
        <p class="plus_2"><a href="javascript:return false">+ 더보기</a></p>
        <ul class="clearfix">
            <li>
                <div class="box">
                    <img src="<?echo G5_THEME_IMG_URL?>/gallery01.jpg" alt="img_1">
                    <div class="search">
                        <img src="<?echo G5_THEME_IMG_URL?>/search.png" alt="search">
                        <p>
                            옥사 소재 치맛자락 사이로 보이는<br>
                            단속곳의 실루엣과 자주색 코의 갖신,<br>
                            손등까지 덮는 시스루 재킷의 조화가<br>
                            동서양의 느낌을 고루 갖췄다.
                        </p>
                    </div>
                </div>
                <div class="box">
                    <img src="<?echo G5_THEME_IMG_URL?>/gallery02.jpg" alt="img_2">
                    <div class="search">
                        <img src="<?echo G5_THEME_IMG_URL?>/search.png" alt="search">
                        <p>
                            매화꽃이 흐드러진 주홍색 저고리와 석류로<br>
                            자연 염색한 치마가 모던 한복 이미지를 연출했다.
                        </p>
                    </div>
                </div>
            </li>
            <li>
                <div class="box">
                    <img src="<?echo G5_THEME_IMG_URL?>/gallery03.jpg" alt="img_3">
                    <div class="search">
                        <img src="<?echo G5_THEME_IMG_URL?>/search.png" alt="search">
                        <p>
                            사랑스러운 색상 매치가 돋보이는 신부<br>
                            한복으로 저고리는 조이고 치마는 풍성하게<br>
                            하여 한복 특유의 실루엣을 연출한다.
                        </p>
                    </div>
                </div>
                <div class="box">
                    <img src="<?echo G5_THEME_IMG_URL?>/gallery04.jpg" alt="img_4">
                    <div class="search">
                        <img src="<?echo G5_THEME_IMG_URL?>/search.png" alt="search">
                        <p>
                            비치는 느낌을 잘 표현한 옥색 치마와<br>
                            흰색 저고리가 단아하다.
                        </p>
                    </div>
                </div>
            </li>
            <li>
                <div class="box">
                    <img src="<?echo G5_THEME_IMG_URL?>/gallery05.jpg" alt="img_5">
                    <div class="search">
                        <img src="<?echo G5_THEME_IMG_URL?>/search.png" alt="search">
                        <p>
                            레이스 저고리와 남색 치마로 단아함을 연출했다.<br>
                            볼륨감 있는 면 레이스는 사랑스럽고<br>
                            남색 치마는 경쾌하다.
                        </p>
                    </div>
                </div>
                <div class="box">
                    <img src="<?echo G5_THEME_IMG_URL?>/gallery06.jpg" alt="img_6">
                    <div class="search">
                        <img src="<?echo G5_THEME_IMG_URL?>/search.png" alt="search">
                        <p>
                            서양 의상에서나 봄직한 페이즐 패턴과<br>
                            경쾌한 프린트를 변형하여 잔잔한 아름다움을<br>
                            선사하는 한복이다.
                        </p>
                    </div>
                </div>
            </li>
        </ul>
    </div>
    <div class="cont3">
        <div class="c3_wrap">
            <h3>뉴스 & 새소식</h3>
            <p class="plus_3"><a href="javascript:return false">+ 더보기</a></p>
            <ul>
                <li>
                    <h5>이코노미 뷰 김숙진 우리옷<br>
                    대표 김숙진 인터뷰</h5>
                    <p>
                        한복을 닮은 명인(名人) '한복의 시대'를 열다. "사단법인을 통해 한복디자인 공모전, 한복 만들기 체험 프로그램 등을 개설해 한복이 한국 전통 문화의 중심이 되도록 노력하겠습니다. 특히 전통에 관심이 많은 젊은 후학을 발굴하여 적극 육성하겠습니다."
                    </p>
                </li>
                <li>
                    <h5>김숙진 우리옷  Wedding21 17년 8월호</h5>
                    <p>
                        다양한 시대적 무드로 시간을 초월한 듯 빼어난 아름다움을 선사하는 김숙진우리옷, 김숙진우리옷을 입은 신랑신부와 두 사람의 친구들이 웨딩데이를 즐기고 있다. 한복의 아름다움이 바람에 날리는 꽃향기처럼 향기롭게 채워지는 현장을 담았다. 
                    </p>
                </li>
                <li>
                    <h5>김숙진 우리옷  MYWedding 17년 8월호</h5>
                    <p>
                        마이웨딩 2017년 8월호 김숙진우리옷의 작품이 실렸습니다. 풀빛이 고운 장옷과 은박 치마가 현대적인 조화를 보여줍니다. ​남색 본견 원삼 속에 레이스 저고리와 흰색 치마를 입어 원삼의 남색이 돋보입니다. 
                    </p>
                </li>
            </ul>
        </div>
    </div>
</div>

<script>
    // scroll
    $(window).scroll(function(){
        var winTop = $(this).scrollTop();
        console.log(winTop);
        if(winTop > 600){
            $(".gnb_wrap").addClass("fixed");
        }else{
            $(".gnb_wrap").removeClass("fixed");
        }
        if(winTop > 0){
            $(".cont1 li").eq(0).stop().animate({opacity: 1},700)
        }
        if(winTop > 350){
            $(".cont1 li").eq(1).stop().animate({opacity: 1},700)
        }
        if(winTop > 800){
            $(".cont2 h3").stop().animate({opacity: 1},700)
            $(".cont2 .plus_2").stop().animate({opacity: 1},700)
        }
        if(winTop > 900){
            $(".cont2 ul").stop().animate({opacity: 1},700)
            $("#top_btn").stop().animate({opacity: 1},700)
        }
    });
    // slide slider
    var current = 0;
    var i;
        function slider(){
            i = (current + 1) % 4;
            // console.log(i);
            $(".slide li").eq(current).fadeOut(700);
            $(".slide li").eq(i).fadeIn(700);
            current = i;
        }
    setInterval(slider,3000);

    // cont2 hover
    $(".box").mouseenter(function(){
        $(this).find(".search").stop().fadeIn(500);
    }).mouseleave(function(){
        $(this).find(".search").stop().fadeOut();
    });
</script>

<?}else{?>

<!-- ----------sub---------- -->
<div id="subBg">
    <div id="page_title" class="sbtImg">
        <div class="title">
            <h2 class="loc1D"><!-- 1차메뉴 --></h2>
            <div class="text"></div>
        </div>
    </div>
</div>
<script>
    // window.onload = function(){};
    window.onload = function(){
        var menuDep = $("#subBg .loc1D").html();
        console.log("현재위치 : " + menuDep);
        // if(menuDep == "디자이너 김숙진"){
            // $("#subBg .text").text("우리옷 문화의 중심이 되겠습니다.")
        // }else if(menuDep == "우리 옷 컬렉션"){
            // $("#subBg .text").text("이곳은 자유롭게 글쓰기를 하실 수 있습니다.")
        // }
    };
</script>

<?}?>


<!-- 콘텐츠 시작 { -->
<div id="wrapper">   
    <div id="container">
        <?php if (!defined("_INDEX_")) { ?>

            <div>
                <span class="locationBar" title="현재위치">
                    <span> <em class="fa fa-home" aria-hidden="true"></em> HOME
                    <i class="fa fa-angle-right" aria-hidden="true"></i> </span>
                    <span class="loc1D"><!-- 1차메뉴 --></span>
                    <i class="fa fa-angle-right"></i>
                    <span class="loc2D"><!-- 2차메뉴 --></span>
                </span>
            </div>
            <h2 id="container_title">
                <?php echo get_head_title($g5['title']); ?><br>
            </h2>
            <div class="subTitle">
                <?
                $subTitle = get_head_title($g5['title']); //타이틀 변수

                if( $subTitle == "디자이너 김숙진"){
                ?>
                    대한민국을 대표하는 글로벌 기업
                    <img src="<? echo G5_THEME_IMG_URL ?>/pc01.jpg" alt="우주">
                <?
                }else if( $subTitle == "나아갈 길"){
                    // echo "글로벌기업 나아갈 길";
                    // echo "<img src='";
                    // echo G5_THEME_IMG_URL;
                    // echo "/pc01.jpg'>";
                }
                ?>
            </div>


        <?php } ?>
