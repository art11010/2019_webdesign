<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

if (G5_IS_MOBILE) {
    include_once(G5_THEME_MOBILE_PATH.'/tail.php');
    return;
}
?>

    </div> <!-- container -->
    <? if (!defined("_INDEX_")){ ?>
    <div id="aside">
        <?include_once(G5_THEME_PATH.'/skin/nav/mysubmenu.php'); ?>
    </div>
    <?}?>

</div> <!-- wrapper -->
<!-- } 콘텐츠 끝 -->

<hr>

<!-- 하단 시작 { -->
<div id="ft">
    <div id="ft_wr">
        <div id="ft_link">
            <a class="sns_1"
             href="http://instagram.com/kim.sookjin" target="_blank">instagram</a>
            <a class="sns_2"
             href="https://blog.naver.com/kimsookjin" target="_blank">blog</a>
            <a class="sns_3"
             href="https://cafe.naver.com/kimsookjin" target="_blank" >cafe</a>
            <!-- <a href="<?php echo get_device_change_url(); ?>">모바일버전</a> -->
        </div>
        <div id="ft_catch">
            <img src="<?echo G5_THEME_IMG_URL?>/logo_o.png" alt="<?php echo G5_VERSION ?>">
        </div>
        <div id="ft_copy"><!-- Copyright -->
            서울 강남구 선릉로 716 / (지번) 서울 강남구 청담동 40-6 / 대표이사 : 김숙진 / 대표번호 : 02-548-2588 / 팩스 : 02-548-7768 / 사업자등록번호 : 108-10-67264<br>
            &copy; <b>2016 KIMSOOKJIN LTD.</b>ALL RIGHTS RESERVED.
        </div>
    </div>
    <button type="button" id="top_btn"><i class="fa fa-arrow-up" aria-hidden="true"></i><span class="sound_only">상단으로</span></button>
        <script>
        
        $(function() {
            $("#top_btn").on("click", function() {
                $("html, body").animate({scrollTop:0}, '500');
                return false;
            });
        });
        </script>
</div>

<?php
if(G5_DEVICE_BUTTON_DISPLAY && !G5_IS_MOBILE) { ?>
<?php
}

if ($config['cf_analytics']) {
    echo $config['cf_analytics'];
}
?>

<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>

<?php
include_once(G5_THEME_PATH."/tail.sub.php");
?>