-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- 생성 시간: 19-09-02 10:58
-- 서버 버전: 5.5.59-log
-- PHP 버전: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 데이터베이스: `art11010`
--
CREATE DATABASE IF NOT EXISTS `art11010` DEFAULT CHARACTER SET euckr COLLATE euckr_korean_ci;
USE `art11010`;

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_auth`
--

CREATE TABLE `g5_auth` (
  `mb_id` varchar(20) NOT NULL DEFAULT '',
  `au_menu` varchar(20) NOT NULL DEFAULT '',
  `au_auth` set('r','w','d') NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_autosave`
--

CREATE TABLE `g5_autosave` (
  `as_id` int(11) NOT NULL,
  `mb_id` varchar(20) NOT NULL,
  `as_uid` bigint(20) UNSIGNED NOT NULL,
  `as_subject` varchar(255) NOT NULL,
  `as_content` text NOT NULL,
  `as_datetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_board`
--

CREATE TABLE `g5_board` (
  `bo_table` varchar(20) NOT NULL DEFAULT '',
  `gr_id` varchar(255) NOT NULL DEFAULT '',
  `bo_subject` varchar(255) NOT NULL DEFAULT '',
  `bo_mobile_subject` varchar(255) NOT NULL DEFAULT '',
  `bo_device` enum('both','pc','mobile') NOT NULL DEFAULT 'both',
  `bo_admin` varchar(255) NOT NULL DEFAULT '',
  `bo_list_level` tinyint(4) NOT NULL DEFAULT '0',
  `bo_read_level` tinyint(4) NOT NULL DEFAULT '0',
  `bo_write_level` tinyint(4) NOT NULL DEFAULT '0',
  `bo_reply_level` tinyint(4) NOT NULL DEFAULT '0',
  `bo_comment_level` tinyint(4) NOT NULL DEFAULT '0',
  `bo_upload_level` tinyint(4) NOT NULL DEFAULT '0',
  `bo_download_level` tinyint(4) NOT NULL DEFAULT '0',
  `bo_html_level` tinyint(4) NOT NULL DEFAULT '0',
  `bo_link_level` tinyint(4) NOT NULL DEFAULT '0',
  `bo_count_delete` tinyint(4) NOT NULL DEFAULT '0',
  `bo_count_modify` tinyint(4) NOT NULL DEFAULT '0',
  `bo_read_point` int(11) NOT NULL DEFAULT '0',
  `bo_write_point` int(11) NOT NULL DEFAULT '0',
  `bo_comment_point` int(11) NOT NULL DEFAULT '0',
  `bo_download_point` int(11) NOT NULL DEFAULT '0',
  `bo_use_category` tinyint(4) NOT NULL DEFAULT '0',
  `bo_category_list` text NOT NULL,
  `bo_use_sideview` tinyint(4) NOT NULL DEFAULT '0',
  `bo_use_file_content` tinyint(4) NOT NULL DEFAULT '0',
  `bo_use_secret` tinyint(4) NOT NULL DEFAULT '0',
  `bo_use_dhtml_editor` tinyint(4) NOT NULL DEFAULT '0',
  `bo_use_rss_view` tinyint(4) NOT NULL DEFAULT '0',
  `bo_use_good` tinyint(4) NOT NULL DEFAULT '0',
  `bo_use_nogood` tinyint(4) NOT NULL DEFAULT '0',
  `bo_use_name` tinyint(4) NOT NULL DEFAULT '0',
  `bo_use_signature` tinyint(4) NOT NULL DEFAULT '0',
  `bo_use_ip_view` tinyint(4) NOT NULL DEFAULT '0',
  `bo_use_list_view` tinyint(4) NOT NULL DEFAULT '0',
  `bo_use_list_file` tinyint(4) NOT NULL DEFAULT '0',
  `bo_use_list_content` tinyint(4) NOT NULL DEFAULT '0',
  `bo_table_width` int(11) NOT NULL DEFAULT '0',
  `bo_subject_len` int(11) NOT NULL DEFAULT '0',
  `bo_mobile_subject_len` int(11) NOT NULL DEFAULT '0',
  `bo_page_rows` int(11) NOT NULL DEFAULT '0',
  `bo_mobile_page_rows` int(11) NOT NULL DEFAULT '0',
  `bo_new` int(11) NOT NULL DEFAULT '0',
  `bo_hot` int(11) NOT NULL DEFAULT '0',
  `bo_image_width` int(11) NOT NULL DEFAULT '0',
  `bo_skin` varchar(255) NOT NULL DEFAULT '',
  `bo_mobile_skin` varchar(255) NOT NULL DEFAULT '',
  `bo_include_head` varchar(255) NOT NULL DEFAULT '',
  `bo_include_tail` varchar(255) NOT NULL DEFAULT '',
  `bo_content_head` text NOT NULL,
  `bo_mobile_content_head` text NOT NULL,
  `bo_content_tail` text NOT NULL,
  `bo_mobile_content_tail` text NOT NULL,
  `bo_insert_content` text NOT NULL,
  `bo_gallery_cols` int(11) NOT NULL DEFAULT '0',
  `bo_gallery_width` int(11) NOT NULL DEFAULT '0',
  `bo_gallery_height` int(11) NOT NULL DEFAULT '0',
  `bo_mobile_gallery_width` int(11) NOT NULL DEFAULT '0',
  `bo_mobile_gallery_height` int(11) NOT NULL DEFAULT '0',
  `bo_upload_size` int(11) NOT NULL DEFAULT '0',
  `bo_reply_order` tinyint(4) NOT NULL DEFAULT '0',
  `bo_use_search` tinyint(4) NOT NULL DEFAULT '0',
  `bo_order` int(11) NOT NULL DEFAULT '0',
  `bo_count_write` int(11) NOT NULL DEFAULT '0',
  `bo_count_comment` int(11) NOT NULL DEFAULT '0',
  `bo_write_min` int(11) NOT NULL DEFAULT '0',
  `bo_write_max` int(11) NOT NULL DEFAULT '0',
  `bo_comment_min` int(11) NOT NULL DEFAULT '0',
  `bo_comment_max` int(11) NOT NULL DEFAULT '0',
  `bo_notice` text NOT NULL,
  `bo_upload_count` tinyint(4) NOT NULL DEFAULT '0',
  `bo_use_email` tinyint(4) NOT NULL DEFAULT '0',
  `bo_use_cert` enum('','cert','adult','hp-cert','hp-adult') NOT NULL DEFAULT '',
  `bo_use_sns` tinyint(4) NOT NULL DEFAULT '0',
  `bo_use_captcha` tinyint(4) NOT NULL DEFAULT '0',
  `bo_sort_field` varchar(255) NOT NULL DEFAULT '',
  `bo_1_subj` varchar(255) NOT NULL DEFAULT '',
  `bo_2_subj` varchar(255) NOT NULL DEFAULT '',
  `bo_3_subj` varchar(255) NOT NULL DEFAULT '',
  `bo_4_subj` varchar(255) NOT NULL DEFAULT '',
  `bo_5_subj` varchar(255) NOT NULL DEFAULT '',
  `bo_6_subj` varchar(255) NOT NULL DEFAULT '',
  `bo_7_subj` varchar(255) NOT NULL DEFAULT '',
  `bo_8_subj` varchar(255) NOT NULL DEFAULT '',
  `bo_9_subj` varchar(255) NOT NULL DEFAULT '',
  `bo_10_subj` varchar(255) NOT NULL DEFAULT '',
  `bo_1` varchar(255) NOT NULL DEFAULT '',
  `bo_2` varchar(255) NOT NULL DEFAULT '',
  `bo_3` varchar(255) NOT NULL DEFAULT '',
  `bo_4` varchar(255) NOT NULL DEFAULT '',
  `bo_5` varchar(255) NOT NULL DEFAULT '',
  `bo_6` varchar(255) NOT NULL DEFAULT '',
  `bo_7` varchar(255) NOT NULL DEFAULT '',
  `bo_8` varchar(255) NOT NULL DEFAULT '',
  `bo_9` varchar(255) NOT NULL DEFAULT '',
  `bo_10` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `g5_board`
--

INSERT INTO `g5_board` (`bo_table`, `gr_id`, `bo_subject`, `bo_mobile_subject`, `bo_device`, `bo_admin`, `bo_list_level`, `bo_read_level`, `bo_write_level`, `bo_reply_level`, `bo_comment_level`, `bo_upload_level`, `bo_download_level`, `bo_html_level`, `bo_link_level`, `bo_count_delete`, `bo_count_modify`, `bo_read_point`, `bo_write_point`, `bo_comment_point`, `bo_download_point`, `bo_use_category`, `bo_category_list`, `bo_use_sideview`, `bo_use_file_content`, `bo_use_secret`, `bo_use_dhtml_editor`, `bo_use_rss_view`, `bo_use_good`, `bo_use_nogood`, `bo_use_name`, `bo_use_signature`, `bo_use_ip_view`, `bo_use_list_view`, `bo_use_list_file`, `bo_use_list_content`, `bo_table_width`, `bo_subject_len`, `bo_mobile_subject_len`, `bo_page_rows`, `bo_mobile_page_rows`, `bo_new`, `bo_hot`, `bo_image_width`, `bo_skin`, `bo_mobile_skin`, `bo_include_head`, `bo_include_tail`, `bo_content_head`, `bo_mobile_content_head`, `bo_content_tail`, `bo_mobile_content_tail`, `bo_insert_content`, `bo_gallery_cols`, `bo_gallery_width`, `bo_gallery_height`, `bo_mobile_gallery_width`, `bo_mobile_gallery_height`, `bo_upload_size`, `bo_reply_order`, `bo_use_search`, `bo_order`, `bo_count_write`, `bo_count_comment`, `bo_write_min`, `bo_write_max`, `bo_comment_min`, `bo_comment_max`, `bo_notice`, `bo_upload_count`, `bo_use_email`, `bo_use_cert`, `bo_use_sns`, `bo_use_captcha`, `bo_sort_field`, `bo_1_subj`, `bo_2_subj`, `bo_3_subj`, `bo_4_subj`, `bo_5_subj`, `bo_6_subj`, `bo_7_subj`, `bo_8_subj`, `bo_9_subj`, `bo_10_subj`, `bo_1`, `bo_2`, `bo_3`, `bo_4`, `bo_5`, `bo_6`, `bo_7`, `bo_8`, `bo_9`, `bo_10`) VALUES
('notice', 'community', '\뉴\스 & \새소식', '', 'both', '', 1, 1, 10, 1, 1, 1, 1, 1, 1, 1, 1, -1, 5, 1, -20, 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 60, 30, 15, 15, 24, 100, 835, 'theme/gallery', 'theme/gallery', '_head.php', '_tail.php', '', '', '', '', '', 4, 285, 120, 125, 100, 1048576, 1, 0, 0, 13, 0, 0, 0, 0, 0, '', 2, 0, '', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('qa', 'community', '질문\답변', '', 'both', '', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 5, 1, -20, 1, '\트\렌드한복|\전통\한복|\드레스\한복|\협찬\작품', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 60, 30, 15, 15, 24, 100, 835, 'basic', 'basic', '_head.php', '_tail.php', '', '', '', '', '', 3, 375, 375, 125, 100, 1048576, 1, 0, 0, 0, 0, 0, 0, 0, 0, '', 2, 0, '', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('gallery', 'community', '\우�\� \옷 컬렉션', '', 'both', '', 1, 1, 10, 10, 1, 1, 1, 1, 1, 1, 1, -1, 5, 1, -20, 1, '\트\렌드한복|\전통\한복|\드레스\한복|\협찬\작품', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 60, 30, 30, 15, 24, 100, 835, 'theme/modalgallery', 'theme/gallery', '_head.php', '_tail.php', '', '', '', '', '', 3, 375, 375, 125, 100, 1048576, 1, 0, 0, 37, 0, 0, 0, 0, 0, '', 2, 0, '', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('freeboard', 'community', '\자유�\��시판', '', 'both', '', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, '\트\렌드한복|\전통\한복|\드레스\한복|\협찬\작품', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 60, 30, 15, 15, 24, 100, 600, 'basic', 'basic', '_head.php', '_tail.php', '', '', '', '', '', 3, 375, 375, 125, 100, 1048576, 1, 1, 0, 0, 0, 0, 0, 0, 0, '', 2, 0, '', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_board_file`
--

CREATE TABLE `g5_board_file` (
  `bo_table` varchar(20) NOT NULL DEFAULT '',
  `wr_id` int(11) NOT NULL DEFAULT '0',
  `bf_no` int(11) NOT NULL DEFAULT '0',
  `bf_source` varchar(255) NOT NULL DEFAULT '',
  `bf_file` varchar(255) NOT NULL DEFAULT '',
  `bf_download` int(11) NOT NULL,
  `bf_content` text NOT NULL,
  `bf_filesize` int(11) NOT NULL DEFAULT '0',
  `bf_width` int(11) NOT NULL DEFAULT '0',
  `bf_height` smallint(6) NOT NULL DEFAULT '0',
  `bf_type` tinyint(4) NOT NULL DEFAULT '0',
  `bf_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `g5_board_file`
--

INSERT INTO `g5_board_file` (`bo_table`, `wr_id`, `bf_no`, `bf_source`, `bf_file`, `bf_download`, `bf_content`, `bf_filesize`, `bf_width`, `bf_height`, `bf_type`, `bf_datetime`) VALUES
('gallery', 4, 0, 'gallery06.jpg', '1893645299_ZD2Yt3RF_fddff37d3125f33d0fabc74cbef3da5e593b4393.jpg', 0, '', 30136, 378, 374, 2, '2019-08-27 14:41:57'),
('gallery', 2, 0, 'gallery08.jpg', '1893645299_FAgecXJw_4f18d1185b7f148c37fff000c84140f14596c42b.jpg', 0, '', 18645, 378, 374, 2, '2019-08-27 14:41:17'),
('gallery', 3, 0, 'gallery07.jpg', '1893645299_rOSMo6Uz_9d5541cc4fdec352a31140a42f6095102e51cb1a.jpg', 0, '', 27734, 378, 374, 2, '2019-08-27 14:41:43'),
('gallery', 5, 0, 'gallery05.jpg', '1893645299_P8v5GyiV_8a4acf40e84356d4b9fecdb65d0e8b437557267e.jpg', 0, '', 26371, 378, 374, 2, '2019-08-27 14:42:14'),
('gallery', 8, 0, 'gallery03.jpg', '1893645299_wHCpK3yZ_503d79f86ef180750de0b832a1a00eb969cde1c7.jpg', 0, '', 16734, 378, 374, 2, '2019-08-27 14:43:19'),
('gallery', 7, 0, 'gallery04.jpg', '1893645299_MqZOLtaB_f2eaf6642287444110be8d78d4c90e0958479149.jpg', 0, '', 22392, 378, 374, 2, '2019-08-27 14:43:01'),
('gallery', 9, 0, 'gallery02.jpg', '1893645299_q5jfapto_5daa5d2bf077b72221286e96b6dc7ecbf05b028f.jpg', 0, '', 17606, 378, 374, 2, '2019-08-27 14:47:50'),
('gallery', 10, 0, 'gallery01.jpg', '1893645299_LZ6ABQpx_56a1df3276f751a4727dc16969855908a9d05228.jpg', 0, '', 19300, 378, 374, 2, '2019-08-27 14:48:08'),
('gallery', 11, 0, 'gallery03.jpg', '1893645299_i34pOJXM_f98b43d0eb523ceb5bfcca2a1ed2851bb1b2878d.jpg', 0, '', 585045, 1000, 786, 2, '2019-08-27 14:49:25'),
('gallery', 12, 0, 'gallery02.jpg', '1893645299_Jvg6hjLn_b2b29b0e350549da68973b5197355116cd97db26.jpg', 0, '', 787580, 1000, 1333, 2, '2019-08-27 14:51:46'),
('gallery', 13, 0, 'gallery01.jpg', '1893645299_xKIMdO9e_857fdcfe41ec1008ef404c9a4818ba14ec78c1c7.jpg', 0, '', 187099, 980, 970, 2, '2019-08-27 14:52:14'),
('gallery', 14, 0, 'gallery14.jpg', '1893645299_rOUCkhsM_7a38ba5e20793323d5c11be373ba85725032b42e.jpg', 0, '', 438085, 1000, 751, 2, '2019-08-27 14:53:12'),
('gallery', 15, 0, 'gallery13.jpg', '1893645299_LlvuT4FB_0db147094fb18f3264ae89f159891a62f25a41af.jpg', 0, '', 547623, 1000, 778, 2, '2019-08-27 14:53:31'),
('gallery', 16, 0, 'gallery12.jpg', '1893645299_HSt0Nz9R_fd0d86dc41918f846341cf5d81bd5c0d6e10e960.jpg', 0, '', 775236, 1000, 1086, 2, '2019-08-27 14:54:03'),
('gallery', 17, 0, 'gallery11.jpg', '1893645299_ciAJekmR_f2bb6836d6f03d46bd15f83257ecd1d54a596898.jpg', 0, '', 624161, 1000, 1332, 2, '2019-08-27 14:54:14'),
('gallery', 18, 0, 'gallery10.jpg', '1893645299_sdK7DFfY_4ab1853ee82d76dac9b5b09f399aa514b9e4e8de.jpg', 0, '', 330765, 1000, 751, 2, '2019-08-27 14:54:27'),
('gallery', 19, 0, 'gallery09.jpg', '1893645299_YwL6zZQO_f41dce22605b2d49b48987a4d1fbf4507b6df37e.jpg', 0, '', 423259, 1000, 1332, 2, '2019-08-27 14:54:40'),
('gallery', 20, 0, 'gallery08.jpg', '1893645299_jPitdbry_fa1bd6e77b98215933fd410d4ef9e3f6792b72be.jpg', 0, '', 556667, 1000, 1332, 2, '2019-08-27 14:54:54'),
('gallery', 21, 0, 'gallery07.jpg', '1893645299_UQGiXuIB_621bdce5d2a609f3d14638884ec8efd43c7aa65e.jpg', 0, '', 423394, 1000, 751, 2, '2019-08-27 14:55:17'),
('gallery', 22, 0, 'gallery06.jpg', '1893645299_TzhU0fJu_abebf913df3b0777b166659032468e9d4f1781be.jpg', 0, '', 632943, 1000, 805, 2, '2019-08-27 14:55:30'),
('gallery', 23, 0, 'gallery05.jpg', '1893645299_DIyRPApu_c8178192191fa547f8a70d2cc11fe878ebdbf211.jpg', 0, '', 670917, 1000, 805, 2, '2019-08-27 14:55:41'),
('gallery', 24, 0, 'gallery04.jpg', '1893645299_lXuNJ2nU_8300063136170a5a32518fe6f5266bbf4a64b327.jpg', 0, '', 386752, 1000, 751, 2, '2019-08-27 14:55:56'),
('gallery', 25, 0, 'gallery03.jpg', '1893645299_lAL5W3xr_4b5e9908fa6ce08e642d44745a5e4fd5fd6f55ba.jpg', 0, '', 480717, 720, 864, 2, '2019-08-27 14:56:31'),
('gallery', 26, 0, 'gallery02.jpg', '1893645299_eMQx3yX5_dfa5ff7dc6aa9fd69d18d4a1efbccfc56063f297.jpg', 0, '', 406543, 720, 873, 2, '2019-08-27 14:56:44'),
('gallery', 27, 0, 'gallery01.jpg', '1893645299_14kzv2iJ_ff88c1ec4b4ff79dd089d4fab53daf9fb941701d.jpg', 0, '', 318626, 960, 625, 2, '2019-08-27 14:56:56'),
('gallery', 28, 0, 'gallery12.jpg', '1893645299_Idz7wHBQ_31480d7bacbbfbf6f68126ce8328cc1d05f89cd6.jpg', 0, '', 52666, 378, 374, 2, '2019-08-27 14:57:53'),
('gallery', 29, 0, 'gallery11.jpg', '1893645299_Rq2iMhYS_b234595d1f3d6958eb59d4afe65d53a2b3895b76.jpg', 0, '', 42968, 378, 374, 2, '2019-08-27 14:58:05'),
('gallery', 30, 0, 'gallery10.jpg', '1893645299_DQsPYw5z_1842a118bc08d025df350b98d6fc5d4b67313b37.jpg', 0, '', 48074, 378, 374, 2, '2019-08-27 14:58:22'),
('gallery', 31, 0, 'gallery09.jpg', '1893645299_o5tukz3j_99af213c5c934631d7a4acc1d1f13a34578b45ec.jpg', 0, '', 56849, 378, 374, 2, '2019-08-27 14:58:49'),
('gallery', 32, 0, 'gallery08.jpg', '1893645299_V3ANgTuI_eb7c950191dd5e93d4f2de85bef0d69f331d8016.jpg', 0, '', 41989, 378, 374, 2, '2019-08-27 14:59:04'),
('gallery', 33, 0, 'gallery07.jpg', '1893645299_PEY3Wa1H_8ce38c0d0c22737c30c0d83b814dca23affc6d6a.jpg', 0, '', 44799, 378, 374, 2, '2019-08-27 14:59:15'),
('gallery', 34, 0, 'gallery06.jpg', '1893645299_rRSmpWzD_73a42f262393cf01f37cc845bb3effc3b24918be.jpg', 0, '', 54014, 378, 374, 2, '2019-08-27 14:59:26'),
('gallery', 35, 0, 'gallery05.jpg', '1893645299_TB4hLNsS_8cc7f5340f54bb34befc8684cc321942a6bd31b8.jpg', 0, '', 45710, 378, 374, 2, '2019-08-27 14:59:38'),
('gallery', 36, 0, 'gallery04.jpg', '1893645299_KEVxhrYZ_b3ac36f5679177f92c79c8be2e2ef6e8f1cfa939.jpg', 0, '', 73883, 378, 374, 2, '2019-08-27 14:59:51'),
('gallery', 37, 0, 'gallery03.jpg', '1893645299_M3XDa4k0_a9d1aa1ea9edc73aff40b959e5b467dea584d57e.jpg', 0, '', 43836, 378, 374, 2, '2019-08-27 15:00:13'),
('gallery', 38, 0, 'gallery02.jpg', '1893645299_Thsm2oNi_b767a54f0e0058ecb270eaa15fa9f3d56b683048.jpg', 0, '', 32448, 378, 374, 2, '2019-08-27 15:00:25'),
('gallery', 39, 0, 'gallery01.jpg', '1893645299_3fcpwDFz_74b3d49af40c95cdd684c61cfd9a8696e6446087.jpg', 0, '', 33440, 378, 374, 2, '2019-08-27 15:00:36'),
('notice', 1, 0, 'new_20.jpg', '1893645299_XSTRxzHy_ae9bb89040180fe04934b1dfa906956fbedd8533.jpg', 0, '', 9828, 284, 170, 2, '2019-08-27 17:06:03'),
('notice', 2, 0, 'new_19.jpg', '1893645299_Wc7m2es4_e23d4730e78b83e4bacd2836c2b8a0677ac96725.jpg', 0, '', 7116, 284, 170, 2, '2019-08-27 17:06:50'),
('notice', 3, 0, 'new_18.jpg', '1893645299_bZflPRhT_72bfcb0b07d45577b5c4e590919ae8501d7e8437.jpg', 0, '', 19522, 284, 170, 2, '2019-08-27 17:09:35'),
('notice', 4, 0, 'new_17.jpg', '1893645299_QubL38hg_4e27a92798c09e0a0ca7a28b35b1cb8d32f1c0e3.jpg', 0, '', 14710, 284, 170, 2, '2019-08-27 17:13:23'),
('notice', 5, 0, 'new_16.jpg', '1893645299_Ao8GxjYE_67c47c836da8cf6799bce1abfc0f240a13f44da6.jpg', 0, '', 12033, 284, 170, 2, '2019-08-27 17:14:11'),
('notice', 6, 0, 'new_15.jpg', '1893645299_csmZkV7Y_79d74b7f8ba57580809357729d56c143516b7698.jpg', 0, '', 16545, 284, 170, 2, '2019-08-27 17:15:06'),
('notice', 9, 0, 'new_13.jpg', '1893645299_ZUom6nAJ_b94354a52e4f02134fa734916c98eae2d02d795e.jpg', 0, '', 21887, 284, 170, 2, '2019-08-27 17:17:50'),
('notice', 8, 0, 'new_14.jpg', '1893645299_IZpA4DWT_5656e92c903f9a60c4d1e5979b5ea48659dd3522.jpg', 0, '', 8120, 284, 170, 2, '2019-08-27 17:17:08'),
('notice', 10, 0, 'new_12.jpg', '1893645299_xpfEdYq8_b1cbcfff27ca49ba6857fa55b1f2f9658641965f.jpg', 0, '', 14545, 284, 170, 2, '2019-08-27 17:18:16'),
('notice', 11, 0, 'new_07.jpg', '1893645299_W9zrvh65_3601eb1e9d60754026605dc17f4e38abfd62a6ca.jpg', 0, '', 14518, 284, 170, 2, '2019-08-27 17:19:28'),
('notice', 12, 0, 'new_03.jpg', '1893645299_DzL5XNR0_2f7ab51240ce9f06670a53e6edfe99b756ceac58.jpg', 0, '', 9200, 284, 170, 2, '2019-08-27 17:20:14'),
('notice', 13, 0, 'new_02.jpg', '1893645299_uGR5wcmP_9f1eedc022948ab27c9bc1a1a6d59fd6e1f47baf.jpg', 0, '', 18987, 284, 170, 2, '2019-08-27 17:21:32'),
('notice', 14, 0, 'new_01.jpg', '1893645299_1auBoKMD_fba0870913af2a0b0d3ee10726b4d5d2e5d3260e.jpg', 0, '', 11865, 284, 170, 2, '2019-08-27 17:22:10');

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_board_good`
--

CREATE TABLE `g5_board_good` (
  `bg_id` int(11) NOT NULL,
  `bo_table` varchar(20) NOT NULL DEFAULT '',
  `wr_id` int(11) NOT NULL DEFAULT '0',
  `mb_id` varchar(20) NOT NULL DEFAULT '',
  `bg_flag` varchar(255) NOT NULL DEFAULT '',
  `bg_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_board_new`
--

CREATE TABLE `g5_board_new` (
  `bn_id` int(11) NOT NULL,
  `bo_table` varchar(20) NOT NULL DEFAULT '',
  `wr_id` int(11) NOT NULL DEFAULT '0',
  `wr_parent` int(11) NOT NULL DEFAULT '0',
  `bn_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `mb_id` varchar(20) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `g5_board_new`
--

INSERT INTO `g5_board_new` (`bn_id`, `bo_table`, `wr_id`, `wr_parent`, `bn_datetime`, `mb_id`) VALUES
(8, 'gallery', 3, 3, '2019-08-27 14:41:43', 'admin'),
(7, 'gallery', 2, 2, '2019-08-27 14:41:17', 'admin'),
(9, 'gallery', 4, 4, '2019-08-27 14:41:57', 'admin'),
(10, 'gallery', 5, 5, '2019-08-27 14:42:14', 'admin'),
(12, 'gallery', 7, 7, '2019-08-27 14:43:01', 'admin'),
(13, 'gallery', 8, 8, '2019-08-27 14:43:19', 'admin'),
(14, 'gallery', 9, 9, '2019-08-27 14:47:50', 'admin'),
(15, 'gallery', 10, 10, '2019-08-27 14:48:08', 'admin'),
(16, 'gallery', 11, 11, '2019-08-27 14:49:25', 'admin'),
(17, 'gallery', 12, 12, '2019-08-27 14:51:46', 'admin'),
(18, 'gallery', 13, 13, '2019-08-27 14:52:14', 'admin'),
(19, 'gallery', 14, 14, '2019-08-27 14:53:12', 'admin'),
(20, 'gallery', 15, 15, '2019-08-27 14:53:31', 'admin'),
(21, 'gallery', 16, 16, '2019-08-27 14:54:03', 'admin'),
(22, 'gallery', 17, 17, '2019-08-27 14:54:14', 'admin'),
(23, 'gallery', 18, 18, '2019-08-27 14:54:27', 'admin'),
(24, 'gallery', 19, 19, '2019-08-27 14:54:40', 'admin'),
(25, 'gallery', 20, 20, '2019-08-27 14:54:54', 'admin'),
(26, 'gallery', 21, 21, '2019-08-27 14:55:17', 'admin'),
(27, 'gallery', 22, 22, '2019-08-27 14:55:30', 'admin'),
(28, 'gallery', 23, 23, '2019-08-27 14:55:41', 'admin'),
(29, 'gallery', 24, 24, '2019-08-27 14:55:56', 'admin'),
(30, 'gallery', 25, 25, '2019-08-27 14:56:31', 'admin'),
(31, 'gallery', 26, 26, '2019-08-27 14:56:44', 'admin'),
(32, 'gallery', 27, 27, '2019-08-27 14:56:56', 'admin'),
(33, 'gallery', 28, 28, '2019-08-27 14:57:53', 'admin'),
(34, 'gallery', 29, 29, '2019-08-27 14:58:05', 'admin'),
(35, 'gallery', 30, 30, '2019-08-27 14:58:22', 'admin'),
(36, 'gallery', 31, 31, '2019-08-27 14:58:49', 'admin'),
(37, 'gallery', 32, 32, '2019-08-27 14:59:04', 'admin'),
(38, 'gallery', 33, 33, '2019-08-27 14:59:15', 'admin'),
(39, 'gallery', 34, 34, '2019-08-27 14:59:26', 'admin'),
(40, 'gallery', 35, 35, '2019-08-27 14:59:38', 'admin'),
(41, 'gallery', 36, 36, '2019-08-27 14:59:51', 'admin'),
(42, 'gallery', 37, 37, '2019-08-27 15:00:13', 'admin'),
(43, 'gallery', 38, 38, '2019-08-27 15:00:25', 'admin'),
(44, 'gallery', 39, 39, '2019-08-27 15:00:36', 'admin'),
(45, 'notice', 1, 1, '2019-08-27 17:06:03', 'admin'),
(46, 'notice', 2, 2, '2019-08-27 17:06:50', 'admin'),
(47, 'notice', 3, 3, '2019-08-27 17:09:35', 'admin'),
(48, 'notice', 4, 4, '2019-08-27 17:13:23', 'admin'),
(49, 'notice', 5, 5, '2019-08-27 17:14:11', 'admin'),
(50, 'notice', 6, 6, '2019-08-27 17:15:06', 'admin'),
(52, 'notice', 8, 8, '2019-08-27 17:17:08', 'admin'),
(53, 'notice', 9, 9, '2019-08-27 17:17:50', 'admin'),
(54, 'notice', 10, 10, '2019-08-27 17:18:16', 'admin'),
(55, 'notice', 11, 11, '2019-08-27 17:19:28', 'admin'),
(56, 'notice', 12, 12, '2019-08-27 17:20:14', 'admin'),
(57, 'notice', 13, 13, '2019-08-27 17:21:32', 'admin'),
(58, 'notice', 14, 14, '2019-08-27 17:22:10', 'admin');

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_cert_history`
--

CREATE TABLE `g5_cert_history` (
  `cr_id` int(11) NOT NULL,
  `mb_id` varchar(20) NOT NULL DEFAULT '',
  `cr_company` varchar(255) NOT NULL DEFAULT '',
  `cr_method` varchar(255) NOT NULL DEFAULT '',
  `cr_ip` varchar(255) NOT NULL DEFAULT '',
  `cr_date` date NOT NULL DEFAULT '0000-00-00',
  `cr_time` time NOT NULL DEFAULT '00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_config`
--

CREATE TABLE `g5_config` (
  `cf_title` varchar(255) NOT NULL DEFAULT '',
  `cf_theme` varchar(255) NOT NULL DEFAULT '',
  `cf_admin` varchar(255) NOT NULL DEFAULT '',
  `cf_admin_email` varchar(255) NOT NULL DEFAULT '',
  `cf_admin_email_name` varchar(255) NOT NULL DEFAULT '',
  `cf_add_script` text NOT NULL,
  `cf_use_point` tinyint(4) NOT NULL DEFAULT '0',
  `cf_point_term` int(11) NOT NULL DEFAULT '0',
  `cf_use_copy_log` tinyint(4) NOT NULL DEFAULT '0',
  `cf_use_email_certify` tinyint(4) NOT NULL DEFAULT '0',
  `cf_login_point` int(11) NOT NULL DEFAULT '0',
  `cf_cut_name` tinyint(4) NOT NULL DEFAULT '0',
  `cf_nick_modify` int(11) NOT NULL DEFAULT '0',
  `cf_new_skin` varchar(255) NOT NULL DEFAULT '',
  `cf_new_rows` int(11) NOT NULL DEFAULT '0',
  `cf_search_skin` varchar(255) NOT NULL DEFAULT '',
  `cf_connect_skin` varchar(255) NOT NULL DEFAULT '',
  `cf_faq_skin` varchar(255) NOT NULL DEFAULT '',
  `cf_read_point` int(11) NOT NULL DEFAULT '0',
  `cf_write_point` int(11) NOT NULL DEFAULT '0',
  `cf_comment_point` int(11) NOT NULL DEFAULT '0',
  `cf_download_point` int(11) NOT NULL DEFAULT '0',
  `cf_write_pages` int(11) NOT NULL DEFAULT '0',
  `cf_mobile_pages` int(11) NOT NULL DEFAULT '0',
  `cf_link_target` varchar(255) NOT NULL DEFAULT '',
  `cf_delay_sec` int(11) NOT NULL DEFAULT '0',
  `cf_filter` text NOT NULL,
  `cf_possible_ip` text NOT NULL,
  `cf_intercept_ip` text NOT NULL,
  `cf_analytics` text NOT NULL,
  `cf_add_meta` text NOT NULL,
  `cf_syndi_token` varchar(255) NOT NULL,
  `cf_syndi_except` text NOT NULL,
  `cf_member_skin` varchar(255) NOT NULL DEFAULT '',
  `cf_use_homepage` tinyint(4) NOT NULL DEFAULT '0',
  `cf_req_homepage` tinyint(4) NOT NULL DEFAULT '0',
  `cf_use_tel` tinyint(4) NOT NULL DEFAULT '0',
  `cf_req_tel` tinyint(4) NOT NULL DEFAULT '0',
  `cf_use_hp` tinyint(4) NOT NULL DEFAULT '0',
  `cf_req_hp` tinyint(4) NOT NULL DEFAULT '0',
  `cf_use_addr` tinyint(4) NOT NULL DEFAULT '0',
  `cf_req_addr` tinyint(4) NOT NULL DEFAULT '0',
  `cf_use_signature` tinyint(4) NOT NULL DEFAULT '0',
  `cf_req_signature` tinyint(4) NOT NULL DEFAULT '0',
  `cf_use_profile` tinyint(4) NOT NULL DEFAULT '0',
  `cf_req_profile` tinyint(4) NOT NULL DEFAULT '0',
  `cf_register_level` tinyint(4) NOT NULL DEFAULT '0',
  `cf_register_point` int(11) NOT NULL DEFAULT '0',
  `cf_icon_level` tinyint(4) NOT NULL DEFAULT '0',
  `cf_use_recommend` tinyint(4) NOT NULL DEFAULT '0',
  `cf_recommend_point` int(11) NOT NULL DEFAULT '0',
  `cf_leave_day` int(11) NOT NULL DEFAULT '0',
  `cf_search_part` int(11) NOT NULL DEFAULT '0',
  `cf_email_use` tinyint(4) NOT NULL DEFAULT '0',
  `cf_email_wr_super_admin` tinyint(4) NOT NULL DEFAULT '0',
  `cf_email_wr_group_admin` tinyint(4) NOT NULL DEFAULT '0',
  `cf_email_wr_board_admin` tinyint(4) NOT NULL DEFAULT '0',
  `cf_email_wr_write` tinyint(4) NOT NULL DEFAULT '0',
  `cf_email_wr_comment_all` tinyint(4) NOT NULL DEFAULT '0',
  `cf_email_mb_super_admin` tinyint(4) NOT NULL DEFAULT '0',
  `cf_email_mb_member` tinyint(4) NOT NULL DEFAULT '0',
  `cf_email_po_super_admin` tinyint(4) NOT NULL DEFAULT '0',
  `cf_prohibit_id` text NOT NULL,
  `cf_prohibit_email` text NOT NULL,
  `cf_new_del` int(11) NOT NULL DEFAULT '0',
  `cf_memo_del` int(11) NOT NULL DEFAULT '0',
  `cf_visit_del` int(11) NOT NULL DEFAULT '0',
  `cf_popular_del` int(11) NOT NULL DEFAULT '0',
  `cf_optimize_date` date NOT NULL DEFAULT '0000-00-00',
  `cf_use_member_icon` tinyint(4) NOT NULL DEFAULT '0',
  `cf_member_icon_size` int(11) NOT NULL DEFAULT '0',
  `cf_member_icon_width` int(11) NOT NULL DEFAULT '0',
  `cf_member_icon_height` int(11) NOT NULL DEFAULT '0',
  `cf_member_img_size` int(11) NOT NULL DEFAULT '0',
  `cf_member_img_width` int(11) NOT NULL DEFAULT '0',
  `cf_member_img_height` int(11) NOT NULL DEFAULT '0',
  `cf_login_minutes` int(11) NOT NULL DEFAULT '0',
  `cf_image_extension` varchar(255) NOT NULL DEFAULT '',
  `cf_flash_extension` varchar(255) NOT NULL DEFAULT '',
  `cf_movie_extension` varchar(255) NOT NULL DEFAULT '',
  `cf_formmail_is_member` tinyint(4) NOT NULL DEFAULT '0',
  `cf_page_rows` int(11) NOT NULL DEFAULT '0',
  `cf_mobile_page_rows` int(11) NOT NULL DEFAULT '0',
  `cf_visit` varchar(255) NOT NULL DEFAULT '',
  `cf_max_po_id` int(11) NOT NULL DEFAULT '0',
  `cf_stipulation` text NOT NULL,
  `cf_privacy` text NOT NULL,
  `cf_open_modify` int(11) NOT NULL DEFAULT '0',
  `cf_memo_send_point` int(11) NOT NULL DEFAULT '0',
  `cf_mobile_new_skin` varchar(255) NOT NULL DEFAULT '',
  `cf_mobile_search_skin` varchar(255) NOT NULL DEFAULT '',
  `cf_mobile_connect_skin` varchar(255) NOT NULL DEFAULT '',
  `cf_mobile_faq_skin` varchar(255) NOT NULL DEFAULT '',
  `cf_mobile_member_skin` varchar(255) NOT NULL DEFAULT '',
  `cf_captcha_mp3` varchar(255) NOT NULL DEFAULT '',
  `cf_editor` varchar(255) NOT NULL DEFAULT '',
  `cf_cert_use` tinyint(4) NOT NULL DEFAULT '0',
  `cf_cert_ipin` varchar(255) NOT NULL DEFAULT '',
  `cf_cert_hp` varchar(255) NOT NULL DEFAULT '',
  `cf_cert_kcb_cd` varchar(255) NOT NULL DEFAULT '',
  `cf_cert_kcp_cd` varchar(255) NOT NULL DEFAULT '',
  `cf_lg_mid` varchar(255) NOT NULL DEFAULT '',
  `cf_lg_mert_key` varchar(255) NOT NULL DEFAULT '',
  `cf_cert_limit` int(11) NOT NULL DEFAULT '0',
  `cf_cert_req` tinyint(4) NOT NULL DEFAULT '0',
  `cf_sms_use` varchar(255) NOT NULL DEFAULT '',
  `cf_sms_type` varchar(10) NOT NULL DEFAULT '',
  `cf_icode_id` varchar(255) NOT NULL DEFAULT '',
  `cf_icode_pw` varchar(255) NOT NULL DEFAULT '',
  `cf_icode_server_ip` varchar(255) NOT NULL DEFAULT '',
  `cf_icode_server_port` varchar(255) NOT NULL DEFAULT '',
  `cf_googl_shorturl_apikey` varchar(255) NOT NULL DEFAULT '',
  `cf_social_login_use` tinyint(4) NOT NULL DEFAULT '0',
  `cf_social_servicelist` varchar(255) NOT NULL DEFAULT '',
  `cf_payco_clientid` varchar(100) NOT NULL DEFAULT '',
  `cf_payco_secret` varchar(100) NOT NULL DEFAULT '',
  `cf_facebook_appid` varchar(255) NOT NULL,
  `cf_facebook_secret` varchar(255) NOT NULL,
  `cf_twitter_key` varchar(255) NOT NULL,
  `cf_twitter_secret` varchar(255) NOT NULL,
  `cf_google_clientid` varchar(100) NOT NULL DEFAULT '',
  `cf_google_secret` varchar(100) NOT NULL DEFAULT '',
  `cf_naver_clientid` varchar(100) NOT NULL DEFAULT '',
  `cf_naver_secret` varchar(100) NOT NULL DEFAULT '',
  `cf_kakao_rest_key` varchar(100) NOT NULL DEFAULT '',
  `cf_kakao_client_secret` varchar(100) NOT NULL DEFAULT '',
  `cf_kakao_js_apikey` varchar(255) NOT NULL,
  `cf_captcha` varchar(100) NOT NULL DEFAULT '',
  `cf_recaptcha_site_key` varchar(100) NOT NULL DEFAULT '',
  `cf_recaptcha_secret_key` varchar(100) NOT NULL DEFAULT '',
  `cf_1_subj` varchar(255) NOT NULL DEFAULT '',
  `cf_2_subj` varchar(255) NOT NULL DEFAULT '',
  `cf_3_subj` varchar(255) NOT NULL DEFAULT '',
  `cf_4_subj` varchar(255) NOT NULL DEFAULT '',
  `cf_5_subj` varchar(255) NOT NULL DEFAULT '',
  `cf_6_subj` varchar(255) NOT NULL DEFAULT '',
  `cf_7_subj` varchar(255) NOT NULL DEFAULT '',
  `cf_8_subj` varchar(255) NOT NULL DEFAULT '',
  `cf_9_subj` varchar(255) NOT NULL DEFAULT '',
  `cf_10_subj` varchar(255) NOT NULL DEFAULT '',
  `cf_1` varchar(255) NOT NULL DEFAULT '',
  `cf_2` varchar(255) NOT NULL DEFAULT '',
  `cf_3` varchar(255) NOT NULL DEFAULT '',
  `cf_4` varchar(255) NOT NULL DEFAULT '',
  `cf_5` varchar(255) NOT NULL DEFAULT '',
  `cf_6` varchar(255) NOT NULL DEFAULT '',
  `cf_7` varchar(255) NOT NULL DEFAULT '',
  `cf_8` varchar(255) NOT NULL DEFAULT '',
  `cf_9` varchar(255) NOT NULL DEFAULT '',
  `cf_10` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `g5_config`
--

INSERT INTO `g5_config` (`cf_title`, `cf_theme`, `cf_admin`, `cf_admin_email`, `cf_admin_email_name`, `cf_add_script`, `cf_use_point`, `cf_point_term`, `cf_use_copy_log`, `cf_use_email_certify`, `cf_login_point`, `cf_cut_name`, `cf_nick_modify`, `cf_new_skin`, `cf_new_rows`, `cf_search_skin`, `cf_connect_skin`, `cf_faq_skin`, `cf_read_point`, `cf_write_point`, `cf_comment_point`, `cf_download_point`, `cf_write_pages`, `cf_mobile_pages`, `cf_link_target`, `cf_delay_sec`, `cf_filter`, `cf_possible_ip`, `cf_intercept_ip`, `cf_analytics`, `cf_add_meta`, `cf_syndi_token`, `cf_syndi_except`, `cf_member_skin`, `cf_use_homepage`, `cf_req_homepage`, `cf_use_tel`, `cf_req_tel`, `cf_use_hp`, `cf_req_hp`, `cf_use_addr`, `cf_req_addr`, `cf_use_signature`, `cf_req_signature`, `cf_use_profile`, `cf_req_profile`, `cf_register_level`, `cf_register_point`, `cf_icon_level`, `cf_use_recommend`, `cf_recommend_point`, `cf_leave_day`, `cf_search_part`, `cf_email_use`, `cf_email_wr_super_admin`, `cf_email_wr_group_admin`, `cf_email_wr_board_admin`, `cf_email_wr_write`, `cf_email_wr_comment_all`, `cf_email_mb_super_admin`, `cf_email_mb_member`, `cf_email_po_super_admin`, `cf_prohibit_id`, `cf_prohibit_email`, `cf_new_del`, `cf_memo_del`, `cf_visit_del`, `cf_popular_del`, `cf_optimize_date`, `cf_use_member_icon`, `cf_member_icon_size`, `cf_member_icon_width`, `cf_member_icon_height`, `cf_member_img_size`, `cf_member_img_width`, `cf_member_img_height`, `cf_login_minutes`, `cf_image_extension`, `cf_flash_extension`, `cf_movie_extension`, `cf_formmail_is_member`, `cf_page_rows`, `cf_mobile_page_rows`, `cf_visit`, `cf_max_po_id`, `cf_stipulation`, `cf_privacy`, `cf_open_modify`, `cf_memo_send_point`, `cf_mobile_new_skin`, `cf_mobile_search_skin`, `cf_mobile_connect_skin`, `cf_mobile_faq_skin`, `cf_mobile_member_skin`, `cf_captcha_mp3`, `cf_editor`, `cf_cert_use`, `cf_cert_ipin`, `cf_cert_hp`, `cf_cert_kcb_cd`, `cf_cert_kcp_cd`, `cf_lg_mid`, `cf_lg_mert_key`, `cf_cert_limit`, `cf_cert_req`, `cf_sms_use`, `cf_sms_type`, `cf_icode_id`, `cf_icode_pw`, `cf_icode_server_ip`, `cf_icode_server_port`, `cf_googl_shorturl_apikey`, `cf_social_login_use`, `cf_social_servicelist`, `cf_payco_clientid`, `cf_payco_secret`, `cf_facebook_appid`, `cf_facebook_secret`, `cf_twitter_key`, `cf_twitter_secret`, `cf_google_clientid`, `cf_google_secret`, `cf_naver_clientid`, `cf_naver_secret`, `cf_kakao_rest_key`, `cf_kakao_client_secret`, `cf_kakao_js_apikey`, `cf_captcha`, `cf_recaptcha_site_key`, `cf_recaptcha_secret_key`, `cf_1_subj`, `cf_2_subj`, `cf_3_subj`, `cf_4_subj`, `cf_5_subj`, `cf_6_subj`, `cf_7_subj`, `cf_8_subj`, `cf_9_subj`, `cf_10_subj`, `cf_1`, `cf_2`, `cf_3`, `cf_4`, `cf_5`, `cf_6`, `cf_7`, `cf_8`, `cf_9`, `cf_10`) VALUES
('김숙�\�� \우리옷', 'basic1st', 'admin', 'admin@domain.com', '그누보\드5', '', 0, 0, 1, 0, 100, 15, 60, 'basic', 15, 'basic', 'basic', 'basic', 0, 0, 0, 0, 10, 5, '_blank', 30, '18\아,18\놈,18\새끼,18\뇬,18\노,18것,18\넘,개년,개놈,개뇬,개새,개색끼,개세\끼,개세\이,개쉐이,개쉑,개쉽,개시키,개자식,개�\��,게색기,게색끼,광뇬,\뇬,\눈�\��,\뉘미\럴,\니�\��미,\니기�\�,\니미,\도촬,\되�\��래,\뒈져\라,\뒈�\��다,\디져\라,\디�\��다,\디�\��래,병쉰,병신,뻐큐,뻑큐,뽁큐,\삐리\넷,\새�\��,\쉬발,\쉬�\�,\쉬\팔,\쉽\알,\스\패\킹,\스\팽,\시�\��,\시�\��랄,\시�\��럴,\시�\��리,\시�\��,\시�\��랄,\시팍,\시팔,\시펄,\실�\�,\십8,\십\쌔,\십�\�,\싶\알,\쌉년,\썅놈,\쌔끼,\쌩\쑈,\썅,\써벌,\썩\을년,\쎄�\��,\쎄엑,\쓰바,\쓰발,\쓰벌,\쓰\팔,\씨8,\씨\댕,\씨바,\씨발,\씨뱅,\씨봉알,\씨부랄,\씨부럴,\씨부렁,\씨부리,\씨불,\씨브랄,\씨빠,\씨�\�,\씨뽀랄,\씨\팍,\씨\팔,\씨\펄,\씹,\아�\��리,\아�\��이,\엄창,\접년,\잡\놈,\재\랄,\저주글,조�\��,조�\��,조쟁이,조�\��냐,조�\��다,조�\��래,존나,존니,좀물,좁년,좃,좆,좇,쥐랄,쥐롤,쥬디,지랄,지럴,지롤,지미\랄,쫍빱,\凸,\퍽\큐,뻑큐,빠큐,\ㅅㅂㄹ\ㅁ', '', '', '', '', '', '', 'basic', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1000, 2, 0, 0, 30, 10000, 1, 0, 0, 0, 0, 0, 0, 0, 0, 'admin,administrator,관리\자,\운\영자,\어\드민,주인\장,webmaster,\웹마스\터,sysop,\시삽,\시샵,manager,매니저,메니저,root,루트,su,guest,방문객', '', 30, 180, 180, 180, '2019-08-30', 2, 5000, 22, 22, 50000, 60, 60, 10, 'gif|jpg|jpeg|png', 'swf', 'asx|asf|wmv|wma|mpg|mpeg|mov|avi|mp3', 1, 15, 15, '\오\늘:1,\어\제:4,최대:4,\전체:20', 0, '\해\당 \홈페이지에 맞는 \회원�\��입약관을 \입력\합\니다.', '\해\당 \홈페이지에 맞는 개인\정보처리방침\을 \입력\합\니다.', 0, 500, 'basic', 'basic', 'basic', 'basic', 'basic', 'basic', 'smarteditor2', 0, '', '', '', '', '', '', 2, 0, '', '', '', '', '211.172.232.124', '7295', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'kcaptcha', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_content`
--

CREATE TABLE `g5_content` (
  `co_id` varchar(20) NOT NULL DEFAULT '',
  `co_html` tinyint(4) NOT NULL DEFAULT '0',
  `co_subject` varchar(255) NOT NULL DEFAULT '',
  `co_content` longtext NOT NULL,
  `co_mobile_content` longtext NOT NULL,
  `co_skin` varchar(255) NOT NULL DEFAULT '',
  `co_mobile_skin` varchar(255) NOT NULL DEFAULT '',
  `co_tag_filter_use` tinyint(4) NOT NULL DEFAULT '0',
  `co_hit` int(11) NOT NULL DEFAULT '0',
  `co_include_head` varchar(255) NOT NULL,
  `co_include_tail` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `g5_content`
--

INSERT INTO `g5_content` (`co_id`, `co_html`, `co_subject`, `co_content`, `co_mobile_content`, `co_skin`, `co_mobile_skin`, `co_tag_filter_use`, `co_hit`, `co_include_head`, `co_include_tail`) VALUES
('company', 1, '\회사\소�\��', '<p align=\"center\"><b>\예�\���\���\��입니다.</b></p>', '', 'basic', 'basic', 1, 0, '', ''),
('privacy', 1, '개인\정보 처리방침', '<p align=center><b>개인\정보 처리방침\에 \대한 \내\용\을 \입력\하십\시오.</b></p>', '', '', '', 0, 0, '', ''),
('provision', 1, '\서�\��스 \이\용\약관', '<p align=center><b>\서�\��스 \이\용\약관에 \대한 \내\용\을 \입력\하십\시오.</b></p>', '', '', '', 0, 0, '', ''),
('location', 1, '\오\시는 �\�', '<a href=\"https://map.kakao.com/?urlX=494890&amp;urlY=1132340&amp;urlLevel=3&amp;map_type=TYPE_MAP&amp;map_hybrid=false\" target=\"_blank\"><img width=\"504\" height=\"310\" src=\"https://map2.daum.net/map/mapservice?FORMAT=PNG&amp;SCALE=2.5&amp;MX=494890&amp;MY=1132340&amp;S=0&amp;IW=504&amp;IH=310&amp;LANG=0&amp;COORDSTM=WCONGNAMUL&amp;logo=kakao_logo\" style=\"border:1px solid #ccc\"></a><div class=\"hide\" style=\"overflow:hidden;padding:7px 11px;border:1px solid #dfdfdf;border-color:rgba(0,0,0,.1);border-radius:0 0 2px 2px;background-color:#f9f9f9;width:482px;\"><strong style=\"float: left;\"><img src=\"//t1.daumcdn.net/localimg/localimages/07/2018/pc/common/logo_kakaomap.png\" width=\"72\" height=\"16\" alt=\"카카\오�\�\"></strong><div style=\"float: right;position:relative\"><a style=\"font-size:12px;text-decoration:none;float:left;height:15px;padding-top:1px;line-height:15px;color:#000\" target=\"_blank\" href=\"https://map.kakao.com/?urlX=494890&amp;urlY=1132340&amp;urlLevel=3&amp;map_type=TYPE_MAP&amp;map_hybrid=false\">지도 \크게 보기</a></div></div>\r\n', '', 'basic', 'basic', 1, 0, '', ''),
('product', 1, '\제품소�\��', '<p>\제품소�\��</p>', '', 'basic', 'basic', 1, 0, '', ''),
('gallery', 1, '갤러�\�', '<p>갤러�\�<br></p>', '', 'basic', 'basic', 1, 0, '', ''),
('note', 1, '게시판 & 갤러�\�', '\ㅤ', '', 'basic', 'basic', 1, 0, '', ''),
('notice', 1, '게시판', '<p>\​�\��시판<br></p>', '', 'basic', 'basic', 1, 0, '', ''),
('design', 1, '\디자이\너 김숙�\��', '<p>\디자이\너 김숙�\��<br></p>', '', 'basic', 'basic', 1, 0, '', ''),
('way_1', 1, '\나아�\�� �\�', '<img src=\"http://art11010.dothome.co.kr/main/data/editor/1908/d9f54adc331be4431e67e7c57e76c180_1567043582_6208.png\" title=\"d9f54adc331be4431e67e7c57e76c180_1567043582_6208.png\"><br style=\"clear:both;\">', '', 'basic', 'basic', 1, 0, '', ''),
('way_2', 1, '걸어\온 �\�', '<img src=\"http://art11010.dothome.co.kr/main/data/editor/1908/d9f54adc331be4431e67e7c57e76c180_1567043629_2259.jpg\" title=\"d9f54adc331be4431e67e7c57e76c180_1567043629_2259.jpg\"><br style=\"clear:both;\"><br style=\"clear:both;\">', '', 'basic', 'basic', 1, 0, '', ''),
('clothes', 1, '\우�\� \옷 컬렉션', '<img src=\"http://art11010.dothome.co.kr/main/data/editor/1908/81fb8b362933e62db899598030598ad3_1566803431_2969.jpg\" title=\"81fb8b362933e62db899598030598ad3_1566803431_2969.jpg\" alt=\"81fb8b362933e62db899598030598ad3_1566803431_2969.jpg\"><br style=\"clear:both;\"><br style=\"clear:both;\">', '', 'basic', 'basic', 1, 0, '', ''),
('how_to_wear', 1, '\우�\� \옷 \입는 법', '<img src=\"http://art11010.dothome.co.kr/main/data/editor/1908/d9f54adc331be4431e67e7c57e76c180_1567043673_7064.jpg\" title=\"d9f54adc331be4431e67e7c57e76c180_1567043673_7064.jpg\"><br style=\"clear:both;\"><br style=\"clear:both;\">', '', 'basic', 'basic', 1, 0, '', ''),
('news_new', 1, '\뉴\스 & \새소식', '<img src=\"http://art11010.dothome.co.kr/main/data/editor/1908/779a565bf9c77d6185d03702698d0f4b_1566804676_9136.jpg\" title=\"779a565bf9c77d6185d03702698d0f4b_1566804676_9136.jpg\"><br style=\"clear:both;\"><br style=\"clear:both;\">', '', 'basic', 'basic', 1, 0, '', ''),
('way_3', 1, '\오\시는 �\�', '<img src=\"http://art11010.dothome.co.kr/main/data/editor/1908/d9f54adc331be4431e67e7c57e76c180_1567043784_1298.jpg\" title=\"d9f54adc331be4431e67e7c57e76c180_1567043784_1298.jpg\"><br style=\"clear:both;\"><br style=\"clear:both;\">', '', 'basic', 'basic', 1, 0, '', ''),
('instagram', 1, 'instagram', '<p>instagram<br></p>', '', 'basic', 'basic', 1, 0, '', ''),
('blog', 1, 'blog', '<p>blog<br></p>', '', 'basic', 'basic', 1, 0, '', ''),
('cafe', 1, 'cafe', '<p>cafe<br></p>', '', 'basic', 'basic', 1, 0, '', '');

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_faq`
--

CREATE TABLE `g5_faq` (
  `fa_id` int(11) NOT NULL,
  `fm_id` int(11) NOT NULL DEFAULT '0',
  `fa_subject` text NOT NULL,
  `fa_content` text NOT NULL,
  `fa_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_faq_master`
--

CREATE TABLE `g5_faq_master` (
  `fm_id` int(11) NOT NULL,
  `fm_subject` varchar(255) NOT NULL DEFAULT '',
  `fm_head_html` text NOT NULL,
  `fm_tail_html` text NOT NULL,
  `fm_mobile_head_html` text NOT NULL,
  `fm_mobile_tail_html` text NOT NULL,
  `fm_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `g5_faq_master`
--

INSERT INTO `g5_faq_master` (`fm_id`, `fm_subject`, `fm_head_html`, `fm_tail_html`, `fm_mobile_head_html`, `fm_mobile_tail_html`, `fm_order`) VALUES
(1, '\자주\하시는 질문', '', '', '', '', 0);

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_group`
--

CREATE TABLE `g5_group` (
  `gr_id` varchar(10) NOT NULL DEFAULT '',
  `gr_subject` varchar(255) NOT NULL DEFAULT '',
  `gr_device` enum('both','pc','mobile') NOT NULL DEFAULT 'both',
  `gr_admin` varchar(255) NOT NULL DEFAULT '',
  `gr_use_access` tinyint(4) NOT NULL DEFAULT '0',
  `gr_order` int(11) NOT NULL DEFAULT '0',
  `gr_1_subj` varchar(255) NOT NULL DEFAULT '',
  `gr_2_subj` varchar(255) NOT NULL DEFAULT '',
  `gr_3_subj` varchar(255) NOT NULL DEFAULT '',
  `gr_4_subj` varchar(255) NOT NULL DEFAULT '',
  `gr_5_subj` varchar(255) NOT NULL DEFAULT '',
  `gr_6_subj` varchar(255) NOT NULL DEFAULT '',
  `gr_7_subj` varchar(255) NOT NULL DEFAULT '',
  `gr_8_subj` varchar(255) NOT NULL DEFAULT '',
  `gr_9_subj` varchar(255) NOT NULL DEFAULT '',
  `gr_10_subj` varchar(255) NOT NULL DEFAULT '',
  `gr_1` varchar(255) NOT NULL DEFAULT '',
  `gr_2` varchar(255) NOT NULL DEFAULT '',
  `gr_3` varchar(255) NOT NULL DEFAULT '',
  `gr_4` varchar(255) NOT NULL DEFAULT '',
  `gr_5` varchar(255) NOT NULL DEFAULT '',
  `gr_6` varchar(255) NOT NULL DEFAULT '',
  `gr_7` varchar(255) NOT NULL DEFAULT '',
  `gr_8` varchar(255) NOT NULL DEFAULT '',
  `gr_9` varchar(255) NOT NULL DEFAULT '',
  `gr_10` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `g5_group`
--

INSERT INTO `g5_group` (`gr_id`, `gr_subject`, `gr_device`, `gr_admin`, `gr_use_access`, `gr_order`, `gr_1_subj`, `gr_2_subj`, `gr_3_subj`, `gr_4_subj`, `gr_5_subj`, `gr_6_subj`, `gr_7_subj`, `gr_8_subj`, `gr_9_subj`, `gr_10_subj`, `gr_1`, `gr_2`, `gr_3`, `gr_4`, `gr_5`, `gr_6`, `gr_7`, `gr_8`, `gr_9`, `gr_10`) VALUES
('community', '커뮤\니티', 'both', '', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_group_member`
--

CREATE TABLE `g5_group_member` (
  `gm_id` int(11) NOT NULL,
  `gr_id` varchar(255) NOT NULL DEFAULT '',
  `mb_id` varchar(20) NOT NULL DEFAULT '',
  `gm_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_login`
--

CREATE TABLE `g5_login` (
  `lo_ip` varchar(255) NOT NULL DEFAULT '',
  `mb_id` varchar(20) NOT NULL DEFAULT '',
  `lo_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lo_location` text NOT NULL,
  `lo_url` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `g5_login`
--

INSERT INTO `g5_login` (`lo_ip`, `mb_id`, `lo_datetime`, `lo_location`, `lo_url`) VALUES
('112.222.187.243', '', '2019-08-30 17:14:06', '김숙�\�� \우리옷', '/main/'),
('211.36.142.102', '', '2019-08-29 11:10:49', '김숙�\�� \우리옷', '/main/'),
('223.38.23.185', '', '2019-08-29 11:13:24', '\오\시는 �\�', '/main/bbs/content.php?co_id=way_3');

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_mail`
--

CREATE TABLE `g5_mail` (
  `ma_id` int(11) NOT NULL,
  `ma_subject` varchar(255) NOT NULL DEFAULT '',
  `ma_content` mediumtext NOT NULL,
  `ma_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ma_ip` varchar(255) NOT NULL DEFAULT '',
  `ma_last_option` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_member`
--

CREATE TABLE `g5_member` (
  `mb_no` int(11) NOT NULL,
  `mb_id` varchar(20) NOT NULL DEFAULT '',
  `mb_password` varchar(255) NOT NULL DEFAULT '',
  `mb_name` varchar(255) NOT NULL DEFAULT '',
  `mb_nick` varchar(255) NOT NULL DEFAULT '',
  `mb_nick_date` date NOT NULL DEFAULT '0000-00-00',
  `mb_email` varchar(255) NOT NULL DEFAULT '',
  `mb_homepage` varchar(255) NOT NULL DEFAULT '',
  `mb_level` tinyint(4) NOT NULL DEFAULT '0',
  `mb_sex` char(1) NOT NULL DEFAULT '',
  `mb_birth` varchar(255) NOT NULL DEFAULT '',
  `mb_tel` varchar(255) NOT NULL DEFAULT '',
  `mb_hp` varchar(255) NOT NULL DEFAULT '',
  `mb_certify` varchar(20) NOT NULL DEFAULT '',
  `mb_adult` tinyint(4) NOT NULL DEFAULT '0',
  `mb_dupinfo` varchar(255) NOT NULL DEFAULT '',
  `mb_zip1` char(3) NOT NULL DEFAULT '',
  `mb_zip2` char(3) NOT NULL DEFAULT '',
  `mb_addr1` varchar(255) NOT NULL DEFAULT '',
  `mb_addr2` varchar(255) NOT NULL DEFAULT '',
  `mb_addr3` varchar(255) NOT NULL DEFAULT '',
  `mb_addr_jibeon` varchar(255) NOT NULL DEFAULT '',
  `mb_signature` text NOT NULL,
  `mb_recommend` varchar(255) NOT NULL DEFAULT '',
  `mb_point` int(11) NOT NULL DEFAULT '0',
  `mb_today_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `mb_login_ip` varchar(255) NOT NULL DEFAULT '',
  `mb_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `mb_ip` varchar(255) NOT NULL DEFAULT '',
  `mb_leave_date` varchar(8) NOT NULL DEFAULT '',
  `mb_intercept_date` varchar(8) NOT NULL DEFAULT '',
  `mb_email_certify` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `mb_email_certify2` varchar(255) NOT NULL DEFAULT '',
  `mb_memo` text NOT NULL,
  `mb_lost_certify` varchar(255) NOT NULL,
  `mb_mailling` tinyint(4) NOT NULL DEFAULT '0',
  `mb_sms` tinyint(4) NOT NULL DEFAULT '0',
  `mb_open` tinyint(4) NOT NULL DEFAULT '0',
  `mb_open_date` date NOT NULL DEFAULT '0000-00-00',
  `mb_profile` text NOT NULL,
  `mb_memo_call` varchar(255) NOT NULL DEFAULT '',
  `mb_1` varchar(255) NOT NULL DEFAULT '',
  `mb_2` varchar(255) NOT NULL DEFAULT '',
  `mb_3` varchar(255) NOT NULL DEFAULT '',
  `mb_4` varchar(255) NOT NULL DEFAULT '',
  `mb_5` varchar(255) NOT NULL DEFAULT '',
  `mb_6` varchar(255) NOT NULL DEFAULT '',
  `mb_7` varchar(255) NOT NULL DEFAULT '',
  `mb_8` varchar(255) NOT NULL DEFAULT '',
  `mb_9` varchar(255) NOT NULL DEFAULT '',
  `mb_10` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `g5_member`
--

INSERT INTO `g5_member` (`mb_no`, `mb_id`, `mb_password`, `mb_name`, `mb_nick`, `mb_nick_date`, `mb_email`, `mb_homepage`, `mb_level`, `mb_sex`, `mb_birth`, `mb_tel`, `mb_hp`, `mb_certify`, `mb_adult`, `mb_dupinfo`, `mb_zip1`, `mb_zip2`, `mb_addr1`, `mb_addr2`, `mb_addr3`, `mb_addr_jibeon`, `mb_signature`, `mb_recommend`, `mb_point`, `mb_today_login`, `mb_login_ip`, `mb_datetime`, `mb_ip`, `mb_leave_date`, `mb_intercept_date`, `mb_email_certify`, `mb_email_certify2`, `mb_memo`, `mb_lost_certify`, `mb_mailling`, `mb_sms`, `mb_open`, `mb_open_date`, `mb_profile`, `mb_memo_call`, `mb_1`, `mb_2`, `mb_3`, `mb_4`, `mb_5`, `mb_6`, `mb_7`, `mb_8`, `mb_9`, `mb_10`) VALUES
(1, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', '최�\���\��리\자', '0000-00-00', 'admin@domain.com', '', 10, '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', 100, '2019-08-30 13:47:56', '112.222.187.243', '2019-07-18 13:32:03', '112.222.187.243', '', '', '2019-07-18 13:32:03', '', '', '', 1, 0, 1, '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_member_social_profiles`
--

CREATE TABLE `g5_member_social_profiles` (
  `mp_no` int(11) NOT NULL,
  `mb_id` varchar(255) NOT NULL DEFAULT '',
  `provider` varchar(50) NOT NULL DEFAULT '',
  `object_sha` varchar(45) NOT NULL DEFAULT '',
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `profileurl` varchar(255) NOT NULL DEFAULT '',
  `photourl` varchar(255) NOT NULL DEFAULT '',
  `displayname` varchar(150) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `mp_register_day` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `mp_latest_day` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_memo`
--

CREATE TABLE `g5_memo` (
  `me_id` int(11) NOT NULL DEFAULT '0',
  `me_recv_mb_id` varchar(20) NOT NULL DEFAULT '',
  `me_send_mb_id` varchar(20) NOT NULL DEFAULT '',
  `me_send_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `me_read_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `me_memo` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_menu`
--

CREATE TABLE `g5_menu` (
  `me_id` int(11) NOT NULL,
  `me_code` varchar(255) NOT NULL DEFAULT '',
  `me_name` varchar(255) NOT NULL DEFAULT '',
  `me_link` varchar(255) NOT NULL DEFAULT '',
  `me_target` varchar(255) NOT NULL DEFAULT '',
  `me_order` int(11) NOT NULL DEFAULT '0',
  `me_use` tinyint(4) NOT NULL DEFAULT '0',
  `me_mobile_use` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `g5_menu`
--

INSERT INTO `g5_menu` (`me_id`, `me_code`, `me_name`, `me_link`, `me_target`, `me_order`, `me_use`, `me_mobile_use`) VALUES
(454, '10', '\디자이\너 김숙�\��', 'http://art11010.dothome.co.kr/main/bbs/content.php?co_id=way_1', 'self', 0, 1, 1),
(455, '1010', '\나아�\�� �\�', 'http://art11010.dothome.co.kr/main/bbs/content.php?co_id=way_1', 'self', 0, 1, 1),
(456, '1020', '걸어\온 �\�', 'http://art11010.dothome.co.kr/main/bbs/content.php?co_id=way_2', 'self', 0, 1, 1),
(457, '20', '\우�\� \옷 컬렉션', 'http://art11010.dothome.co.kr/main/bbs/board.php?bo_table=gallery', 'self', 0, 1, 1),
(458, '30', '\우�\� \옷 \입는 법', 'http://art11010.dothome.co.kr/main/bbs/content.php?co_id=how_to_wear', 'self', 0, 1, 1),
(459, '40', '\뉴\스 & \새소식', 'http://art11010.dothome.co.kr/main/bbs/board.php?bo_table=notice', 'self', 0, 1, 1),
(460, '50', '\오\시는 �\�', 'http://art11010.dothome.co.kr/main/bbs/content.php?co_id=way_3', 'self', 0, 1, 1),
(461, '5010', '\오\시는 �\�', 'http://art11010.dothome.co.kr/main/bbs/content.php?co_id=way_3', 'self', 0, 1, 1),
(462, '5020', 'VISION', 'http://art11010.dothome.co.kr/main/theme/basic1st/vision.php', 'self', 0, 1, 1);

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_new_win`
--

CREATE TABLE `g5_new_win` (
  `nw_id` int(11) NOT NULL,
  `nw_device` varchar(10) NOT NULL DEFAULT 'both',
  `nw_begin_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `nw_end_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `nw_disable_hours` int(11) NOT NULL DEFAULT '0',
  `nw_left` int(11) NOT NULL DEFAULT '0',
  `nw_top` int(11) NOT NULL DEFAULT '0',
  `nw_height` int(11) NOT NULL DEFAULT '0',
  `nw_width` int(11) NOT NULL DEFAULT '0',
  `nw_subject` text NOT NULL,
  `nw_content` text NOT NULL,
  `nw_content_html` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_point`
--

CREATE TABLE `g5_point` (
  `po_id` int(11) NOT NULL,
  `mb_id` varchar(20) NOT NULL DEFAULT '',
  `po_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `po_content` varchar(255) NOT NULL DEFAULT '',
  `po_point` int(11) NOT NULL DEFAULT '0',
  `po_use_point` int(11) NOT NULL DEFAULT '0',
  `po_expired` tinyint(4) NOT NULL DEFAULT '0',
  `po_expire_date` date NOT NULL DEFAULT '0000-00-00',
  `po_mb_point` int(11) NOT NULL DEFAULT '0',
  `po_rel_table` varchar(20) NOT NULL DEFAULT '',
  `po_rel_id` varchar(20) NOT NULL DEFAULT '',
  `po_rel_action` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `g5_point`
--

INSERT INTO `g5_point` (`po_id`, `mb_id`, `po_datetime`, `po_content`, `po_point`, `po_use_point`, `po_expired`, `po_expire_date`, `po_mb_point`, `po_rel_table`, `po_rel_id`, `po_rel_action`) VALUES
(1, 'admin', '2019-07-18 13:33:21', '2019-07-18 첫�\��그\인', 100, 0, 0, '9999-12-31', 100, '@login', 'admin', '2019-07-18');

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_poll`
--

CREATE TABLE `g5_poll` (
  `po_id` int(11) NOT NULL,
  `po_subject` varchar(255) NOT NULL DEFAULT '',
  `po_poll1` varchar(255) NOT NULL DEFAULT '',
  `po_poll2` varchar(255) NOT NULL DEFAULT '',
  `po_poll3` varchar(255) NOT NULL DEFAULT '',
  `po_poll4` varchar(255) NOT NULL DEFAULT '',
  `po_poll5` varchar(255) NOT NULL DEFAULT '',
  `po_poll6` varchar(255) NOT NULL DEFAULT '',
  `po_poll7` varchar(255) NOT NULL DEFAULT '',
  `po_poll8` varchar(255) NOT NULL DEFAULT '',
  `po_poll9` varchar(255) NOT NULL DEFAULT '',
  `po_cnt1` int(11) NOT NULL DEFAULT '0',
  `po_cnt2` int(11) NOT NULL DEFAULT '0',
  `po_cnt3` int(11) NOT NULL DEFAULT '0',
  `po_cnt4` int(11) NOT NULL DEFAULT '0',
  `po_cnt5` int(11) NOT NULL DEFAULT '0',
  `po_cnt6` int(11) NOT NULL DEFAULT '0',
  `po_cnt7` int(11) NOT NULL DEFAULT '0',
  `po_cnt8` int(11) NOT NULL DEFAULT '0',
  `po_cnt9` int(11) NOT NULL DEFAULT '0',
  `po_etc` varchar(255) NOT NULL DEFAULT '',
  `po_level` tinyint(4) NOT NULL DEFAULT '0',
  `po_point` int(11) NOT NULL DEFAULT '0',
  `po_date` date NOT NULL DEFAULT '0000-00-00',
  `po_ips` mediumtext NOT NULL,
  `mb_ids` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_poll_etc`
--

CREATE TABLE `g5_poll_etc` (
  `pc_id` int(11) NOT NULL DEFAULT '0',
  `po_id` int(11) NOT NULL DEFAULT '0',
  `mb_id` varchar(20) NOT NULL DEFAULT '',
  `pc_name` varchar(255) NOT NULL DEFAULT '',
  `pc_idea` varchar(255) NOT NULL DEFAULT '',
  `pc_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_popular`
--

CREATE TABLE `g5_popular` (
  `pp_id` int(11) NOT NULL,
  `pp_word` varchar(50) NOT NULL DEFAULT '',
  `pp_date` date NOT NULL DEFAULT '0000-00-00',
  `pp_ip` varchar(50) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_qa_config`
--

CREATE TABLE `g5_qa_config` (
  `qa_title` varchar(255) NOT NULL DEFAULT '',
  `qa_category` varchar(255) NOT NULL DEFAULT '',
  `qa_skin` varchar(255) NOT NULL DEFAULT '',
  `qa_mobile_skin` varchar(255) NOT NULL DEFAULT '',
  `qa_use_email` tinyint(4) NOT NULL DEFAULT '0',
  `qa_req_email` tinyint(4) NOT NULL DEFAULT '0',
  `qa_use_hp` tinyint(4) NOT NULL DEFAULT '0',
  `qa_req_hp` tinyint(4) NOT NULL DEFAULT '0',
  `qa_use_sms` tinyint(4) NOT NULL DEFAULT '0',
  `qa_send_number` varchar(255) NOT NULL DEFAULT '0',
  `qa_admin_hp` varchar(255) NOT NULL DEFAULT '',
  `qa_admin_email` varchar(255) NOT NULL DEFAULT '',
  `qa_use_editor` tinyint(4) NOT NULL DEFAULT '0',
  `qa_subject_len` int(11) NOT NULL DEFAULT '0',
  `qa_mobile_subject_len` int(11) NOT NULL DEFAULT '0',
  `qa_page_rows` int(11) NOT NULL DEFAULT '0',
  `qa_mobile_page_rows` int(11) NOT NULL DEFAULT '0',
  `qa_image_width` int(11) NOT NULL DEFAULT '0',
  `qa_upload_size` int(11) NOT NULL DEFAULT '0',
  `qa_insert_content` text NOT NULL,
  `qa_include_head` varchar(255) NOT NULL DEFAULT '',
  `qa_include_tail` varchar(255) NOT NULL DEFAULT '',
  `qa_content_head` text NOT NULL,
  `qa_content_tail` text NOT NULL,
  `qa_mobile_content_head` text NOT NULL,
  `qa_mobile_content_tail` text NOT NULL,
  `qa_1_subj` varchar(255) NOT NULL DEFAULT '',
  `qa_2_subj` varchar(255) NOT NULL DEFAULT '',
  `qa_3_subj` varchar(255) NOT NULL DEFAULT '',
  `qa_4_subj` varchar(255) NOT NULL DEFAULT '',
  `qa_5_subj` varchar(255) NOT NULL DEFAULT '',
  `qa_1` varchar(255) NOT NULL DEFAULT '',
  `qa_2` varchar(255) NOT NULL DEFAULT '',
  `qa_3` varchar(255) NOT NULL DEFAULT '',
  `qa_4` varchar(255) NOT NULL DEFAULT '',
  `qa_5` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `g5_qa_config`
--

INSERT INTO `g5_qa_config` (`qa_title`, `qa_category`, `qa_skin`, `qa_mobile_skin`, `qa_use_email`, `qa_req_email`, `qa_use_hp`, `qa_req_hp`, `qa_use_sms`, `qa_send_number`, `qa_admin_hp`, `qa_admin_email`, `qa_use_editor`, `qa_subject_len`, `qa_mobile_subject_len`, `qa_page_rows`, `qa_mobile_page_rows`, `qa_image_width`, `qa_upload_size`, `qa_insert_content`, `qa_include_head`, `qa_include_tail`, `qa_content_head`, `qa_content_tail`, `qa_mobile_content_head`, `qa_mobile_content_tail`, `qa_1_subj`, `qa_2_subj`, `qa_3_subj`, `qa_4_subj`, `qa_5_subj`, `qa_1`, `qa_2`, `qa_3`, `qa_4`, `qa_5`) VALUES
('1:1문의', '\회원|\포\인\트', 'basic', 'basic', 1, 0, 1, 0, 0, '0', '', '', 1, 60, 30, 15, 15, 600, 1048576, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_qa_content`
--

CREATE TABLE `g5_qa_content` (
  `qa_id` int(11) NOT NULL,
  `qa_num` int(11) NOT NULL DEFAULT '0',
  `qa_parent` int(11) NOT NULL DEFAULT '0',
  `qa_related` int(11) NOT NULL DEFAULT '0',
  `mb_id` varchar(20) NOT NULL DEFAULT '',
  `qa_name` varchar(255) NOT NULL DEFAULT '',
  `qa_email` varchar(255) NOT NULL DEFAULT '',
  `qa_hp` varchar(255) NOT NULL DEFAULT '',
  `qa_type` tinyint(4) NOT NULL DEFAULT '0',
  `qa_category` varchar(255) NOT NULL DEFAULT '',
  `qa_email_recv` tinyint(4) NOT NULL DEFAULT '0',
  `qa_sms_recv` tinyint(4) NOT NULL DEFAULT '0',
  `qa_html` tinyint(4) NOT NULL DEFAULT '0',
  `qa_subject` varchar(255) NOT NULL DEFAULT '',
  `qa_content` text NOT NULL,
  `qa_status` tinyint(4) NOT NULL DEFAULT '0',
  `qa_file1` varchar(255) NOT NULL DEFAULT '',
  `qa_source1` varchar(255) NOT NULL DEFAULT '',
  `qa_file2` varchar(255) NOT NULL DEFAULT '',
  `qa_source2` varchar(255) NOT NULL DEFAULT '',
  `qa_ip` varchar(255) NOT NULL DEFAULT '',
  `qa_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `qa_1` varchar(255) NOT NULL DEFAULT '',
  `qa_2` varchar(255) NOT NULL DEFAULT '',
  `qa_3` varchar(255) NOT NULL DEFAULT '',
  `qa_4` varchar(255) NOT NULL DEFAULT '',
  `qa_5` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_scrap`
--

CREATE TABLE `g5_scrap` (
  `ms_id` int(11) NOT NULL,
  `mb_id` varchar(20) NOT NULL DEFAULT '',
  `bo_table` varchar(20) NOT NULL DEFAULT '',
  `wr_id` varchar(15) NOT NULL DEFAULT '',
  `ms_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_uniqid`
--

CREATE TABLE `g5_uniqid` (
  `uq_id` bigint(20) UNSIGNED NOT NULL,
  `uq_ip` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `g5_uniqid`
--

INSERT INTO `g5_uniqid` (`uq_id`, `uq_ip`) VALUES
(2019071813450565, '112.222.187.243'),
(2019072414582212, '112.222.187.243'),
(2019072414584678, '112.222.187.243'),
(2019072414590165, '112.222.187.243'),
(2019072414592066, '112.222.187.243'),
(2019072414595609, '112.222.187.243'),
(2019082714122341, '112.222.187.243'),
(2019082714204633, '112.222.187.243'),
(2019082714221793, '112.222.187.243'),
(2019082714335891, '112.222.187.243'),
(2019082714360228, '112.222.187.243'),
(2019082714361943, '112.222.187.243'),
(2019082714362785, '112.222.187.243'),
(2019082714364820, '112.222.187.243'),
(2019082714381454, '112.222.187.243'),
(2019082714383663, '112.222.187.243'),
(2019082714390610, '112.222.187.243'),
(2019082714413467, '112.222.187.243'),
(2019082714414832, '112.222.187.243'),
(2019082714420663, '112.222.187.243'),
(2019082714421753, '112.222.187.243'),
(2019082714425161, '112.222.187.243'),
(2019082714430542, '112.222.187.243'),
(2019082714452446, '112.222.187.243'),
(2019082714454346, '112.222.187.243'),
(2019082714460610, '112.222.187.243'),
(2019082714462277, '112.222.187.243'),
(2019082714464117, '112.222.187.243'),
(2019082714465185, '112.222.187.243'),
(2019082714470290, '112.222.187.243'),
(2019082714471389, '112.222.187.243'),
(2019082714473718, '112.222.187.243'),
(2019082714475742, '112.222.187.243'),
(2019082714490886, '112.222.187.243'),
(2019082714512802, '112.222.187.243'),
(2019082714515133, '112.222.187.243'),
(2019082714524273, '112.222.187.243'),
(2019082714531606, '112.222.187.243'),
(2019082714534660, '112.222.187.243'),
(2019082714535133, '112.222.187.243'),
(2019082714540643, '112.222.187.243'),
(2019082714541751, '112.222.187.243'),
(2019082714543114, '112.222.187.243'),
(2019082714544402, '112.222.187.243'),
(2019082714550800, '112.222.187.243'),
(2019082714552019, '112.222.187.243'),
(2019082714553294, '112.222.187.243'),
(2019082714554482, '112.222.187.243'),
(2019082714561447, '112.222.187.243'),
(2019082714563400, '112.222.187.243'),
(2019082714564764, '112.222.187.243'),
(2019082714573433, '112.222.187.243'),
(2019082714575599, '112.222.187.243'),
(2019082714580743, '112.222.187.243'),
(2019082714582450, '112.222.187.243'),
(2019082714583867, '112.222.187.243'),
(2019082714585551, '112.222.187.243'),
(2019082714590606, '112.222.187.243'),
(2019082714591795, '112.222.187.243'),
(2019082714592930, '112.222.187.243'),
(2019082714594140, '112.222.187.243'),
(2019082715000484, '112.222.187.243'),
(2019082715001570, '112.222.187.243'),
(2019082715002752, '112.222.187.243'),
(2019082717013358, '112.222.187.243'),
(2019082717061682, '112.222.187.243'),
(2019082717070046, '112.222.187.243'),
(2019082717072665, '112.222.187.243'),
(2019082717075073, '112.222.187.243'),
(2019082717080301, '112.222.187.243'),
(2019082717082139, '112.222.187.243'),
(2019082717083860, '112.222.187.243'),
(2019082717120026, '112.222.187.243'),
(2019082717122274, '112.222.187.243'),
(2019082717132865, '112.222.187.243'),
(2019082717144918, '112.222.187.243'),
(2019082717151070, '112.222.187.243'),
(2019082717163249, '112.222.187.243'),
(2019082717171289, '112.222.187.243'),
(2019082717175941, '112.222.187.243'),
(2019082717184279, '112.222.187.243'),
(2019082717193142, '112.222.187.243'),
(2019082717202733, '112.222.187.243'),
(2019082717213643, '112.222.187.243'),
(2019082817505861, '112.222.187.243'),
(2019082817540829, '112.222.187.243'),
(2019082817541463, '112.222.187.243'),
(2019082817555224, '112.222.187.243'),
(2019082817560913, '112.222.187.243'),
(2019082817562304, '112.222.187.243'),
(2019082817563910, '112.222.187.243'),
(2019082817573259, '112.222.187.243'),
(2019082817580222, '112.222.187.243'),
(2019082817581910, '112.222.187.243'),
(2019082817583593, '112.222.187.243'),
(2019082817585232, '112.222.187.243'),
(2019082817591281, '112.222.187.243'),
(2019082817592579, '112.222.187.243'),
(2019082817593987, '112.222.187.243'),
(2019082817595453, '112.222.187.243'),
(2019082818000877, '112.222.187.243'),
(2019082818002753, '112.222.187.243'),
(2019082818003952, '112.222.187.243'),
(2019082818005505, '112.222.187.243'),
(2019083013530594, '112.222.187.243'),
(2019083013553707, '112.222.187.243');

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_visit`
--

CREATE TABLE `g5_visit` (
  `vi_id` int(11) NOT NULL DEFAULT '0',
  `vi_ip` varchar(255) NOT NULL DEFAULT '',
  `vi_date` date NOT NULL DEFAULT '0000-00-00',
  `vi_time` time NOT NULL DEFAULT '00:00:00',
  `vi_referer` text NOT NULL,
  `vi_agent` varchar(255) NOT NULL DEFAULT '',
  `vi_browser` varchar(255) NOT NULL DEFAULT '',
  `vi_os` varchar(255) NOT NULL DEFAULT '',
  `vi_device` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `g5_visit`
--

INSERT INTO `g5_visit` (`vi_id`, `vi_ip`, `vi_date`, `vi_time`, `vi_referer`, `vi_agent`, `vi_browser`, `vi_os`, `vi_device`) VALUES
(1, '112.222.187.243', '2019-07-22', '13:18:12', '', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '', '', ''),
(2, '112.222.187.243', '2019-07-23', '13:29:29', '', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '', '', ''),
(3, '112.222.187.243', '2019-07-24', '14:27:27', '', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '', '', ''),
(4, '112.222.187.243', '2019-07-25', '14:29:01', '', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '', '', ''),
(5, '112.222.187.243', '2019-07-30', '14:19:08', '', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '', '', ''),
(6, '112.222.187.243', '2019-07-31', '16:23:46', '', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '', '', ''),
(7, '112.222.187.243', '2019-08-19', '14:33:13', '', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '', '', ''),
(8, '112.222.187.243', '2019-08-20', '14:33:55', 'http://art11010.dothome.co.kr/main/', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '', '', ''),
(9, '112.222.187.243', '2019-08-21', '15:11:05', 'http://art11010.dothome.co.kr/main/bbs/content.php?co_id=Bidanhyang', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '', '', ''),
(10, '112.222.187.243', '2019-08-22', '15:27:28', 'http://art11010.dothome.co.kr/main/adm/menu_list.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '', '', ''),
(11, '223.38.17.246', '2019-08-25', '13:56:40', '', 'Mozilla/5.0 (iPhone; CPU iPhone OS 12_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.1.2 Mobile/15E148 Safari/604.1', '', '', ''),
(12, '112.222.187.243', '2019-08-26', '09:50:39', '', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '', '', ''),
(13, '112.222.187.243', '2019-08-27', '13:21:27', '', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '', '', ''),
(14, '218.38.90.34', '2019-08-28', '01:18:57', 'http://art11010.dothome.co.kr/main/', 'Mozilla/5.0 (iPhone; CPU iPhone OS 12_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.1.2 Mobile/15E148 Safari/604.1', '', '', ''),
(15, '112.222.187.243', '2019-08-28', '13:27:39', 'http://art11010.dothome.co.kr/main/theme/basic1st/vision.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '', '', ''),
(16, '211.231.103.91', '2019-08-29', '10:59:41', '', 'facebookexternalhit/1.1;kakaotalk-scrap/1.0; +https://devtalk.kakao.com/t/scrap/33984', '', '', ''),
(17, '211.36.142.102', '2019-08-29', '11:07:34', '', 'Mozilla/5.0 (Linux; Android 9; SM-G950N Build/PPR1.180610.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/76.0.3809.111 Mobile Safari/537.36;KAKAOTALK 1908510', '', '', ''),
(18, '223.38.23.185', '2019-08-29', '11:11:41', '', 'Mozilla/5.0 (iPhone; CPU iPhone OS 12_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 KAKAOTALK 8.5.2', '', '', ''),
(19, '112.222.187.243', '2019-08-29', '14:01:13', '', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', '', '', ''),
(20, '112.222.187.243', '2019-08-30', '14:01:41', 'http://art11010.dothome.co.kr/main/bbs/board.php?bo_table=gallery&wr_id=39', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', '', '', '');

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_visit_sum`
--

CREATE TABLE `g5_visit_sum` (
  `vs_date` date NOT NULL DEFAULT '0000-00-00',
  `vs_count` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `g5_visit_sum`
--

INSERT INTO `g5_visit_sum` (`vs_date`, `vs_count`) VALUES
('2019-07-22', 1),
('2019-07-23', 1),
('2019-07-24', 1),
('2019-07-25', 1),
('2019-07-30', 1),
('2019-07-31', 1),
('2019-08-19', 1),
('2019-08-20', 1),
('2019-08-21', 1),
('2019-08-22', 1),
('2019-08-25', 1),
('2019-08-26', 1),
('2019-08-27', 1),
('2019-08-28', 2),
('2019-08-29', 4),
('2019-08-30', 1);

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_write_freeboard`
--

CREATE TABLE `g5_write_freeboard` (
  `wr_id` int(11) NOT NULL,
  `wr_num` int(11) NOT NULL DEFAULT '0',
  `wr_reply` varchar(10) NOT NULL,
  `wr_parent` int(11) NOT NULL DEFAULT '0',
  `wr_is_comment` tinyint(4) NOT NULL DEFAULT '0',
  `wr_comment` int(11) NOT NULL DEFAULT '0',
  `wr_comment_reply` varchar(5) NOT NULL,
  `ca_name` varchar(255) NOT NULL,
  `wr_option` set('html1','html2','secret','mail') NOT NULL,
  `wr_subject` varchar(255) NOT NULL,
  `wr_content` text NOT NULL,
  `wr_link1` text NOT NULL,
  `wr_link2` text NOT NULL,
  `wr_link1_hit` int(11) NOT NULL DEFAULT '0',
  `wr_link2_hit` int(11) NOT NULL DEFAULT '0',
  `wr_hit` int(11) NOT NULL DEFAULT '0',
  `wr_good` int(11) NOT NULL DEFAULT '0',
  `wr_nogood` int(11) NOT NULL DEFAULT '0',
  `mb_id` varchar(20) NOT NULL,
  `wr_password` varchar(255) NOT NULL,
  `wr_name` varchar(255) NOT NULL,
  `wr_email` varchar(255) NOT NULL,
  `wr_homepage` varchar(255) NOT NULL,
  `wr_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `wr_file` tinyint(4) NOT NULL DEFAULT '0',
  `wr_last` varchar(19) NOT NULL,
  `wr_ip` varchar(255) NOT NULL,
  `wr_facebook_user` varchar(255) NOT NULL,
  `wr_twitter_user` varchar(255) NOT NULL,
  `wr_1` varchar(255) NOT NULL,
  `wr_2` varchar(255) NOT NULL,
  `wr_3` varchar(255) NOT NULL,
  `wr_4` varchar(255) NOT NULL,
  `wr_5` varchar(255) NOT NULL,
  `wr_6` varchar(255) NOT NULL,
  `wr_7` varchar(255) NOT NULL,
  `wr_8` varchar(255) NOT NULL,
  `wr_9` varchar(255) NOT NULL,
  `wr_10` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_write_gallery`
--

CREATE TABLE `g5_write_gallery` (
  `wr_id` int(11) NOT NULL,
  `wr_num` int(11) NOT NULL DEFAULT '0',
  `wr_reply` varchar(10) NOT NULL,
  `wr_parent` int(11) NOT NULL DEFAULT '0',
  `wr_is_comment` tinyint(4) NOT NULL DEFAULT '0',
  `wr_comment` int(11) NOT NULL DEFAULT '0',
  `wr_comment_reply` varchar(5) NOT NULL,
  `ca_name` varchar(255) NOT NULL,
  `wr_option` set('html1','html2','secret','mail') NOT NULL,
  `wr_subject` varchar(255) NOT NULL,
  `wr_content` text NOT NULL,
  `wr_link1` text NOT NULL,
  `wr_link2` text NOT NULL,
  `wr_link1_hit` int(11) NOT NULL DEFAULT '0',
  `wr_link2_hit` int(11) NOT NULL DEFAULT '0',
  `wr_hit` int(11) NOT NULL DEFAULT '0',
  `wr_good` int(11) NOT NULL DEFAULT '0',
  `wr_nogood` int(11) NOT NULL DEFAULT '0',
  `mb_id` varchar(20) NOT NULL,
  `wr_password` varchar(255) NOT NULL,
  `wr_name` varchar(255) NOT NULL,
  `wr_email` varchar(255) NOT NULL,
  `wr_homepage` varchar(255) NOT NULL,
  `wr_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `wr_file` tinyint(4) NOT NULL DEFAULT '0',
  `wr_last` varchar(19) NOT NULL,
  `wr_ip` varchar(255) NOT NULL,
  `wr_facebook_user` varchar(255) NOT NULL,
  `wr_twitter_user` varchar(255) NOT NULL,
  `wr_1` varchar(255) NOT NULL,
  `wr_2` varchar(255) NOT NULL,
  `wr_3` varchar(255) NOT NULL,
  `wr_4` varchar(255) NOT NULL,
  `wr_5` varchar(255) NOT NULL,
  `wr_6` varchar(255) NOT NULL,
  `wr_7` varchar(255) NOT NULL,
  `wr_8` varchar(255) NOT NULL,
  `wr_9` varchar(255) NOT NULL,
  `wr_10` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `g5_write_gallery`
--

INSERT INTO `g5_write_gallery` (`wr_id`, `wr_num`, `wr_reply`, `wr_parent`, `wr_is_comment`, `wr_comment`, `wr_comment_reply`, `ca_name`, `wr_option`, `wr_subject`, `wr_content`, `wr_link1`, `wr_link2`, `wr_link1_hit`, `wr_link2_hit`, `wr_hit`, `wr_good`, `wr_nogood`, `mb_id`, `wr_password`, `wr_name`, `wr_email`, `wr_homepage`, `wr_datetime`, `wr_file`, `wr_last`, `wr_ip`, `wr_facebook_user`, `wr_twitter_user`, `wr_1`, `wr_2`, `wr_3`, `wr_4`, `wr_5`, `wr_6`, `wr_7`, `wr_8`, `wr_9`, `wr_10`) VALUES
(4, -4, '', 4, 0, 0, '', '\전통\한복', '', '\화보', '\화보', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:41:57', 1, '2019-08-27 14:41:57', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(3, -3, '', 3, 0, 0, '', '\전통\한복', '', '\화보', '\화보', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:41:43', 1, '2019-08-27 14:41:43', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(2, -2, '', 2, 0, 0, '', '\전통\한복', '', '\화보', '\화보', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:41:17', 1, '2019-08-27 14:41:17', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(5, -5, '', 5, 0, 0, '', '\전통\한복', '', '\화보', '\화보', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:42:14', 1, '2019-08-27 14:42:14', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(8, -7, '', 8, 0, 0, '', '\전통\한복', '', '\화보', '\화보', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:43:19', 1, '2019-08-27 14:43:19', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(7, -6, '', 7, 0, 0, '', '\전통\한복', '', '\화보', '\화보', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:43:01', 1, '2019-08-27 14:43:01', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(9, -8, '', 9, 0, 0, '', '\드레스\한복', '', '\드레스\화보', '\드레스\화보', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:47:50', 1, '2019-08-27 14:47:50', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(10, -9, '', 10, 0, 0, '', '\드레스\한복', '', '\드레스\화보', '\드레스\화보', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:48:08', 1, '2019-08-27 14:48:08', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(11, -10, '', 11, 0, 0, '', '\협찬\작품', '', '김�\��표', '김�\��표', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:49:25', 1, '2019-08-27 14:49:25', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(12, -11, '', 12, 0, 0, '', '\협찬\작품', '', '문근\영', '문근\영', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:51:46', 1, '2019-08-27 14:51:46', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(13, -12, '', 13, 0, 0, '', '\협찬\작품', '', '\성\현아', '\성\현아', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:52:14', 1, '2019-08-27 14:52:14', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(14, -13, '', 14, 0, 0, '', '\트\렌드한복', '', '2016.09 모던한 \뉴 \스\타일', '2016.09 모던한 \뉴 \스\타일', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:53:12', 1, '2019-08-27 14:53:12', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(15, -14, '', 15, 0, 0, '', '\트\렌드한복', '', '2016.09 모던한 \뉴 \스\타일', '2016.09 모던한 \뉴 \스\타일', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:53:31', 1, '2019-08-27 14:53:31', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(16, -15, '', 16, 0, 0, '', '\트\렌드한복', '', '2016.09 모던한 \뉴 \스\타일', '2016.09 모던한 \뉴 \스\타일', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:54:03', 1, '2019-08-27 14:54:03', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(17, -16, '', 17, 0, 0, '', '\트\렌드한복', '', '2016.09 모던한 \뉴 \스\타일', '2016.09 모던한 \뉴 \스\타일', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:54:14', 1, '2019-08-27 14:54:14', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(18, -17, '', 18, 0, 0, '', '\트\렌드한복', '', '2016.09 모던한 \뉴 \스\타일', '2016.09 모던한 \뉴 \스\타일', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:54:27', 1, '2019-08-27 14:54:27', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(19, -18, '', 19, 0, 0, '', '\트\렌드한복', '', '2016.09 모던한 \뉴 \스\타일', '2016.09 모던한 \뉴 \스\타일', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:54:40', 1, '2019-08-27 14:54:40', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(20, -19, '', 20, 0, 0, '', '\트\렌드한복', '', '2016.09 모던한 \뉴 \스\타일', '2016.09 모던한 \뉴 \스\타일', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:54:54', 1, '2019-08-27 14:54:54', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(21, -20, '', 21, 0, 0, '', '\트\렌드한복', '', '2016.09 모던한 \뉴 \스\타일', '2016.09 모던한 \뉴 \스\타일', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:55:17', 1, '2019-08-27 14:55:17', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(22, -21, '', 22, 0, 0, '', '\트\렌드한복', '', '2016.09 모던한 \뉴 \스\타일', '2016.09 모던한 \뉴 \스\타일', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:55:30', 1, '2019-08-27 14:55:30', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(23, -22, '', 23, 0, 0, '', '\트\렌드한복', '', '2016.09 모던한 \뉴 \스\타일', '2016.09 모던한 \뉴 \스\타일', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:55:41', 1, '2019-08-27 14:55:41', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(24, -23, '', 24, 0, 0, '', '\트\렌드한복', '', '2016.09 모던한 \뉴 \스\타일', '2016.09 모던한 \뉴 \스\타일', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:55:56', 1, '2019-08-27 14:55:56', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(25, -24, '', 25, 0, 0, '', '\트\렌드한복', '', '2017.01.\화보', '2017.01.\화보', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:56:31', 1, '2019-08-27 14:56:31', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(26, -25, '', 26, 0, 0, '', '\트\렌드한복', '', '2017.01.\화보', '2017.01.\화보', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:56:44', 1, '2019-08-27 14:56:44', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(27, -26, '', 27, 0, 0, '', '\트\렌드한복', '', '2017.01.\화보', '2017.01.\화보', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:56:56', 1, '2019-08-27 14:56:56', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(28, -27, '', 28, 0, 0, '', '\드레스\한복', '', 'Wedding21 17\년 8\월호', 'Wedding21 17\년 8\월호', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:57:53', 1, '2019-08-27 14:57:53', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(29, -28, '', 29, 0, 0, '', '\드레스\한복', '', 'Wedding21 17\년 8\월호', 'Wedding21 17\년 8\월호', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:58:05', 1, '2019-08-27 14:58:05', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(30, -29, '', 30, 0, 0, '', '\드레스\한복', '', 'Wedding21 17\년 8\월호', 'Wedding21 17\년 8\월호', '', '', 0, 0, 2, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:58:22', 1, '2019-08-27 14:58:22', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(31, -30, '', 31, 0, 0, '', '\드레스\한복', '', 'Wedding21 17\년 8\월호', 'Wedding21 17\년 8\월호', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:58:49', 1, '2019-08-27 14:58:49', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(32, -31, '', 32, 0, 0, '', '\드레스\한복', '', 'Wedding21 17\년 8\월호', 'Wedding21 17\년 8\월호', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:59:04', 1, '2019-08-27 14:59:04', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(33, -32, '', 33, 0, 0, '', '\드레스\한복', '', 'Wedding21 17\년 8\월호', 'Wedding21 17\년 8\월호', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:59:15', 1, '2019-08-27 14:59:15', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(34, -33, '', 34, 0, 0, '', '\드레스\한복', '', 'Wedding21 17\년 8\월호', 'Wedding21 17\년 8\월호', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:59:26', 1, '2019-08-27 14:59:26', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(35, -34, '', 35, 0, 0, '', '\드레스\한복', '', 'Wedding21 17\년 8\월호', 'Wedding21 17\년 8\월호', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:59:38', 1, '2019-08-27 14:59:38', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(36, -35, '', 36, 0, 0, '', '\드레스\한복', '', 'Wedding21 17\년 8\월호', 'Wedding21 17\년 8\월호', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 14:59:51', 1, '2019-08-27 14:59:51', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(37, -36, '', 37, 0, 0, '', '\드레스\한복', '', 'Wedding21 17\년 8\월호', 'Wedding21 17\년 8\월호', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 15:00:13', 1, '2019-08-27 15:00:13', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(38, -37, '', 38, 0, 0, '', '\드레스\한복', '', 'Wedding21 17\년 8\월호', 'Wedding21 17\년 8\월호', '', '', 0, 0, 1, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 15:00:25', 1, '2019-08-27 15:00:25', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(39, -38, '', 39, 0, 0, '', '\드레스\한복', '', 'Wedding21 17\년 8\월호', 'Wedding21 17\년 8\월호', 'https://www.youtube.com/embed/i-9GNNc1Mfk', '', 1, 0, 2, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 15:00:36', 1, '2019-08-27 15:00:36', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_write_notice`
--

CREATE TABLE `g5_write_notice` (
  `wr_id` int(11) NOT NULL,
  `wr_num` int(11) NOT NULL DEFAULT '0',
  `wr_reply` varchar(10) NOT NULL,
  `wr_parent` int(11) NOT NULL DEFAULT '0',
  `wr_is_comment` tinyint(4) NOT NULL DEFAULT '0',
  `wr_comment` int(11) NOT NULL DEFAULT '0',
  `wr_comment_reply` varchar(5) NOT NULL,
  `ca_name` varchar(255) NOT NULL,
  `wr_option` set('html1','html2','secret','mail') NOT NULL,
  `wr_subject` varchar(255) NOT NULL,
  `wr_content` text NOT NULL,
  `wr_link1` text NOT NULL,
  `wr_link2` text NOT NULL,
  `wr_link1_hit` int(11) NOT NULL DEFAULT '0',
  `wr_link2_hit` int(11) NOT NULL DEFAULT '0',
  `wr_hit` int(11) NOT NULL DEFAULT '0',
  `wr_good` int(11) NOT NULL DEFAULT '0',
  `wr_nogood` int(11) NOT NULL DEFAULT '0',
  `mb_id` varchar(20) NOT NULL,
  `wr_password` varchar(255) NOT NULL,
  `wr_name` varchar(255) NOT NULL,
  `wr_email` varchar(255) NOT NULL,
  `wr_homepage` varchar(255) NOT NULL,
  `wr_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `wr_file` tinyint(4) NOT NULL DEFAULT '0',
  `wr_last` varchar(19) NOT NULL,
  `wr_ip` varchar(255) NOT NULL,
  `wr_facebook_user` varchar(255) NOT NULL,
  `wr_twitter_user` varchar(255) NOT NULL,
  `wr_1` varchar(255) NOT NULL,
  `wr_2` varchar(255) NOT NULL,
  `wr_3` varchar(255) NOT NULL,
  `wr_4` varchar(255) NOT NULL,
  `wr_5` varchar(255) NOT NULL,
  `wr_6` varchar(255) NOT NULL,
  `wr_7` varchar(255) NOT NULL,
  `wr_8` varchar(255) NOT NULL,
  `wr_9` varchar(255) NOT NULL,
  `wr_10` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `g5_write_notice`
--

INSERT INTO `g5_write_notice` (`wr_id`, `wr_num`, `wr_reply`, `wr_parent`, `wr_is_comment`, `wr_comment`, `wr_comment_reply`, `ca_name`, `wr_option`, `wr_subject`, `wr_content`, `wr_link1`, `wr_link2`, `wr_link1_hit`, `wr_link2_hit`, `wr_hit`, `wr_good`, `wr_nogood`, `mb_id`, `wr_password`, `wr_name`, `wr_email`, `wr_homepage`, `wr_datetime`, `wr_file`, `wr_last`, `wr_ip`, `wr_facebook_user`, `wr_twitter_user`, `wr_1`, `wr_2`, `wr_3`, `wr_4`, `wr_5`, `wr_6`, `wr_7`, `wr_8`, `wr_9`, `wr_10`) VALUES
(1, -1, '', 1, 0, 0, '', '', '', '\전통\한복 \의복문화에 \대한 계승', '청담\동에 \위�\��한 \전통\한복 \디자이\너 브랜드인 \'김숙�\��우리옷\'\은 \한복\디자이\너 김숙�\���\��의 \독특\한 \디자인\을 추구\하�\�� \있다.\r\n\r\n\전통�\� \현대 감�\��의 조화를 \이루며 \원단 \재직에서�\��터 \옛 문헌의 고�\��을 \통\한 \전통 문양 \재\현과 \자수 배�\��, \저�\��리 치�\��, 마�\��자, 바�\�� \등 \옷\의 \특\성\에 \따�\� \전통 바느�\��, \손수 \염\색 \등 \전통기�\��을 \통\해 \우�\� \옷\의 \아�\��다\움을 \나타내고 \있다.\r\n\r\n\또한 \신세\대의 취향\에 맞는 \독특\한 \디자인�\� \현대적인 감�\��이 가미\된 \색상으로 \한복\의 \트\렌드를 만들\어 가�\�� \있다.\r\n\r\n\한복\의 3\대 \원�\��인 \디자인, 바느�\��, \원단\의 조화�\�� 고�\�� 맞춤복의 \특\성\을 \정확히 \표현하여 \소�\��자에�\�� 만족감을 갖�\�� \함�\� \동시에 \섬\세\한 부�\���\���\�� \잘 \살\펴 \끝�\���\�� \정\r\n\r\n \r\n\r\n\성\을 \다\하는 \전통\한복 \전문 브랜드 김숙�\��우리옷.\r\n\r\n\r\n\r\n김숙�\��우리옷\은 \독특\한 \디자인\을 추구\하�\�� \있으�\� \전통\적인 면을 중요시하�\�� \재\단�\� 배색 \디자인\에서 \현대적인 \장\점을 취하여 \신랑, \신�\�� \등 \한복\을 \자주 \접하�\�� \않았던 고�\��도 \편\안함\을 \느낄 \수 \있는 \장\점이 \있다.\r\n\r\n치�\��나 \저�\��리\등 \에서도 \서구\화 \되어가는 \우리나라 \사\람들\의 체형을 \연구하여 \재\단�\� 바느�\�� 과정을 과학적으로 \하여 \한복\이지�\�� 불편\한 것이 \아니라 \편\안한 \느낌을 줄 \수 \있는 김숙�\���\��의 \독특\한 \패\턴\을 추구\하�\�� \있다.\r\n\r\n칼라 \또한 \디자이\너 브랜드�\�� \앞선 \트\렌드를 \읽고 \단계를 \선택하여 \오\랜 \시�\�� \우�\� \한복\을 \입어\도 \싫증나�\�� \않�\�� \세\련\된 \느낌을 줄 \수 \있는 \색상을 \염\색해 \내고 \있다.\r\n\r\n김숙�\�� \우리옷 \연\혁\r\n\r\n1989\년 4\월 미국 LA 청소년 마약\퇴치 기�\�� 조성\을 \위한 \우리옷 \패\션쇼\r\n\r\n1990\년 5\월 \대통\령 방일 기념 \일�\� \오\사�\� 꽃 박람회 \우리옷 발표회 개�\��\r\n1991\년~1998\년 8\년�\�� \대한항�\� 국제선 1\등\석 \승무원의 \한복 \유니폼 \디자인 \제작\r\n1992\년~1996\년  5\년�\�� SBS TV 초청 \패\션쇼\r\n1993\년~1997\년  5\년�\�� \대통\령 \해\외 \순방 \때 \의전 \한복 \담\당\r\n1994\년 KBS TV \대하드라마 \‘장\녹\수’ \의상 \제작\r\n1997\년~1999\년 중앙일�\� 문화센\터 \한복 강사\r\n1999\년 5\월 \산\업자원�\�� 지원 \아래 \‘전통 마섬\유의 고품격 \생활한복\’ \을 \연�\� 개�\��하여 \서�\�� 모시문\화제 개�\��식에서 발표\r\n1999\년 6\월 국립\현대미\술�\�� 주�\�� \‘ART & ART WEAR \오\늘의 \우리옷\’ 초청 \전시\r\n\r\n2000\년 9\월 KOSCO\전 (\서울 백상 기념�\��), KBS TV \드라마 \‘송\화’ \의상 \제작 \등\r\n2001\년 <\오\뜨\웨\딩10\월 11\월호>발표, <마이\웨\딩 12\월호>\신�\��복 발표\r\n2002\년 \한산 모시 문화제 \‘모\시 \패\션디자인 공모\전’, \심\사\위원장, KBS TV TV-\드라마 \‘인\생화보\’ \의상제작\r\n2003\년 SBS TV \드라마 \‘�\��년�\��애’ \전통\의상 \제작, \한산모시 문화제 \‘모\시옷 \패\션디자인 공모\전’ \심\사\위원장 \등 \역\임\r\n2005\년 \‘임페리\얼 \팰리스 \호\텔’�\���\�� 기념 VIP 초청 \한복 \패\션쇼 개�\��\r\n2006\년 7\월 \월�\��웨\딩21 \잡지에  가을 \새�\��운 \디자인 발표, kbs \드라마 \소문\난 7공주 \의상 \협찬 \등\r\n2007\년 kbs \드라마 미우\나 고우\나 \의상 \협찬 \등\r\n2008\년 \농구\선수 김주\성 \선수, \연\예인 찰스, 가수 김�\��표  결혼 \한복 진행\r\n2009\년 kbs \드라마 \솔약집 \아들\들 \의상 \협찬, \농구\선수 \서장\훈 결혼 \한복 진행\r\n\r\n2010\년 중소기\업�\��흥공단 \인\정 벤�\��기\업 \승\인\r\n2011\년 강남�\� \'미주\통\상�\���\��단\' \파견 참여\r\n2012\년 강남�\� \'\유럽\통\상�\���\��단\' \파견 참여\r\n2015\년 글�\���\�� \럭\셔리 \어\워�\�� 국제협력 \한복부문 \대상 \수상\r\n2016\년 \현재 \여\러 방송 및 국제행사\에서 \한복 관련 \자문\위원으로 \활동�\��.\r\n\r\n\r\n\자�\��제공 : 김숙�\��우리옷(02-548-2588 http://www.kimsookjin.com )\r\n\r\n\r\n\웨\프뉴\스<news@wef.co.kr>', '', '', 0, 0, 2, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 17:06:03', 1, '2019-08-27 17:06:03', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(2, -2, '', 2, 0, 0, '', '', '', '\우리상품 \세계�\��품화대상 \수상 \영예', '\우리상품세계�\��품화�\���\��위원회와 \이철우, 김장\실, 강은희, 박수현 국회의원이 공동주최하�\�� 글�\���\�� 관�\��융복합\산\업연\합\회�\�� 주�\��한 \'\우리상품 \세계�\��품화대상 \시상식(GLOBAL LUXURY AWARDS)\'\이 지난해 6\월 1\일 국회 \의원회�\��에서 개�\��되었다.\r\n\r\n\시상식에는 \삼\성 \'갤럭\시\', \아모\레퍼\시픽 \'\설\화수\'가 국내 \상품의 \우\수성\을 \세계에 \알린 \제품으로 \‘세계 명품화 \대상’을 \수상했으�\� \전통\한복\으로는 \유일\하�\�� 국제협력 \한복부문\에서 김숙�\��우리옷\이 \수상하는 \영예를 \안았다.  \r\n\r\n \r\n\r\n\세계에서 \인\정�\��을 \수 \있는 \신뢰\도를 가�\�� \전통\한복 \디자이\너 브랜드이�\� \한복\의 \세계화에 기여\한 공�\���\�� \이 \상을 \수상했다.\r\n\r\n김숙�\�� \대표는 \"김숙�\��우리옷\이 가�\�� 고유의 \전통\한복\의 \우\수성�\� 국내\외\의 \신뢰�\� 기�\��으로 지역경제에 \이바�\��하�\��, \다\양한 \사\회공\헌 \활동을 \통\해 \대한민국의 \대표 브랜드�\�� \성\장\해 \나�\���\��다\"고 \수상 \소�\��을 밝혔다. \r\n\r\n \r\n\r\n<\사진 : 김숙�\��우리옷 \작품 \한복>\r\n\r\n\한편, 청담\동에 \위�\��한 \전통\한복 \디자이\너 브랜드인 \'\우리옷\의 \자�\��심 - 김숙�\��우리옷\'\은 \전통�\� \현대 감�\��의 조화를 \이�\� \한복\을 \선보\인\다. \r\n\r\n\특\히, \원단 \제작에서�\��터 \옛 문헌의 고�\��을 \통\한 \전통문양의 \재\현과 \자수 배�\��, 치�\��저�\��리, 마�\��자, 바�\�� \등 \옷\의 \특\성\에 \따\라 \전통 바느�\��과 \손수 \염\색 \등\의 \전통기�\��으로 \제작해 \우�\� \옷\의 \아�\��다\움을 \드러\내\는 것이 \특징이\다. \r\n\r\n\한복\의 \현대화와 \패\션화에 \앞장\서�\�� \있는 \전통\한복 \디자이\너인 김숙�\�� \대표는 \"2016\년 가을시�\��과 2017\년 봄시�\��을 맞아 \다\양한 \한복 \디자인 \작품을 비롯\한 \한복\드레스, \신랑한복, \신�\��한복, \어머님한복 \등\을 \웨\딩\전문 매거진인 \'\월�\��웨\딩21\'\을 \통\해 \선보\일 \예정\"\이\라�\�,279c6ccac2c7dfbfcd3b768721bd0fa0_1478225 \r\n\r\n \r\n\r\n<\사진 : 김숙�\��우리옷 \작품 \한복>\r\n\r\n\"\자연\속에서 \소재�\� \얻\어 \아�\��답고 \화려\하면\서도 \품격\이 \느껴지는 고유의 \의복문화�\�� 계승발전을 거듭\해 \오고 \있는 \한국\의 \전통\한복\은 \세계인\이 부러\워하�\�� \있는 \우�\� 고유의 \높은 \자산\이기에 \디자이\너�\��서의 \자�\��심\이 무엇보\다 \크\다. 그래서 \슬로건\을 \'\우리옷\의 \자�\��심\'\으로 \하�\�� \있다\"고 \덧붙였다.\r\n\r\n\또한, 김숙�\��한복\은 \전통\한복\의 \현대화에 \대한 기술평�\���\��문\에서 \한복\업�\�� 최�\���\�� 지난 2010\년 중소기\업�\��흥공단 벤�\��기\업 \인증을 \획득하였다. \r\n\r\n\r\n\자�\��제공 : 김숙�\��우리옷(02-548-2588 http://www.kimsookjin.com )\r\n\r\n\r\n\웨\프뉴\스<news@wef.co.kr>', '', '', 0, 0, 2, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 17:06:50', 1, '2019-08-27 17:06:50', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(4, -4, '', 4, 0, 0, '', '', '', '\새롭게 \쓰\이\는 모던한복', '\현대와 \전통\의 믹스매�\���\�� \한복\의 개성\을 마음�\�� \살\렸\다. \올가을 김숙�\��우리옷\의 \새�\��운 \제안을 만나보\자. -1\r\n\r\nDesigned by 김숙�\��우리옷\r\n\r\n\r\n\r\n비취\색 치�\��와 개나리\색 \당\의�\�� \소재\의 \특징을 \살\려 \자연\스\러\운 \실루엣\을 \연출했다. 치�\�� \사\이로 보이\는 \너른바�\��와 \단\속곳\의 \아�\��다\움이 \포\인\트. \업스\타일�\� \어\우\러\져 바람에 \날리\는 \홍색 고�\��이 \아�\��답\다.\r\n\r\n\r\n\r\n\서양 \의상에서나 봄�\��한 \페이즐 \패\턴�\� 경�\��한 \프린\트�\� 변형하여 \잔잔한 \아�\��다\움을 \선사\하는 \한복\이\다. \신�\��의 \화사\함\을 \표현하는 매력\적인 믹스매�\��를 보여준다.\헤\어\장\식 \앤\틱반\r\n\r\n\r\n\r\n\사\랑스\러\운 \색상 매�\���\�� \돋보\이\는 \신�\�� \한복\으로 \저�\��리\는 조이고 치�\��는 \풍성\하�\�� \하여 \한복 \특\유의 \실루엣\을 \연출한다. \끝동과 \저�\��리 \도련\에 \레이\스로 \포\인\트�\� 주�\�� \헤\어\엔 \시폰 \소재 \장\식을 \달\아 \사\랑스\럽게 마무리했다. 구슬�\� \앤\틱반\r\n\r\n\r\n\r\n매화�\��이 \흐드러진 주홍색 \저�\��리\와 \석�\���\�� \자연 \염\색한 치�\���\�� 모던 \한복 \이미�\��를 \연출했다. \흰 \끝동과 \작�\�� 가는 고�\��이 모던하�\�� \표현되었으�\� 말기\에 \두른 \레이\스가 멋스\럽\다. \레이\스밴드 \앤\틱반\r\n\r\n\r\n\한복 김숙�\��우리옷 (02 548 2588)\r\n\에디터 김주�\�\r\n\포\토그\래퍼 김보\하 (\더써\드�\��인\드 02 516 5947)\r\n\디렉터 박희\수 (010 6231 1978)\r\n모델 김�\��이\r\n\헤\어 \에�\��(TG\헤\어 02 792 2042)\r\n메이\크\업 민희, \한솔 (\터치�\��이\해�\� 02 3443 3857)\r\n\제품협조 \앤\틱반(02 512 1343)\r\n\r\n\월�\��웨\딩21 \편집�\��<news@wef.co.kr>', '', '', 0, 0, 2, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 17:13:23', 1, '2019-08-27 17:13:23', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(3, -3, '', 3, 0, 0, '', '', '', '\우�\� 고유의 \색 쪽�\�� \한복\으로 \재\현', '- \전통\한복 \디자이\너의 \영�\��으로 \되살\아 \난 쪽�\�� \한복\에 광복\의 \염\원을 \담\다.\r\n\r\n광복 71주년 기념 \전야\행사\인 \'\융복합 문화�\��텐�\�� 공연\'\이 지난  14\일 국회 \의원회�\�� \대�\��당\에서 국회대�\��문\화미\디어\연구회(\대표의원 \홍문종), \한국\언론인\연\합\회(\회장 최재\영), \서울\팝스\오케스\트\라(\단\장 \하성\호) 공동주최�\�� \'광복, 빛을 \되찾\다\' 공연\이 \열\렸\다.\r\n\r\n \r\n\r\n\한국국악협회(\이\사\장 \홍성\덕) \소속 국악인\인 김�\��미 명창\을 비롯\해 김�\��순, 김보\연, \남궁정애, 박옥초, 최영자 명창\이 \아리\랑과 뱃노\래 \등 \다\양한 \우�\� 민족\의 \음악을 관�\��에�\�� \선보\였�\�� \젊은 \팝페라 가수인 \한아�\��, \오\정환이 출연\해 \팝페라\의 진수를 \선보\이기도 \하였다. \r\n\r\n\r\n\r\n\이\러\한 \뜻깊은 \행사\의 진행을 맡은 \한다\연 \아나운\서의 \한복\을 \전통\한복 \디자이\너 브랜드인 \'김숙�\��우리옷\'\에서 \특별히 \제작, \협찬\하였다.\r\n\r\n광복\의 \뜻\을 \되새기\는 \의미\에서 \남\색 치�\��에 \소색저�\��리로 \소�\��하�\�� \단\아한 \느낌을 중시하였으�\� 중기\시대 \저�\��리로 깃을 \둥글�\�� 굴린 것이 \특징이\다. \r\n\r\n\핑크빛 고�\��으로 \포\인\트�\� 주�\�� \둥글�\�� \도린 깃에 무�\��화�\��을 \수놓아 경건\함�\� \절제의 �\�(美)�\� \돋보\이게 \하였다.\r\n\r\n\r\n\r\n광복\에 \대한 \영�\��을 \한복\으로 \표현한 \한복\디자이\너 김숙�\��은 \우리�\��유의 \색상인 쪽�\���\���\��에 \소색 \저�\��리로 \단\아하�\�� \소�\��한 멋이 \흐르\는 \한복\을 \선보\였다.\r\n\r\n\한복\디자이\너이\자 김숙�\��우리옷\의 김숙�\�� \대표는 \"국�\�� \행사\인 광복 71주년 \뜻깊은 공연\의 진행을 맡은 \한다\연 \아나운\서의 \한복\을 \협찬\한다\는 것은 \나에�\��는 \한복\에 \대한 \또다�\� \도전\"\이\였다�\�,\r\n\r\n\"광복\에 \대한 깊이\있는 \성찰없이\는 \당\시의 \'\염\원\'\을 \우�\� 고유의 \의복문화인 \전통\한복\의 빛�\���\�� \표현해 \내\는 것은 결�\�� \쉬\운 \일\이 \아닙니다. \화려\함보다\는 \절제된 미와 \소�\��함\을 기�\��한 고유의 \'쪽�\��\'\을 \선택하�\�� 깃에 무�\��화�\��을 \수놓은 것도 \이\러\한 \뜻\에서입니다.\"\r\n\r\n\한편, 청담\동에 \위�\��한 \전통\한복 \디자이\너 브랜드인 \'\우리옷\의 \자�\��심 - 김숙�\��우리옷\'\은 \작품한복\을 비롯\한 \다\양한 \전통\한복, \한복\드레스, \신랑한복, \신�\��한복, \어머님한복 \등\을 \선보\이고 \있다.\r\n\r\n\자�\��제공 : 김숙�\��우리옷(02-548-2588)\r\n \r\n\r\n\r\n\웨\프뉴\스<news@wef.co.kr>', '', '', 0, 0, 2, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 17:09:35', 1, '2019-08-27 17:09:35', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(5, -5, '', 5, 0, 0, '', '', '', '\새롭게 \쓰\이\는 모던한복 2', '﻿현대와 \전통\의 믹스매�\���\�� \한복\의 개성\을 마음�\�� \살\렸\다. \올가을 김숙�\��우리옷\의 \새�\��운 \제안을 만나보\자. 2\r\n\r\nDesigned by 김숙�\��우리옷\r\n\r\n\r\n\r\n복숭\아색 말기 치�\��와 물방\울 문양이 \프린\팅된 \저�\��리\의 조화�\�� \신�\��를 \여\성\스\럽게 만든다.\r\n\r\n\저�\��리 \도련 \아래의 \레이\스 \장\식과 �\� \끝동이 \화사\한 분위기�\� \연출한다. 고�\�� \대신 브�\���\���\���\�� \장\식해\도 멋스\럽\다.브�\���\�� \앤\틱반\r\n\r\n\r\n\r\n\레이\스 \저�\��리\와 \남\색 치�\���\�� \단\아함\을 \연출했다. 볼륨감 \있는 �\� \레이\스\는 \사\랑스\럽고 \남\색 치�\��는 경�\��하다.\r\n\r\n주아사 \소재\의 \안�\��으로 \풍성\한 치�\��를 \표현하였다.\r\n\r\n\r\n\r\n비�\��는 \느낌을 \잘 \표현한 \옥\색 치�\��와 \흰\색 \저�\��리가 \단\아하다. \전통 말기 치�\���\�� \섹\시함\을 \드러\내고,\r\n\r\n\옆으로 길�\�� \늘어\뜨�\� 치�\��끈의 모습\이 \눈에 \띈다. \단\속곳�\� \속�\���\���\�� 치�\��를 부풀리\는 \형태의 \항\아리 \실루엣\이 \포\인\트.\r\n\r\n\r\n\r\n\옥\사 \소재 치�\��자락 \사\이로 보이\는 \단\속곳\의 \실루엣�\� \자주\색 코의 갖신, \손등까�\�� \덮\는 \시스�\� \재\킷\의 조화�\�� \동서양의 \느낌을 고루 갖�\��다.\r\n\r\n보넷\으로 \영화 같은 \스\타일\을 \완성\했다. \재\킷, \헤\어\장\식 \앤\틱반\r\n\r\n\r\n\한복 김숙�\��우리옷 (02 548 2588)\r\n\에디터 김주�\�\r\n\포\토그\래퍼 김보\하 (\더써\드�\��인\드 02 516 5947)\r\n\디렉터 박희\수 (010 6231 1978)\r\n모델 김�\��이\r\n\헤\어 \에�\��(TG\헤\어 02 792 2042)\r\n메이\크\업 민희, \한솔 (\터치�\��이\해�\� 02 3443 3857)\r\n\제품협조 \앤\틱반(02 512 1343)\r\n\r\n\r\n\월�\��웨\딩21 \편집�\��<news@wef.co.kr>', '', '', 0, 0, 2, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 17:14:11', 1, '2019-08-27 17:14:11', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(6, -6, '', 6, 0, 0, '', '', '', '\우�\� 고유의 \전통\한복\을 \세계�\��', '\한국\에서는 처음으로 개�\��되는 \‘2017 \서울 \한복\위크\’�\�� \내\달 29\일부터 \약 \한 \달 간 \열리는 \대한민�\� 최대 \쇼\핑�\���\���\��제인 \‘�\��리\아 \세\일 \페스\타(Korea Sale FESTA)\’ \행사\와 \함께 진행된다.\r\n\r\n\오\는 10\월 1\일(\토) \‘2017 \서울 \한복\위크\’�\�� \신사\동 가�\��수길�\� \이\태원 \역\일\대에서 1�\� \오\후 2\시�\��터 3\시�\���\��, 2�\� \오\후 4\시�\��터 5\시�\���\�� 진행될 \예정이�\� \이번 \행사\는 \‘월�\��웨\딩21\’이 주�\�� / 주�\��을 \하�\��, 강남�\�, \용\산�\�, \‘대한상공\회의소’에서 \후원한다.\r\n\r\n\r\n\r\n<\사진 : 김숙�\��우리옷>\r\n\r\n2016코리\아세\일\페스\타에서 \한�\��문\화 축제의 \한 코너�\�� 진행되는 \‘2017\서울\한복\위크\’는 침체\되어 \있는 \전통 복식인 \‘한복\’의 \대�\��화에 \이바�\��하�\�� \젊은 층으로�\��터 불�\�� \있는 \한복 \입기 문화를 \세\대 \전�\��에 \널리 \알리고자 \하는 \의미\에서 진행된다.\r\n\r\n\‘2017 \서울 \한복\위크\’에 참여\하는 \‘�\��숙�\��우리옷\’은 \한복\의 \전통\을 \이\어가는 \대표디자이\너 브랜드�\��써 김숙�\���\��의 \독특\한 \디자인�\� \젊은세\대의 취향\에 맞는 \현대적인 감�\��이 가미\된 \색상으로 \한복\의 \트\렌드를 만들\어 가�\�� \있다.\r\n\r\n\또한  \‘�\��숙�\��우리옷\’은 \‘우리상품 \세계�\��품화대상 \시상식(GLOBAL LUXURY AWARDS)\’에서 \한국 고유의 \전통\한복\으로 국제협력 \한복부문\에서 \수상하는 \영예를 \안았다.\r\n\r\n\세계에서 \인\정�\��을 \수 \있는 \신뢰\도를 가�\�� \전통\한복 \디자이\너 브랜드�\��써 \한복\의 \세계화에 \앞장\서�\�� \있으�\� \다\양한 \사\회공\헌 \활동을 \통\해 \대한민국의 \대표 브랜드�\�� \성\장\하�\�� \있다.\r\n\r\n\이번 \행사\는 많은 \사\람들\이 보�\�� 즐길 \수 \있는 게릴\라 로드쇼 방식으로 진행되며, \전국\적으로 개�\��되는 코리\아세\일축제 기�\�� 중에 가장 \젊은 층들\이 많이 보이\는 가�\��수 길과 \이\태원 \패\션거리에서 진행될 \예정이\다.\r\n\r\n참여 \업체로는 \전통\한복 \‘�\��숙�\��우리옷\’외 \효\재\한복, \한국\의상 무낙, \포\토그\래퍼 청스\튜디오, \영상에 \디노\트\필�\��, \헤\어&메이\크\업에 \늘솜, \터치�\��이\해�\�, \플라\워에 비욘드앤 \업체가 참여\한다.\r\n\r\n\한편 \‘2017 \서울 \한복\위크\’에서  \‘�\��숙�\��우리옷\’의 \트\렌디한 \다\양한 \한복\을 \선보\일 \예정에 \있어 \이�\� \큰 관심\을 불러 \일\으\키고 \있다.\r\n\r\n\자�\��제공 : 김숙�\��우리옷( 02-548-2588 http://www.kimsookjin.com )\r\n\r\n\웨\프뉴\스<news@wef.co.kr>', '', '', 0, 0, 2, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 17:15:06', 1, '2019-08-27 17:15:06', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(8, -7, '', 8, 0, 0, '', '', '', '\품격\있는 결혼\식에 \안성맞춤', '- \전통�\� \현대적 감�\�� \두루 갖�\�� \세계적 명품 브랜드\r\n\r\n과거 \한복\산\업에 르네\상스\와 같던 \시절이 \있었더라�\� \시�\��이 지날수�\�� \서구문물 \유입과 \한복\의 \예복\화�\�� \인\해 \일\상 \속에서 \전통\한복\의 \입�\��는 \점차 좁아�\���\�� \있는 \현실\이\다. \이\에 \한복\산\업의 \돌파구�\� 마련\해\야 \한다\는 각성\의 목소리가 \높아�\���\�� \있다.\r\n\r\n\이\런 \현실\에서 김숙�\�� \우리옷\은 \뚝심\있�\�� \우�\� \옷\의 계보�\� \이\어가면\서도 계속해\서 \젊은 \세\대의 \호\응을 \이\끌 만 \한 \트\렌드를 \한복\에 가미\하는 \등 \전통\한복\의 \새�\��운 지평을 \열기위해 \노\력\하�\�� \있다.\r\n\r\n\r\n\r\n\스\토리가 \있는 김숙�\�� \우리옷\r\n \r\n\한복\은 \우�\� 문화의 \상�\��이\요, 국제화 \시대의 중요한 문화상품이\다. 청담\에 \위�\��한 김숙�\�� \우리옷\은 \우�\� \의복문화의 \전통\을 계승\하면\서 \시대에 발전시키고자 \노\력\하�\�� \있다.\r\n\r\n\전통�\� \현대 감�\��의 조화를 추구\하는 김숙�\�� \우�\� \옷\은 \원단 \재직에서�\��터 \옛 문헌 고�\��을 \통\한 \전통 문양 \재\현은 물�\�� \자수 배�\��, \저�\��리 치�\��, 마�\��자, 바�\�� \등 \옷\의 \특\성\에 \따�\� \전통 바느�\��, \손수 \염\색 \등 \전통기�\��을 \통\해 \우�\� \옷\의 \아�\��다\움을 \나타내고 \있다.\r\n\r\n\동시에 \젊은 \세\대의 취향\에 맞는 \독특\한 \디자인�\� \현대적인 감�\��이 가미\된 \색상으로 \한복\의 \트\렌드를 만들\어 가�\�� \있다.\r\n\r\n최근\에는 f/w \시�\��을 맞아 \프랑스\에서 직접 \수입한 \수공\예 \레이\스�\� \한복\에 가미\하며 \독창\적이고 \세\련\된 \의상을 \선보\이기도 \했다.\r\n\r\n김숙�\�� \우리옷 만의 차�\��성\은 그�\�� \대한항�\�, SK그룹, CJ, KBS 및 SBS \등 방송\사 \자문\위원, \신한�\��융그룹, KLPGA 골프협회 , 강남�\� \제휴\업체, 롯데\호\텔, \대한무\역\투\자�\��흥공사(KOTRA) \등�\� \제휴�\� 맺으�\� �\� 가�\��를 \드러\냈다.\r\n\r\n\특\히 최근\에는 \이철우, 김장\실, 강은희, 박수현 국회의원이 공동주최하�\�� 글�\���\�� 관�\��융복합\산\업연\합\회�\�� 주�\��한 \'\우리상품 \세계�\��품화대상 \시상식(GLOBAL LUXURY AWARDS)\'\에서 \아모\레퍼\시픽 \설\화수, \삼\성 갤럭\시와 \함께 \의복분야 \전체 \대표�\�� \수상하는 \영예를 \얻기도 \했다.\r\n\r\n\한복\의 \전통미에 \현대적 감�\��을 \더했다고 \평�\���\��는 김숙�\�� \대표는 20\대�\��터 30\년 \이\상 \우�\� \전통 \옷\을 \위한 \외�\� \인\생을 걸어\왔다.\r\n\r\n\노\량�\��을 \시작으로 2001\년 청담\으로 \이\전, 지�\��에 \이르기까�\�� 김 \대표는 \한복\의 3\대 \원�\��인 \디자인, 바느�\��, \원단\의 조화를 \이루며 고�\�� 맞춤복의 \특\성\을 \정확히 \표현하며 고�\��들\에�\�� 만족감을 \전하�\�� \있다. 김숙�\�� \대표에�\�� 가을 결혼\시�\��을 맞아 \신혼부�\�� \한복\에 \대한 조언\을 \들\었다.\r\n\r\n\r\n\r\n\한복 \낯\선 \신혼부�\��…\사계절 맞는 \재질·색상 추�\��\r\n\r\n김숙�\�� \우리옷\은 \독특\한 \디자인\을 추구\하�\�� \있으�\� \전통\적인 면을 중요시하�\�� \재\단�\� 배색 \디자인\에서 \현대적인 \장\점을 취하여 \신랑, \신�\�� \등 \한복\을 \자주 \접하�\�� \않았던 고�\��도 \편\안함\을 \느낄 \수 \있는 \장\점이 \있다.\r\n\r\n뿐�\�� \아니라 치�\��나 \저�\��리\등 \에서도 \서구\화 \되어가는 \우리나라 \사\람들\의 체형을 \연구하여 \재\단�\� 바느�\�� 과정을 과학적으로 \하여 \한복\이지�\�� 불편\한 것이 \아니라 \편\안한 \느낌을 줄 \수 \있는 김숙�\�� 만의 \독특\한 \패\턴\을 추구\하�\�� \있다.\r\n\r\n칼라 \또한 \디자이\너 브랜드�\�� \앞선 \트\렌드를 \읽고 \단계를 \선택하여 \오\랜 \시�\�� \우�\� \한복\을 \입어\도 \싫증나�\�� \않�\�� \세\련\된 \느낌을 줄 \수 \있는 \색상을 \염\색해 \내고 \있다.\r\n\r\n김 \대표는 \신혼부�\��들\의 \한복\에 \대해 \“전통\한복\은 계절에 \따\라 겨울\엔 \양단, 모본\단, 공단 \등 \단종�\��, \여름에는 \한삼모시 \등 최적의 \색과 \소재가 \따로 \있습\니다.\r\n\r\n그러\나 \한복\을 \잘 \입�\�� \않는 경우 계절 \소재�\� \택하는 것보\다 \사계절용\을 \선택하는 것을 추�\��합\니다. \사계절용\은 봄·�\��을에 많이 \입는 \사\재질을 \사\용\합\니다.\r\n\r\n\사\재질에는 \자미\사, \생�\��사, \숙�\��사 \등 \누에�\���\��에서 \실\을 만들\어 \내\는 과정에 \따\라 \다\양하�\�� 구�\��됩\니다\”며 \“신랑 \한복\의 경우 결혼\식 \이\후에는 보통 \설 명절에�\�� \한복\을 많이 \입기 \때문\에 \설\에 맞춰 조�\�� \두�\���\�� 만드는 것도 (\두�\��두�\�� \입을 \수 \있는) \한 방�\��입니다.\”�\�� \덧붙였다.\r\n\r\n\색상에 \대해\서는 \“전�\��적으로 바랜 \듯 \한 \옅은 \색�\��을 \선호\하�\�� \있는 추세\입니다. \하�\���\�� \옅은 \색�\��의 경우 8~9\월 같은 경우\는 괜찮지�\�� 겨울\에 \입기\엔 \다\소 추워 보이\는 경향\이 \있습\니다.\r\n\r\n보통 \이 \시기 (\옅은 \색으로) \한복\을 맞�\��면 \웨\딩 촬영�\��터 본식�\���\�� 몇 개월 간격\이 \있기 \때문\에 촬영 \때는 좋�\���\�� 겨울\에는 \색�\��이 \다\소 맞�\�� \않는 경우\도 \있습\니다\”며 \“그\래서 보통\신�\��의 경우 치�\�� \색상을 \다\홍색, 분홍색, 빨�\��색, \토�\��토 \색상을 \선택하는 경우가 많습\니다. \이\런 \색상은 \신�\��를 \화사\해 보이게 \하면\서 \사계절 \입기 좋습\니다\”�\�� 말했다.\r\n\r\n\r\n\r\n\예복 \대여보다 \제대�\�� \된 \전통\옷 \소�\���\�� 경제적일 \수도\r\n\r\n\한복\은 \양�\�� 부모\님�\�� 받는 �\� \예복\이고 결혼\에 \대한 \약\속이\자 증표이\다. \따\라\서 \트\렌드에 \영향\을 받�\�� \않으면서 \시�\��이 \흐를\수�\�� 가�\���\�� \느껴지는 것을 \선택하는 것이 중요하다.\r\n\r\n김숙�\�� \대표는 최근 경제적인 결혼\을 \위해 \한복\을 \대여\하는 추세\에 \대해 \“물론 \한복\이 \평소에 \잘 \입�\�� \않을 뿐 \더러 경제적으로 부담\이 \되는 경향\이 \있기 \때문\에 \요�\��에는 \대여�\� 많이 \하시는 걸�\�� \압니다\”며 \“보\통 \한복\을 맞�\��러 \온 \신혼부�\��들\의 80%\는 결혼\식 \때 \생전 처음으로 \한복\을 \입어봅니다.\r\n\r\n\나머지 20%\는 \돌 \때 \입었다\니. \사\실\상 기억\에는 \없는 것이지요.(\웃음) \어쩌면 \한복\을 맞춰 \입을 기회는 결혼\식�\��일 \수도 \있습\니다.\r\n\r\n그런\데 그때 \한복\의 \아�\��다\움을 \알 \수 \있는 기회를 \잃은 채 중국\에서 \대량으로 바느�\�� \해\오거나 \전통방식이 \아닌 \안�\��과 \소재로 \엉터리�\�� 지은 \한복\을 \입으\시는 분들\을 보면 조�\�� \안타�\��다\는 \생�\��이 \듭\니다. 물�\�� (\한복\에 \대해) \잘 모르\시니�\�� 그런 것이겠�\��요”라�\� \아쉬\움을 \드러\냈다.\r\n\r\n그러면서도 \“하�\���\�� \일\생에 \한�\��이\라�\� \또 \한국\인\이\라�\� \제대�\�� \된 \한복 \한�\��은 \입어보는 것도 좋�\�� \않을�\��요? \사\실 \한복 \대여\도 \요�\�� \한�\��에 2-30만원을 \호가합\니다.\r\n\r\n\신혼부�\��들\이 \한복\을 \아무�\� \입�\�� \않는다 \하더라\도 \적어\도 결혼\식, \양�\�� \인\사, \아기 \돌잔�\��에는 \입는데. \이 \때�\��다 \대여�\� \하는 것보\다 \자기 몸에 \딱 맞는 \한복\을 짓는 것이 \오\히려 경제적일 \수 \있다고 \생�\��합\니다.\”�\�� 말했다.\r\n\r\n\정�\��차\원 \전통복식�\�� 지원 \끊겨... \도움 \되�\��파\r\n\r\n김숙�\�� \대표�\�� 꿈꾸\는 것은 무엇일까. 김 \대표는 \한국 \전통복식의 미래에 \대해 \우\려\의 목소리�\� \드러\냈다. 그녀는 \“이번 \정�\���\�� \시작하면\서�\��터 \사\실\상 \전통복식�\��의 맥이 \끊겼\습\니다.\r\n\r\n\전통복식�\�� \양성\에 \대한 \정�\��의 지원이 \끊기면서 \대학 \내 개설\돼 \있던 \전통복식학과가 \사\라지�\�� \의상학과\에 \편\입되었기 \때문\입니다\”라�\� \아쉬\움을 \드러\냈다. \“시대�\�� 변해 \이\제 \한복\산\업이 많이 \쇠퇴\했습\니다.\r\n\r\n\제�\�� \있는 청담\동 \일\대�\�� \해\도 100\여개의 \한복집 중 50\여개�\�� \닫\은 \현실\이고 \아�\�� \내\년에는 그나�\�� 중에서도 30군데\는 문을 \닫\을 것입니다. \저 \역\시 \돈을 번다기보\다 \전통\옷·\자수 �\� 문화산\업을 \한다고 \생�\��하�\�� \일\하�\�� \있습\니다.\r\n\r\n국�\��에서도 \전통관련 \사\업에 \대해 \세금 감면 \혜택을 주는 것도 좋을 것 같다고 \생�\��합\니다\”�\�� \제안했다.\r\n\r\n김숙�\�� \우리옷\은 최근\에도 국회대�\��문\화미\디어\연구회(\대표의원 \홍문종), \한국\언론인\연\합\회(\회장 최재\영), \서울\팝스\오케스\트\라(\단\장 \하성\호) 공동주최, 국회 \의원회�\��에서 \열�\� 광복 71주년 기념 \전야\행사 \'광복, 빛을 \되찾\다\' 공연\에 진행을 맡은 \한다\연 \아나운\서의 \한복\을 \제작, \협찬, 광복\의 \뜻\을 기리면서 \한복\의 \아�\��다\움을 \알리\는데 \앞장\섰\다.\r\n\r\n\이\어 그녀는“기\회�\�� \된다�\� 김숙�\�� \우리옷 \사\옥\에 \후배\양성 \혹\은 \일반인\들\에�\�� \전통복식에 \대한 \이\해�\� \돕기 \위해 바느�\�� 교실\이\라\든�\�� 좋은 \프�\��그\램\을 만들\어 \사\회에 \이바�\�� \하�\�� \싶\습\니다\”며 \포부를 \나타냈다.\r\n\r\n청담\동에 \위�\��한 김숙�\�� \우리옷 \사\옥\은 매장 뿐 \아니라 \우리옷 중심\의 복합 \전시공간이\자 문화센\터로서 \사\옥 \전체�\� \우�\� 문화 보존�\� \홍보�\� \위한 관�\���\��스가 \되도�\�� 꾸며지�\�� \있다.\r\n\r\n\한 \평생 \우�\� \전통\옷\을 \위해 매�\��한 김숙�\�� \우리옷, \앞으로도 민족문화 \전통계승\의 \선도자�\��서 번창\하길 기대한다.\r\n\r\n기사\제공 : \정경\뉴\스 \이채현기\자 (02-782-2121 http://www.mjknews.com )\r\n\r\n\웨\프뉴\스<news@wef.co.kr>', '', '', 0, 0, 2, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 17:17:08', 1, '2019-08-27 17:17:08', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(9, -8, '', 9, 0, 0, '', '', '', '2017 \한복 로드쇼', '2017 \서울 \한복\위크가 \서울 강남 \신사\동 가�\��수길�\� \이\태원역 \일\대, \이\태원 \퀴\논 \패\션 거리\에서 \열\렸\다.\r\n\r\n\전통\한복\의 맥을 \이\어가�\�� \있는 \디자이\너 브랜드인 \'김숙�\��우리옷\'\에서 2017 \한복 로드쇼�\� \통\해 \선보\인 \다\양한 \작품 발표�\�� 주목\을 받았다.\r\n\r\n\r\n\r\n�\� \행사\는 \웨\딩 매거진 \월�\�� <\웨\딩21>\이 주�\��·주관하�\�� 강남�\�, \용\산�\�, \산\업자원�\��, 문화체\육관�\���\��, \대한상공\회의소 \후원 \아래 \r\n\r\n\대한민�\� \쇼\핑 관�\�� 축제 \‘�\��리\아 \세\일 \페스\타’의 \한�\�� 문화 축제 중 \한 코너�\�� 진행되었다. \한�\��문\화 축제의 \한 코너�\�� \한복 \입기\r\n\r\n문화를 \세\대 \전�\��에 \널리 \알리�\� \위해 마련\된 \이번 \행사\에 참여\한 김숙�\��우리옷\은 보다 많은 \사\람이 보�\�� 즐길 \수 \있는 \한복\쇼�\�\r\n\r\n\일반에�\�� \선보\임으로써 \한복\의 \대�\��화에 기여\하였다\는 \평을 받기\도 \하였다. \r\n \r\n\r\n\r\n\한복\의 3\대 \원�\��인 \디자인, 바느�\��, \원단\의 조화�\�� 고�\�� 맞춤복의 \특\성\을 \정확히 \표현하는 것으로 \정평이 \나있는\r\n\r\n\디자이\너 브랜드인 \'김숙�\��우리옷\'\은 \이번 \행사\에 \선보\인 \다\양한 \작품한복\을 기�\��으로 2017\년에는 \한층 \더 발�\��\r\n\r\n�\� \행보�\� \선보\일 \예정이\라고 \전했다.\r\n\r\n\'김숙�\��우리옷\'\의 \대표 김숙�\��은 지난해 \연말, \'\우리상품 \세계�\��품화대상 \시상식\'\에서 \한국 고유의 \전통\한복\으로\r\n\r\n국제협력 \한복부문\에서 \수상하는 \영예를 \안은 바 \있다.\r\n\r\n\또한, \동�\��성\장�\� \해\외 \판�\�� 지원을 \위해 출�\��한 \'\한국강소기\업협회\'\의 고문\을 \역\임하�\�� \있으�\� \제16\회 \한국\언론\r\n\r\n\인\연\합\회 \선정 \'\자랑스\런\한국\인\대상\' \시상식에서 공�\��대상을 \수상하기\도 \하였다.\r\n\r\n\자�\��제공 : 김숙�\��우리옷( 02-548-2588 http://www.kimsookjin.com )\r\n \r\n\r\n\r\n\월�\��웨\딩21 \편집�\��<news@wef.co.kr>\r\n\r\n\저작�\��자 \ⓒ온\포\스미디어 \r\n�\� 기사\의 비승\인 복제, \전송, 무단 \전재, \재가공 \등\을 금하며 \위�\��시 법적인 책임을 질 \수 \있습\니다.', '', '', 0, 0, 2, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 17:17:50', 1, '2019-08-27 17:17:50', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(10, -9, '', 10, 0, 0, '', '', '', '\한국강소기\업협회 고문 맡아', '지난 11\월 23\일, 각�\���\��층\의 \저�\��인\사\들\이 참여\한 가운\데 \서울 \여\의도 국회 \헌정기\념�\��에서 \한국강소기\업협회�\�� \‘창�\� 총회 출�\�� \세미나’를 개�\��하�\�� 본격\적으로 출�\��하였다. \r\n\r\n\한국강소기\업협회는 \대기\업과 중소기\업�\�� \동�\��성\장\을 \도모\하�\�� 중소기\업의 \해\외 \판�\���\���\�� 및 컨설\팅을 보다 구체\적으로 지원하여 강소기\업으로 거듭\날 \수 \있도�\�� 지원하기 \위해 \탄생하였다.\r\n\r\n창립총회 \세미나에는 \정운�\� 명예회장, \손욱 고문\을 비롯\한 \이기왕 \한국강소기\업협회 \상근부회장, 김난주 \상근부회장, \나�\��호 \상근부회장, 김�\��선 \인\하대 교수, \장\승\희 GW&TRUST \대표, \안장�\� 변호\사, \임설\아 비엘디 \대표, 김숙�\�� 김숙�\��우리옷 \대표 \등 각 분야별 \회원사 \대표�\�� \대거 참석하였다. \r\n \r\n \r\n\r\n그린\테크가전 \전문기업인 \디�\��이\산\업, \한복\디자이\너 \전문 브랜드인 김숙�\��우리옷 \등 620\여 \회원사�\� \시작으로 출�\��한 \한국강소기\업협회는 강소기\업 \사례를 \연구하�\�� 중소기\업이 \실\행키 \어\려\운 기술�\���\��, \수�\�� \판�\���\���\�� \등 \다\양한 \현안 문제들\을 \함께 \해결하기 \위해 \설립된 \단체이\다.\r\n\r\n\협회 관�\��자는 \"\연 매�\�� 5000\억\원 \이\하의 중소, 중견기업을 \회원사로 \유�\��해 경쟁력 강화를 \위한 \다\양한 \사례를 \연구해 \회원사\들\이 벤�\���\��팅을 \통\해 \이�\� \적극 공유할 \수 \있도�\�� \할 계획\"\이\라고 \전했다.\r\n\r\n\또한, \웨\딩관련\업체로는 \유일\하�\�� \한국강소기\업협회의 고문\을 맡은 \한복\연구�\��인 김숙�\��대표(김숙�\��우리옷)\는 \"\협회 \회원사\인 620개 중소, 중견기업 모두�\�� 국내\외\적으로 경쟁력 \높은 강소기\업으로 거듭\나는 계기가 \될 \수 \있었으�\� \하는 바램\"\이\라�\�,\r\n\r\n\앞으로 \"\협회 고문\으로서 모든 \회원사가 강소기\업으로 거듭\나 고�\���\���\���\��의 \사\회경\제적 모�\��텀을 공유함\으로써 \어\려\운 \여건속에서나�\�� \희망과 \용기를 \사\회에 \전할 \수 \있는 \뜻깊은 \일\이 \될 \수 \있도�\�� 최선을 \다\할 것\"\이\라고 \소임을 \전했다. \r\n\r\n\한국강소기\업협회 \회장 및 고문 명단\은 \아래와 같다.\r\n\r\n\정운�\� 명예회장(\동�\��성\장\연구소 \이\사\장, \전 국무총리)\r\n\손욱 고문(\서울\대융\합기술대학원 \센\타장)\r\n김�\��선 \전)\인천항만공\사 \대표\r\n\성\낙한 그레이\더스 \회장\r\n권영후 \오\성\화학 \회장\r\n김숙�\�� 김숙�\��우리옷 \한복\디자이\너(벤�\��기\업인증)\r\n\정희�\� \태방\파텍 \회장\r\n최정숙 \포커스컴퍼\니 \대표(\전 \여\성벤�\��협회 \회장)\r\n강태운 \엘디에�\��홀딩\스 \회장\r\n\장기조 \두둑한행복 \회장(\외\식 \프랜차\이즈)\r\n\오\희\숙 \전통부�\�� \식품�\��인25\호\r\n\남\상�\�� \한국관�\��공\사 \회장\r\n\이\세\인 까르방�\��리\아 \회장\r\n\두�\��문 \시안파트\너스 \회장\r\n\이병용 \자연과환경 \회장(코스\닥 \상장\사)\r\n강석창 \소�\���\���\���\�� \대표(꽃을든남\자, \소�\��화장\품)\r\n강희갑 \영덕산\업 \회장\r\n천정자 \장\흥\식품 \대표\r\n\r\n\자�\��제공 : 김숙�\��우리옷( 02-548-2588 http://www.kimsookjin.com )\r\n \r\n\r\n\r\n\r\n\월�\��웨\딩21 \편집�\��<news@wef.co.kr>', '', '', 0, 0, 2, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 17:18:16', 1, '2019-08-27 17:18:16', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(11, -10, '', 11, 0, 0, '', '', '', '\인문학 \'\우�\� \옷\'\연구�\��', '\인문학으로 \옷\을 짓는 \‘우�\� \옷\’ \연구�\��, 김숙�\�� \대표\r\n\r\n\“... 모든 죽어가는 것을 \사\랑해\야지. 그리고 \나에�\�� 주어진 길을 걸어가야겠다\”\r\n\r\n\한복 브랜드의 \산 \역\사로 불리\는 김숙�\�� \대표를 만난 \후 머릿\속에 \자연\스\럽게 \떠오�\� \윤\동주 \시인\의 \서시다. \한복\을 계승\해\야 \할 \전통\으로 \생�\��하는 �\�. \사\업�\��이기에 \앞서 \우�\� 문화를 \이\어\나�\��다\는 묵�\��한 \사명�\��, \어\떤 \환경 \속에서도 묵묵\히 \자신의 길을 개�\��해 \나�\��는 \단\단\한 �\� 마음이 \크게 \와 \닿\았다.\r\n\r\n \r\n\r\n\한복 \디자이\너에서 복식연구�\���\��\r\n\r\n\인\터뷰를 \위해 직접 만나기 \전 그녀의 \수�\��은 \대외 \활동 \내\역�\� \수상 \내\역\을 \자�\���\�� \접했다. \옷\을 \디자인\하�\�� \판매\하는 것�\��으로 충�\��히 바빴\을 \삶 \속에서 �\� 같은 결과물을 \낼 \수 \있었던 \에너�\��의 근원이 무엇인지 무�\�� 궁�\��했다.\r\n\r\n\“항\상 10\년 \단\위�\�� 계획을 \세\우고 지�\��의 \나를 만들\어 갑니다. \하�\���\�� 지�\�� \사\업적 \성공�\��큼\이\나 중요한 �\� \사\라\져가는 \우�\� \전통 문화를 \이\어가�\�� \사\회에 공헌할 \수 \있는 기업이 \되는 것이\라고 \생�\��해\요”\r\n\r\n그녀�\�� 최근 마음에 \새긴 문구\라�\� 건넨 메모 \속에는 철학자 김형석 교수�\�� \쓴 글의 \일부�\�� \적혀 \있었다. \‘사\회의 \한 모퉁이\에서 책임을 감당\해 \온 \사\람들\이 \더 \늦�\� \전에 보다 좋은 \사\회를 \위해 무엇인가 \한�\���\��씩\이\라\도 책임을 지는 것이 \당\연\한 \의무\라고 본다. \큰\일\을 \하자는 것은 \아니다. \해\야 \할 \일\을 \하자는 \뜻\이\다.\’\r\n\r\n\이 문장\을 마음에 \담고 \실천하�\��자 \한 김 \대표는 조�\�� \더 체�\��적인 공�\���\�� \필요하다고 \생�\��해 \한 \대학에서 \의�\��패\션학 \전공\을 \시작했다. \앞으로 \대학원에서는 복식사 공�\��를 \제대�\�� \할 \생�\��이\다. 10\년 \후에는 \단\순한 \한복 \디자이\너�\�� \아니라 복식연구�\���\�� \인\정�\���\�� \싶\은 \욕심\이\다.\r\n\r\n\여기에는 \오\늘날 \한복\이 \생활한복\의 \자리�\� \잃�\�� \행사 \때나 \입는 \옷\으로 \인\식되는 \시�\��에 \대한 \안타�\��움과 \옷\을 \연구하는 \한복\디자이\너�\��서 갖는 \시대적 \절�\��함\이 \늘 마음속에 \있기 \때문\이\다.\r\n\r\n \r\n\r\n\영�\��의 \원�\��은 박물관과 \역\사\r\n\r\n\우�\� 민족\의 \삶\이 \녹\아 \있는 \한복\을 \이\어가야 \한다\는 김 \대표의 \이\러\한 \생�\��에 \영�\��을 주는 \원�\��은 박물관이\다. 중�\��등\학�\�� \학생들\이 배우\는 \한국\사 같은 책도 곁에 \두�\�� 즐겨보는 \편\이\다.\r\n\r\n김 \대표는 \“요�\��은 \전통 \한복\이\라고 부를 만한 \한복 브랜드를 찾아보�\� \힘든 것이 \현실\입니다. 급격\히 변화하는 \트\렌드에서 \살\아남�\� \위해 김숙�\��우리옷 \역\시 \전통�\� \현대의 \접목\점을 찾기 \위해 부단\히 \노\력 중입니다. \하�\���\�� \우리�\�� 거�\�� \온 \역\사�\� \잊�\��서는 \이질적인 \두 \시대를 \연결하기 \힘들\다고 \생�\��합\니다.\”\r\n\r\n\또 \한복만 \다뤘던 \디자이\너들\의 \한�\��를 \뛰\어\넘기 \위해 \패\션디자인\을 \전공\한 \디자이\너들\을 \영입해 \패\턴부터 \소재까�\�� \새�\��운 감�\��을 불어\넣\으\려고 \노\력\한다.\r\n\r\n김숙�\��우리옷\은 \올\해 \한복 \장\인 5\호 \인증을 받았다. \소�\��자에�\��서 \옷\이 마음에 \안 \든다\는 컴플레인\을 받은 기억\이 거의 \없을 \정도�\�� 까다로운 바느�\���\��과 \일반 \한복보다 \세분화된 \사\이즈 \실측으로 \완성\하는 \편\안한 \패\턴\으로 \완성\해\온 \실\력\이 공식적으로 \인\정�\��은 \셈이\다.\r\n\r\n\상담부터 \사\이즈 \실�\�, \실\제 \한복 \제작�\���\�� \한 곳에서 진행하는 \시스\템 \역\시 마니아층\을 \탄탄하�\�� 거느릴 \수�\��에 \없는 비결\이\다. \옷 \한 벌 \한 벌을 \제품이 \아닌 \작품으로 \생�\��하는 김숙�\�� \대표�\�� \생�\��하는 \한복\의 \위상은 최근 \대�\��화된 개량 \한복\이\나 \생활 \한복과는 조�\�� \다르다.\r\n\r\n그렇다고 결혼\식 \때 \한 번 \입�\�� 마는 \예복\으로 \남\는다�\� \생�\��력\이 \약\해질 \수�\��에 \없다. \우리�\�� 격식을 갖�\�� \때 \입는 \정장처럼 \활용\도�\�� \높으면서도 \품위이고 고�\��스\러\운 \‘신한복\’ \디자인\을 만들\어 \나�\��는 것이 김숙�\�� \대표의 목표다.\r\n\r\n\r\n\r\n\세계 \속의 \한복\을 꿈꾸\다\r\n\r\n90\년 \후�\�� \산\자�\��의 지원 \하에 처음 만들\어진 \‘모\시문\화제’의 조�\��위원회 \일\을 \수락\했던 것은 \한복�\� \한복 \소재\의 \세계화에 \대한 \욕심 \때문\이\다. \이\후 강남구�\�� \선정한 미주\통\상�\���\��단, \유럽\통\상�\���\��단\의 10개 \업체\에 \선정돼 각 \나라\에서 \단\독 \전시를 \열\었다.\r\n\r\n\“당\시 \파티 문화�\�� \자리 \잡\은 비엔나, \크로아티\아의 \상�\��층\에�\�� \한복\이 \신선함\으로 \어\필했습\니다. \한복 고유의 \선, 컬러감, \디테일 \등\을 \살�\� \파티복을 만들\어 \수�\��했�\��.\” \r\n\r\n\앞으로도 \한복 \자체�\� \세계화한다기보\다 \한복\의 \아�\��다\움을 \알리고, \한복\의 \디테일\을 \녹\여 만든 \패\션으로 \세계화시키고 \싶\은 \욕심\을 버리지 \않았다. \사\실 \전통 계승\은 개인\이 \하기\는 \쉽지않다. \정�\�� 차원의 지속적인 관심�\� 지원이 \필요하�\���\�� 김 \대표는 \업�\��를 \이\끌어 \온 중견\들\이 \해\야 \할 \저�\��다\의 \역\할이 \있다고 \생�\��한다.\r\n\r\n \r\n\r\n\“신세\대의 취향\에 맞는 \독특\한 \디자인�\� \현대적 감�\��을 가미\한 \색상으로 \한복\의 \트\렌드를 만들\어\야죠. 그렇�\�� \사\회의 \한 구성\원으로서 \의무�\� 감내\하며 꾸�\��히 \나의 길을 가�\�� \싶\습\니다.\” \r\n\r\n\현재 \사\단법인 개설\을 준�\��하는 김 \대표는 \한복 \디자인 공모\전 개�\��를 \통\한 꾸�\��한 \한복 \디자이\너 \육\성 \작업, 바늘�\��이·조�\��보 만들�\� \등\의 규방공예, \한�\�� \인\형 만들�\� \등\의 문화 체험 \프�\��그\램\을 개설\해 \한복\이 \한국 \전통 문화의 중심\이 \되도�\�� \한다\는 계획이\다.\r\n\r\n\“전통\을 \잇�\�� \싶\어 \하는 \젊은 \후학을 \끊임없이 발굴\해 \전통�\� \현대를 \잇는 가�\�� \역\할에 집�\��할 것입니다. \한편, \원단 \재직에서 \옛 문헌의 고�\��을 \통\한 \전통 문양 \재\현과 \자수 배�\��, \저�\��리 치�\��, 마�\��자, 바�\�� \등 \옷\의 \특\성\에 \따�\� \전통 바느�\��, \손수 \염\색 \등 \전통기�\��을 발전시�\�� \우�\� \옷\의 \아�\��다\움을 \나타내고자 \합\니다.\”\r\n\r\n \r\n\r\n\에디터 조윤\예 \r\n\월�\��웨\딩21 \편집�\��<news@wef.co.kr> \r\n\r\n\저작�\��자 \ⓒ온\포\스미디어 \r\n�\� 기사\의 비승\인 복제, \전송, 무단 \전재, \재가공 \등\을 금하며 \위�\��시 법적인 책임을 질 \수 \있습\니다.', '', '', 0, 0, 2, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 17:19:28', 1, '2019-08-27 17:19:28', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(12, -11, '', 12, 0, 0, '', '', '', '마이\웨\딩 17\년 8\월호', '마이\웨\딩 2017\년 8\월호\r\n\r\n김숙�\��우리옷\의 \작품이 \실\렸\습\니다.\r\n\r\n\r\n\​\r\n\풀�\��이 고운 \장\옷�\� \은�\�� 치�\���\�� \현대적인 조화를 보여준다. 김숙�\�� \우리옷.\r\n\r\n\​\r\n\r\n\​남\색 본견 \원삼 \속에 \레이\스 \저�\��리\와 \흰\색 치�\��를 \입어 \원삼\의 \남\색이 \돋보\인\다. 김숙�\�� \우리옷.\r\n\r\n\r\n\r\n\사진 김보\하 \r\n모델 \노\재\희 \r\n\한복 \r\n김숙�\�� \우리옷(02-548-2588) \r\n\한국\의상 백옥\수(02-6080-9422) \r\n\한국\의상 \은유(02-545-8863) \r\n\헤\어&메이\크\업 \r\n\애�\��뉴준오(\헤\어 \효\심 메이\크\업 김미\소 02-2138-0605)', '', '', 0, 0, 2, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 17:20:14', 1, '2019-08-27 17:20:14', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(13, -12, '', 13, 0, 0, '', '', '', 'Wedding21 17\년 8\월호', '\다\양한 \시대적 무드�\�� \시�\��을 초월한 \듯 빼어\난 \아�\��다\움을 \선사\하는 김숙�\��우리옷, \r\n김숙�\��우리옷\을 \입은 \신랑신�\��와 \두 \사\람의 친구\들\이 \웨\딩\데\이�\� 즐기고 \있다. \r\n\한복\의 \아�\��다\움이 바람에 \날리\는 꽃향기�\��럼 \향기롭게 채워�\��는 \현장\을 \담\았다. \r\n\r\n\r\n\r\n\연카키\색 \답\호\와 \남\색 바�\���\�� \어\우\러\저 \안정적이고 차�\��한 분위기�\� \자아낸\다.\r\n\흰\색 \저�\��리\와 밝은 \연\둣빛 치�\���\�� \싱그러\운 \느낌의 \한복.\r\n\노\랑 명주 \당\의와 차�\��한 베이지톤\의 치�\��의 조화�\�� \아�\��답\다. \r\n\r\n\r\n\r\n막 \피\어\나는 \듯 \생동�\�� \있는 \푸른�\�� \플라\워 \패\턴\이 \돋보\이\는 철릭\원피\스 \r\n \r\n\r\n\r\n\피치�\��이지 \턱\시도와 \레이\스 \저�\��리\와 미디 기장\의 치�\���\�� \완성\한 \웨\딩 \한복. \r\n\r\n\r\n\​\r\n분홍�\�� \플라\워 \패\턴\의 \실\크 \저�\��리가 \화사\한 \한복.\r\n\생동�\�� \있는 주홍�\��과 짧은 기장\의 치�\���\�� 귀여\운 \느낌을 \자아낸\다. \r\n\r\n\​\r\n\r\n\은은하�\�� \수놓아�\�� \플라\워 \패\턴\이 고�\��스\러\운 \실\크 \소재\의 \한복.\r\n분홍�\�� \톤 \온 \톤  매�\���\�� 조화롭\다.\r\n\얼굴을 \화사\하�\�� 밝혀주\는 \생동�\�� \있는 컬러\의 \한복\이\다.\r\n\r\n\r\n\r\n\은은하�\�� \퍼진 \은�\�� 무늬가 \아�\��다\운 \한복 \드레스. \r\n \r\n\r\n\r\n청�\���\�� 반�\���\�� 멋스\럽\다. \r\n\단\아하면\서 간결\한 멋이 \돋보\이\는 \화이\트 \한복 \드레스 \r\n\r\n\r\n\r\n\연분홍�\�� \당\의형 \저�\��리\와 \하얀 치�\��의 조화�\�� 로맨\틱\하다. \r\n\신�\�� \한복�\� 같은 분위기로 \연분홍�\�� 쾌자를 \덧\입었다.\r\n \r\n\r\n\r\n\은은한 \저�\��도 배색의 \저�\��리\와 치�\���\�� \단\아해 보인\다.\r\n\r\n\r\n\r\n꽃잎이 \피\어\난 \듯 \다채�\��운 \색�\��이 \시선을 \사로잡\는다. \r\n\앙�\���\��은 치�\��와 \푸른�\�� \플라\워 \패\턴 \저�\��리\의 조화�\�� \아�\��답\다.\r\n\r\n\​\r\n\r\n\다채�\��운 \색�\��이 \돋보\이\는 \플라\워 \패\턴\의 \신한복.\r\n\은회색�\�� 쾌자�\�� 부드러\운 \인\상을 \전한다. \r\n분홍�\�� \당\의에 \재\해\석된 \전통\자수�\�� \포\인\트�\� 주었다.\r\n\푸른�\�� \플라\워 \패\턴 \저�\��리가 \여\성\스\러\운 \느낌을 \전한다.\r\n\r\n\r\n\r\n\r\n\턱\시도: 몬테�\��아\r\n\스\타일\디렉터:김미\예(\웨\딩\잇)\r\n\포\토그\래퍼:\정한택(\오브라\픽쳐스)\r\n모델:김�\���\��,박소영,박주\하,\송\제이\r\n\헤\어:\윤\정,\아�\�� 메이\크\업:미정,\세진(\오\테르청담)\r\n\제품협조:비�\��이\레이\디,\앙뜨,JM\다\이\아몬\드\r\n\플라\워: 김리\원(\슈에뜨블롬)\r\n\장\소:메이\필드호\텔\r\n\영상:\웨\딩�\�', '', '', 0, 0, 3, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 17:21:32', 1, '2019-08-27 17:21:32', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', ''),
(14, -13, '', 14, 0, 0, '', '', '', '\대표 김숙�\�� \인\터�\�', '\한복\을 \닮\은 명인(\名人)\r\n\'\한복\의 \시대\'�\� \열\다.\r\n\r\n\"\사\단법인\을 \통\해 \한복\디자인 공모\전, \한복 만들�\� 체험 \프�\��그\램 \등\을 개설\해 \한복\이 \한국 \전통 문화의 중심\이 \되도�\�� \노\력\하�\��습\니다. \특\히 \전통\에 관심\이 많은 \젊은 \후학을 발굴\하여 \적극 \육\성\하�\��습\니다.\"\r\n\우�\� \대통\령\의 \해\외\순방 \의전한복\담\당, \대한항�\� \승무원 \한복\유니폼 \제작, \우리옷\장\인 \인증 \등 김숙�\�� \대표를 \상�\��하는 \수식어\들\을 \되뇌며 \인\터뷰를 \시작하려\는 기자에�\�� 김 \대표�\�� 건넨 첫�\��디는 \뜻밖에 \전통문화의 \전파와 \후학 \육\성\이\었다. \'\한복\업�\��의 \사관학�\��\'\라\는 별�\��을 가�\�� \'김숙�\��우리옷\'\의 김숙�\�� \대표는 개인\의 \욕심보다\는 국�\��와 \사\회를 \위해 기여\해\야 \한다고 강조\했다. \'\나\'보다\는 \'\우�\�\'�\� 먼저 \생�\��하는 \한복 명인 김숙�\�� \대표의 \한복철학을 \들\어보자.\r\n\r\n\r\n\​\r\n\"\저는 \한복\에 \대한 \열망과 비전�\��으로 \여기�\���\�� \왔습\니다. \일\생에 걸�\��서 \사명�\��을 가�\���\�� \할 \수 \있는 것이 무엇일까 고민\하다 \한복\을 \시작하�\�� \되었�\��, 지�\��도 \오직 \한복만을 \생�\��하며 \행복\하�\�� \일\하�\�� \있습\니다.\" \'김숙�\��우리옷\'김숙�\�� \대표는 \어�\� \시절 \한복\을 \유난히 좋아하시는 부모\님의 \영향\으로 \한복\을 \생활 \속에서 친숙하�\�� \접할 \수 \있었�\��, \한복\은 �\� 그녀의 \전�\���\�� \되었다. \"\한복\에 \인\생을 바�\��기로 맹세\하�\��, 최�\���\�� \되려�\� 최�\��에�\�� 배워야\한다\는 \생�\��에 \'\이리자 \한복 \연구소\'�\� 찾아�\�� \이리자 \선생님의 \제자�\�� \되었습\니다. \이리자 \선생님�\��는 \우리나라 \한복 \소재\의 \특\성, \디자인, \전통바느�\�� \나아�\�� \한복\을 만드는 \사\람의 철학과 마음�\���\���\���\�� \도제식으로 배웠습\니다. \" 김 \대표는 \이리자 \선생의 \도제수업 \이\후에도 복식(\服飾)\의 \이론을 \더 배우�\� \위해 \당\시 \성\신여\대 박경\자 교수(\당\시 \세계복\식학회 \회장)�\� 찾아�\�� \전통 복식의 \역\사\와 \이론을 배우고, \단국대 고 \석주\선 박사\님�\�� 고�\��을 \사\사받�\��, 고 \서수연(\섬\유예술�\��)\선생님�\�� \섬\유예술과 \색을 배웠다. 그녀의 \끝없는 배움은 지�\���\���\�� \이\어\져 최근\에는 \성균�\��대 출토복\식 강의�\���\�� \이\어지�\�� \있다. \r\n\r\n그래서일까. \'김숙�\��우리옷\'\의 \한복\은 \항\상 \시대를 \앞서�\��다\는 \평이\다. 김 \대표의 \한복\은 \서구\화 \되어가는 \우리나라 \사\람들\의 체형을 면�\��히 \연구하여 \재\단�\� 바느�\�� 과정을 과학적으로 구현했다. \한복\이 불편\하다\는 \선입견\을 \없애�\��, \편\안함�\� \단\아한 \느낌을 줄 \수 \있는 \'김숙�\��우리옷\'만의 \앞서�\��는 \패\턴\도 창조\했다. \전통�\� \현대적 감�\��의 조화를 \위해, \원단 \선택에서�\��터 \전통 바느�\��, \전통 \염\색 \등\의 기�\��을 \통\해 \한복\의 \아�\��다\움을 \현대에 맞�\�� \재\해\석했기 \때문\에, \한복\점이 밀�\��한 청담\동에서도 \항\상 \으\뜸\으로 꼽힌다. 김 \대표는 \한복만 \다뤘던 \디자이\너의 \한�\��를 극복\하기 \위해 \서양의 \패\션디자인\을 \전공\한 \디자이\너�\���\�� \영입해 \패\턴부터 \소재까�\�� \새�\��운 감�\��을 불어\넣\었다. \양장\전문가의 \눈을 \통\하여 \한복\의 \디자인\을 \재\평�\��하�\�� \양장\의 \장\점을 \한복\에 \접목\하여, \더욱 \사\랑�\��는 \한복\을 만들�\� \위해\서다.\r\n\r\n\r\n\r\n\'\일류\'\는 \'\일류\'가 \알아본\다.\r\n\"\제자들\에�\�� \항\상 꿈을 가�\��라고 강조\합\니다. \자신이 좋아하는 \일\은 밤을 \새도 \재밌�\�� \신나기 \때문\입니다. 그리고 \포기하�\�� 말�\�� \언\젠�\�� \'\나의 \시대\'가 \올 \때를 기다리며 충�\��히 준�\��해\야 \합\니다. \내가 \삼류인\데 \일류�\�� 찾아오\는 법은 \없습\니다. \내가 먼저 \일류�\�� \되어\야 \일류�\�� \알아보고 찾아오\는 법입니다.\" \'김숙�\��우리옷\'\은 \한복\인\들 \사\이\에서 \'\한복 \사관학�\��\'\라고 불린\다. 청담\동의 많은 \한복\디자이\너들\이 김숙�\�� \대표의 \제자이�\�, 그녀에�\��서 \도제식으로 배운 \한복\인\들\의 \자�\��심 \또한 \대단\하기 \때문\이\다. \더�\��어 \'김숙�\��우리옷\'\은 \유행에 \휩\쓸리�\�� \않으면서도, \패\션의 \흐�\��을 \품위 \있�\�� 리드한다\는 \평�\��다. \아�\��도 복식의 \흐�\��을 먼저 창조\하는 김 \대표의 \심미안(審�\��眼)\에서 \유행이 \파생되기 \때문\이 \아닐�\��.\r\n\"\제 꿈은 \우리나라\와 비자�\�� \오\픈된 160\여개 각 \나라\에 \우리의 \자랑스\러\운 \한복\을 \수�\��하는 것입니다. \한복\의 \수�\��은 �\� 문화의 \수�\��이�\� \때문\입니다. 그래서 지�\��도 \세계인\에�\�� \통\하는 \한복\을 만들�\� \위해 \끊임없이 \디자인\을 개�\��하�\�� \있습\니다.\"\r\n김 \대표의 \한복\은 \이�\� 글�\���\��시장\에서 \여\러 번 \화제�\�� \되었다. \대�\��의 글�\���\��기\업 \임�\��원용 \한복\을 \수년�\�� \수�\��하기\도 \했�\��, 강남�\� \유럽\통\상�\���\��단 \대표�\�� \유럽\에 방문\했을 \때 \현�\��인\들\이 \한복\에 \폭발적인 반응을 보여 \오\스\트리아(비엔나), \크로아티\아 \등\의 \패\션의�\�� \유통기업에 \수�\��하기\도 \했다. \얼마후 진행되는 \평창\동�\��올림픽 \성공기\원행사(\평창 고려궁한옥\호\텔)\에서는 국내\외 귀�\�� \앞에서 \한복\패\션쇼�\� \성\대하�\�� 기획하여 진행할 \예정이\다. 지�\��의 김숙�\�� \대표를 만든 것은 \한복\에 \인\생을 걸�\��다\는 \사명�\��과 \노\력\이\었다. 김 \대표 \자신은 \오\늘의 \성과도 공�\��와 \독서의 \힘 \일뿐 \자신은 \아�\�� 부족\하다�\� \수�\���\�� \웃었다. \한복\은 \선이 곱�\��, \아�\��다\우�\�, \동양의 \독특\한 멋을 \낸\다. \은은한 마음씨\와 \정겨\운\도 \느낄 \수 \있다. 기자�\�� 만난 김숙�\�� \대표도 \아�\��다\움 \한복�\� \닮\아 \있었다. \한복\을 \닮\은 \한복 명인 김숙�\�� \대표는 조�\��씩, 그리고 \확실\하�\�� \'\한복\의 \시대\'�\� \열고 \있었다. \r\n\r\n- \이\양은 기자\r\n\r\n\r\nECONOMYVIEW 2017\년 8\월호', '', '', 0, 0, 3, 0, 0, 'admin', '*A4B6157319038724E3560894F7F932C8886EBFCF', '최�\���\��리\자', 'admin@domain.com', '', '2019-08-27 17:22:10', 1, '2019-08-27 17:22:10', '112.222.187.243', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- 테이블 구조 `g5_write_qa`
--

CREATE TABLE `g5_write_qa` (
  `wr_id` int(11) NOT NULL,
  `wr_num` int(11) NOT NULL DEFAULT '0',
  `wr_reply` varchar(10) NOT NULL,
  `wr_parent` int(11) NOT NULL DEFAULT '0',
  `wr_is_comment` tinyint(4) NOT NULL DEFAULT '0',
  `wr_comment` int(11) NOT NULL DEFAULT '0',
  `wr_comment_reply` varchar(5) NOT NULL,
  `ca_name` varchar(255) NOT NULL,
  `wr_option` set('html1','html2','secret','mail') NOT NULL,
  `wr_subject` varchar(255) NOT NULL,
  `wr_content` text NOT NULL,
  `wr_link1` text NOT NULL,
  `wr_link2` text NOT NULL,
  `wr_link1_hit` int(11) NOT NULL DEFAULT '0',
  `wr_link2_hit` int(11) NOT NULL DEFAULT '0',
  `wr_hit` int(11) NOT NULL DEFAULT '0',
  `wr_good` int(11) NOT NULL DEFAULT '0',
  `wr_nogood` int(11) NOT NULL DEFAULT '0',
  `mb_id` varchar(20) NOT NULL,
  `wr_password` varchar(255) NOT NULL,
  `wr_name` varchar(255) NOT NULL,
  `wr_email` varchar(255) NOT NULL,
  `wr_homepage` varchar(255) NOT NULL,
  `wr_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `wr_file` tinyint(4) NOT NULL DEFAULT '0',
  `wr_last` varchar(19) NOT NULL,
  `wr_ip` varchar(255) NOT NULL,
  `wr_facebook_user` varchar(255) NOT NULL,
  `wr_twitter_user` varchar(255) NOT NULL,
  `wr_1` varchar(255) NOT NULL,
  `wr_2` varchar(255) NOT NULL,
  `wr_3` varchar(255) NOT NULL,
  `wr_4` varchar(255) NOT NULL,
  `wr_5` varchar(255) NOT NULL,
  `wr_6` varchar(255) NOT NULL,
  `wr_7` varchar(255) NOT NULL,
  `wr_8` varchar(255) NOT NULL,
  `wr_9` varchar(255) NOT NULL,
  `wr_10` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 덤프된 테이블의 인덱스
--

--
-- 테이블의 인덱스 `g5_auth`
--
ALTER TABLE `g5_auth`
  ADD PRIMARY KEY (`mb_id`,`au_menu`);

--
-- 테이블의 인덱스 `g5_autosave`
--
ALTER TABLE `g5_autosave`
  ADD PRIMARY KEY (`as_id`),
  ADD UNIQUE KEY `as_uid` (`as_uid`),
  ADD KEY `mb_id` (`mb_id`);

--
-- 테이블의 인덱스 `g5_board`
--
ALTER TABLE `g5_board`
  ADD PRIMARY KEY (`bo_table`);

--
-- 테이블의 인덱스 `g5_board_file`
--
ALTER TABLE `g5_board_file`
  ADD PRIMARY KEY (`bo_table`,`wr_id`,`bf_no`);

--
-- 테이블의 인덱스 `g5_board_good`
--
ALTER TABLE `g5_board_good`
  ADD PRIMARY KEY (`bg_id`),
  ADD UNIQUE KEY `fkey1` (`bo_table`,`wr_id`,`mb_id`);

--
-- 테이블의 인덱스 `g5_board_new`
--
ALTER TABLE `g5_board_new`
  ADD PRIMARY KEY (`bn_id`),
  ADD KEY `mb_id` (`mb_id`);

--
-- 테이블의 인덱스 `g5_cert_history`
--
ALTER TABLE `g5_cert_history`
  ADD PRIMARY KEY (`cr_id`),
  ADD KEY `mb_id` (`mb_id`);

--
-- 테이블의 인덱스 `g5_content`
--
ALTER TABLE `g5_content`
  ADD PRIMARY KEY (`co_id`);

--
-- 테이블의 인덱스 `g5_faq`
--
ALTER TABLE `g5_faq`
  ADD PRIMARY KEY (`fa_id`),
  ADD KEY `fm_id` (`fm_id`);

--
-- 테이블의 인덱스 `g5_faq_master`
--
ALTER TABLE `g5_faq_master`
  ADD PRIMARY KEY (`fm_id`);

--
-- 테이블의 인덱스 `g5_group`
--
ALTER TABLE `g5_group`
  ADD PRIMARY KEY (`gr_id`);

--
-- 테이블의 인덱스 `g5_group_member`
--
ALTER TABLE `g5_group_member`
  ADD PRIMARY KEY (`gm_id`),
  ADD KEY `gr_id` (`gr_id`),
  ADD KEY `mb_id` (`mb_id`);

--
-- 테이블의 인덱스 `g5_login`
--
ALTER TABLE `g5_login`
  ADD PRIMARY KEY (`lo_ip`);

--
-- 테이블의 인덱스 `g5_mail`
--
ALTER TABLE `g5_mail`
  ADD PRIMARY KEY (`ma_id`);

--
-- 테이블의 인덱스 `g5_member`
--
ALTER TABLE `g5_member`
  ADD PRIMARY KEY (`mb_no`),
  ADD UNIQUE KEY `mb_id` (`mb_id`),
  ADD KEY `mb_today_login` (`mb_today_login`),
  ADD KEY `mb_datetime` (`mb_datetime`);

--
-- 테이블의 인덱스 `g5_member_social_profiles`
--
ALTER TABLE `g5_member_social_profiles`
  ADD UNIQUE KEY `mp_no` (`mp_no`),
  ADD KEY `mb_id` (`mb_id`),
  ADD KEY `provider` (`provider`);

--
-- 테이블의 인덱스 `g5_memo`
--
ALTER TABLE `g5_memo`
  ADD PRIMARY KEY (`me_id`),
  ADD KEY `me_recv_mb_id` (`me_recv_mb_id`);

--
-- 테이블의 인덱스 `g5_menu`
--
ALTER TABLE `g5_menu`
  ADD PRIMARY KEY (`me_id`);

--
-- 테이블의 인덱스 `g5_new_win`
--
ALTER TABLE `g5_new_win`
  ADD PRIMARY KEY (`nw_id`);

--
-- 테이블의 인덱스 `g5_point`
--
ALTER TABLE `g5_point`
  ADD PRIMARY KEY (`po_id`),
  ADD KEY `index1` (`mb_id`,`po_rel_table`,`po_rel_id`,`po_rel_action`),
  ADD KEY `index2` (`po_expire_date`);

--
-- 테이블의 인덱스 `g5_poll`
--
ALTER TABLE `g5_poll`
  ADD PRIMARY KEY (`po_id`);

--
-- 테이블의 인덱스 `g5_poll_etc`
--
ALTER TABLE `g5_poll_etc`
  ADD PRIMARY KEY (`pc_id`);

--
-- 테이블의 인덱스 `g5_popular`
--
ALTER TABLE `g5_popular`
  ADD PRIMARY KEY (`pp_id`),
  ADD UNIQUE KEY `index1` (`pp_date`,`pp_word`,`pp_ip`);

--
-- 테이블의 인덱스 `g5_qa_content`
--
ALTER TABLE `g5_qa_content`
  ADD PRIMARY KEY (`qa_id`),
  ADD KEY `qa_num_parent` (`qa_num`,`qa_parent`);

--
-- 테이블의 인덱스 `g5_scrap`
--
ALTER TABLE `g5_scrap`
  ADD PRIMARY KEY (`ms_id`),
  ADD KEY `mb_id` (`mb_id`);

--
-- 테이블의 인덱스 `g5_uniqid`
--
ALTER TABLE `g5_uniqid`
  ADD PRIMARY KEY (`uq_id`);

--
-- 테이블의 인덱스 `g5_visit`
--
ALTER TABLE `g5_visit`
  ADD PRIMARY KEY (`vi_id`),
  ADD UNIQUE KEY `index1` (`vi_ip`,`vi_date`),
  ADD KEY `index2` (`vi_date`);

--
-- 테이블의 인덱스 `g5_visit_sum`
--
ALTER TABLE `g5_visit_sum`
  ADD PRIMARY KEY (`vs_date`),
  ADD KEY `index1` (`vs_count`);

--
-- 테이블의 인덱스 `g5_write_freeboard`
--
ALTER TABLE `g5_write_freeboard`
  ADD PRIMARY KEY (`wr_id`),
  ADD KEY `wr_num_reply_parent` (`wr_num`,`wr_reply`,`wr_parent`),
  ADD KEY `wr_is_comment` (`wr_is_comment`,`wr_id`);

--
-- 테이블의 인덱스 `g5_write_gallery`
--
ALTER TABLE `g5_write_gallery`
  ADD PRIMARY KEY (`wr_id`),
  ADD KEY `wr_num_reply_parent` (`wr_num`,`wr_reply`,`wr_parent`),
  ADD KEY `wr_is_comment` (`wr_is_comment`,`wr_id`);

--
-- 테이블의 인덱스 `g5_write_notice`
--
ALTER TABLE `g5_write_notice`
  ADD PRIMARY KEY (`wr_id`),
  ADD KEY `wr_num_reply_parent` (`wr_num`,`wr_reply`,`wr_parent`),
  ADD KEY `wr_is_comment` (`wr_is_comment`,`wr_id`);

--
-- 테이블의 인덱스 `g5_write_qa`
--
ALTER TABLE `g5_write_qa`
  ADD PRIMARY KEY (`wr_id`),
  ADD KEY `wr_num_reply_parent` (`wr_num`,`wr_reply`,`wr_parent`),
  ADD KEY `wr_is_comment` (`wr_is_comment`,`wr_id`);

--
-- 덤프된 테이블의 AUTO_INCREMENT
--

--
-- 테이블의 AUTO_INCREMENT `g5_autosave`
--
ALTER TABLE `g5_autosave`
  MODIFY `as_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- 테이블의 AUTO_INCREMENT `g5_board_good`
--
ALTER TABLE `g5_board_good`
  MODIFY `bg_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 테이블의 AUTO_INCREMENT `g5_board_new`
--
ALTER TABLE `g5_board_new`
  MODIFY `bn_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- 테이블의 AUTO_INCREMENT `g5_cert_history`
--
ALTER TABLE `g5_cert_history`
  MODIFY `cr_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 테이블의 AUTO_INCREMENT `g5_faq`
--
ALTER TABLE `g5_faq`
  MODIFY `fa_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 테이블의 AUTO_INCREMENT `g5_faq_master`
--
ALTER TABLE `g5_faq_master`
  MODIFY `fm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 테이블의 AUTO_INCREMENT `g5_group_member`
--
ALTER TABLE `g5_group_member`
  MODIFY `gm_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 테이블의 AUTO_INCREMENT `g5_mail`
--
ALTER TABLE `g5_mail`
  MODIFY `ma_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 테이블의 AUTO_INCREMENT `g5_member`
--
ALTER TABLE `g5_member`
  MODIFY `mb_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 테이블의 AUTO_INCREMENT `g5_member_social_profiles`
--
ALTER TABLE `g5_member_social_profiles`
  MODIFY `mp_no` int(11) NOT NULL AUTO_INCREMENT;

--
-- 테이블의 AUTO_INCREMENT `g5_menu`
--
ALTER TABLE `g5_menu`
  MODIFY `me_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=463;

--
-- 테이블의 AUTO_INCREMENT `g5_new_win`
--
ALTER TABLE `g5_new_win`
  MODIFY `nw_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 테이블의 AUTO_INCREMENT `g5_point`
--
ALTER TABLE `g5_point`
  MODIFY `po_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 테이블의 AUTO_INCREMENT `g5_poll`
--
ALTER TABLE `g5_poll`
  MODIFY `po_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 테이블의 AUTO_INCREMENT `g5_popular`
--
ALTER TABLE `g5_popular`
  MODIFY `pp_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 테이블의 AUTO_INCREMENT `g5_qa_content`
--
ALTER TABLE `g5_qa_content`
  MODIFY `qa_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 테이블의 AUTO_INCREMENT `g5_scrap`
--
ALTER TABLE `g5_scrap`
  MODIFY `ms_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 테이블의 AUTO_INCREMENT `g5_write_freeboard`
--
ALTER TABLE `g5_write_freeboard`
  MODIFY `wr_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- 테이블의 AUTO_INCREMENT `g5_write_gallery`
--
ALTER TABLE `g5_write_gallery`
  MODIFY `wr_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- 테이블의 AUTO_INCREMENT `g5_write_notice`
--
ALTER TABLE `g5_write_notice`
  MODIFY `wr_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- 테이블의 AUTO_INCREMENT `g5_write_qa`
--
ALTER TABLE `g5_write_qa`
  MODIFY `wr_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
